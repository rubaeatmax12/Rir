<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
redirect_if_not_logged_in();

// লগইন করা ইউজারের ডেটা তুলে আনা
$current_user = get_user_data($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connectrix</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- CSS Modules -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/base/variables.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/components/buttons.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/layout/three-column-layout.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/layout/navbar.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/layout/sidebar-left.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/layout/sidebar-right.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/search/search-results.css">
    <!-- নতুন গ্লোবাল ডার্ক মোড সিএসএস -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/base/dark-mode.css">
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const isDarkMode = <?php echo $current_user['dark_mode'] ?? 0; ?>;
            if (isDarkMode === 1) {
                document.body.classList.add('dark-mode');
            }
        });
    </script>
</head>
<body class="<?php echo ($current_user['dark_mode'] ?? 0) ? 'dark-mode' : ''; ?>">