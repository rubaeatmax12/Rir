<aside class="right-sidebar-column">
    <div class="sidebar-section-title">Contacts</div>
    
    <div class="contact-list">
        <!-- ডেমো কন্ট্যাক্ট ১ -->
        <div class="contact-list-item">
            <div class="contact-avatar-wrapper">
                <img class="contact-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/default-avatar.png" alt="User">
                <span class="online-dot"></span>
            </div>
            <span style="font-weight: 500; font-size:14px;">Demo Friend</span>
        </div>
        
        <!-- ডেমো কন্ট্যাক্ট ২ -->
        <div class="contact-list-item">
            <div class="contact-avatar-wrapper">
                <img class="contact-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/default-avatar.png" alt="User">
                <span class="online-dot"></span>
            </div>
            <span style="font-weight: 500; font-size:14px;">Zarin Anjum</span>
        </div>
    </div>
</aside>