<!-- Global Javascripts -->
    <script src="<?php echo SITE_URL; ?>/assets/js/notification/fetch-notifications-poll.js" defer></script>
    <script src="<?php echo SITE_URL; ?>/assets/js/search/live-search.js" defer></script>
    <!-- নতুন ডার্ক মোড জাভাস্ক্রিপ্ট -->
    <script src="<?php echo SITE_URL; ?>/assets/js/dark-mode-toggle.js" defer></script>
</body>
</html>