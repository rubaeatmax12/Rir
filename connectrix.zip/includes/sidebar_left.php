<aside class="left-sidebar-column">
    <ul class="sidebar-menu-list">
        <!-- Profile Link -->
        <li class="sidebar-menu-item" style="margin-bottom: 8px;">
            <a href="<?php echo SITE_URL; ?>/profile/view.php?id=<?php echo $current_user['id']; ?>">
                <img class="sidebar-icon-img" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($current_user['profile_pic']); ?>" alt="Profile">
                <span><strong><?php echo clean_output($current_user['first_name'] . ' ' . $current_user['last_name']); ?></strong></span>
            </a>
        </li>
        
        <!-- Friends Menu -->
        <li class="sidebar-menu-item">
            <a href="<?php echo SITE_URL; ?>/friends/index.php">
                <div class="sidebar-icon-placeholder"><i class="fa-solid fa-user-group"></i></div>
                <span>Friends</span>
            </a>
        </li>

        <!-- Chat Menu -->
        <li class="sidebar-menu-item">
            <a href="<?php echo SITE_URL; ?>/chat/index.php">
                <div class="sidebar-icon-placeholder"><i class="fa-solid fa-comments"></i></div>
                <span>Messages</span>
            </a>
        </li>

        <!-- Saved Posts Menu -->
        <li class="sidebar-menu-item">
            <a href="<?php echo SITE_URL; ?>/feed/saved.php">
                <div class="sidebar-icon-placeholder"><i class="fa-solid fa-bookmark" style="color:#e056fd;"></i></div>
                <span>Saved</span>
            </a>
        </li>

        <!-- Settings -->
        <li class="sidebar-menu-item">
            <a href="<?php echo SITE_URL; ?>/profile/settings.php">
                <div class="sidebar-icon-placeholder"><i class="fa-solid fa-gear" style="color:#65676B;"></i></div>
                <span>Settings</span>
            </a>
        </li>
    </ul>
</aside>