<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';

// ইউজার লগইন চেক করা
function is_logged_in() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_email']);
}

// সেশন ভ্যালিডেশন এবং অটো রিডাইরেক্ট (লগইন করা না থাকলে)
function redirect_if_not_logged_in() {
    if (!is_logged_in()) {
        header("Location: " . SITE_URL . "/auth/login.php");
        exit();
    }
}

// লগইন করা থাকলে গেস্ট পেজ (যেমন লগইন/রেজিস্টার) থেকে রিডাইরেক্ট করা
function redirect_if_logged_in() {
    if (is_logged_in()) {
        header("Location: " . SITE_URL . "/feed/index.php");
        exit();
    }
}

// ইউজার আইডি দিয়ে ইউজারের গুরুত্বপূর্ণ তথ্য নিয়ে আসা
function get_user_data($user_id) {
    $db = (new Database())->getConnection();
    $query = "SELECT id, first_name, last_name, email, profile_pic, cover_pic, bio, status, dark_mode FROM users WHERE id = :id LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}