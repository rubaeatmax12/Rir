<?php
require_once dirname(__DIR__, 2) . '/config/database.php';

// ১. নতুন নোটিফিকেশন তৈরি করা (যেমন লাইক, কমেন্ট বা ফ্রেন্ড রিকোয়েস্টে কল হবে)
function create_notification($notifier_id, $receiver_id, $entity_id, $type) {
    if ($notifier_id === $receiver_id) return false; // নিজেকে নিজে নোটিফিকেশন পাঠানোর দরকার নেই

    $db = (new Database())->getConnection();
    try {
        $query = "INSERT INTO notifications (notifier_id, receiver_id, entity_id, type, is_read) 
                  VALUES (:notifier_id, :receiver_id, :entity_id, :type, 0)";
        $stmt = $db->prepare($query);
        return $stmt->execute([
            ':notifier_id' => $notifier_id,
            ':receiver_id' => $receiver_id,
            ':entity_id' => $entity_id,
            ':type' => $type
        ]);
    } catch (PDOException $e) {
        error_log("Notification Error: " . $e->getMessage());
        return false;
    }
}

// ২. আনরিড নোটিফিকেশন সংখ্যা কাউন্ট করা
function get_unread_notifications_count($receiver_id) {
    $db = (new Database())->getConnection();
    try {
        $stmt = $db->prepare("SELECT COUNT(id) as unread_count FROM notifications WHERE receiver_id = :receiver_id AND is_read = 0");
        $stmt->execute([':receiver_id' => $receiver_id]);
        return $stmt->fetch()['unread_count'];
    } catch (PDOException $e) {
        return 0;
    }
}