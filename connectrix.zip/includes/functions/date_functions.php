<?php
// পোস্টের সৃষ্টির সময়কে 'টাইম এগো' ফরম্যাটে কনভার্ট করার ফাংশন
function get_time_ago($timestamp) {
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    
    $minutes      = round($seconds / 60 );           // value 60 is seconds
    $hours        = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec
    $days         = round($seconds / 86400);          //value 86400 is 24 hours * 60 minutes * 60 sec
    $weeks        = round($seconds / 604800);         //value 604800 is 7 days * 24 hours * 60 mins * 60 sec
    $months       = round($seconds / 2629440);        //value 2629440 is ((365+365+365+366)/4/12)*24*60*60
    $years        = round($seconds / 31553280);       //value 31553280 is ((365+365+365+366)/4)*24*60*60

    if ($seconds <= 60) {
        return "Just now";
    } else if ($minutes <= 60) {
        return ($minutes == 1) ? "1 min ago" : "$minutes mins ago";
    } else if ($hours <= 24) {
        return ($hours == 1) ? "1 hour ago" : "$hours hours ago";
    } else if ($days <= 7) {
        return ($days == 1) ? "Yesterday" : "$days days ago";
    } else if ($weeks <= 4.3) {
        return ($weeks == 1) ? "1 week ago" : "$weeks weeks ago";
    } else if ($months <= 12) {
        return ($months == 1) ? "1 month ago" : "$months months ago";
    } else {
        return ($years == 1) ? "1 year ago" : "$years years ago";
    }
}