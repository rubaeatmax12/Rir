<?php
// HTML এক্সপোজড এক্সএসএস (XSS) প্রতিরোধ করার জন্য
function clean_output($data) {
    if ($data === null) return '';
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// ইনপুট স্যানিটাইজেশন (স্ট্রিং ক্লিনিং)
function sanitize_input($data) {
    if ($data === null) return '';
    $data = trim($data);
    $data = stripslashes($data);
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// ইমেইল ভ্যালিডেশন
function is_valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// JSON রেসপন্স ফরমেটিং (AJAX এর জন্য রিয়ুজেবল)
function send_json_response($status, $message, $extra_data = []) {
    header('Content-Type: application/json; charset=utf-8');
    $response = array_merge([
        'status' => $status,
        'message' => $message
    ], $extra_data);
    echo json_encode($response);
    exit;
}