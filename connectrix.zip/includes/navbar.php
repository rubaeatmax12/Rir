<nav class="fb-navbar">
    <div class="navbar-left">
        <a href="<?php echo SITE_URL; ?>/feed/index.php" class="logo">c</a>
        <div class="search-box-container">
            <span class="search-icon-placeholder"><i class="fa-solid fa-magnifying-glass"></i></span>
            <input type="text" class="navbar-search-input" placeholder="Search Connectrix">
        </div>
    </div>
    
    <div class="navbar-right">
        <!-- Dark Mode Toggle Button -->
        <button class="nav-icon-btn" onclick="toggleDarkModeBtn()" title="Toggle Theme">
            <i id="darkModeIcon" class="fa-solid <?php echo ($current_user['dark_mode'] ?? 0) ? 'fa-sun' : 'fa-moon'; ?>"></i>
        </button>

        <!-- Messenger Shortcut -->
        <a href="<?php echo SITE_URL; ?>/chat/index.php" class="nav-icon-btn" title="Messenger">
            <i class="fa-solid fa-comment-dots"></i>
        </a>
        
        <!-- Notifications Link with Red Badge Counter -->
        <a href="<?php echo SITE_URL; ?>/notifications/index.php" class="nav-icon-btn" title="Notifications" style="position: relative;">
            <i class="fa-solid fa-bell"></i>
            <span class="nav-badge-counter" id="notificationBadgeCounter">0</span>
        </a>
        
        <!-- Dropdown / Profile -->
        <a href="<?php echo SITE_URL; ?>/profile/view.php?id=<?php echo $current_user['id']; ?>">
            <img class="nav-profile-pic" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($current_user['profile_pic']); ?>" alt="Profile">
        </a>

        <!-- Logout Button -->
        <a href="<?php echo SITE_URL; ?>/auth/logout.php" class="nav-icon-btn" title="Log Out" style="background-color: rgba(250, 56, 62, 0.1); color: var(--danger-color);">
            <i class="fa-solid fa-right-from-bracket"></i>
        </a>
    </div>
</nav>