<?php
require_once __DIR__ . '/functions/auth_functions.php';
redirect_if_not_logged_in();