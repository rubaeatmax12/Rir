<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request method.');
}

// CSRF ভ্যালিডেশন
if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security token mismatch. Refresh page.');
}

$email = sanitize_input($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    send_json_response('error', 'All fields are required.');
}

if (!is_valid_email($email)) {
    send_json_response('error', 'Invalid email address.');
}

$db = (new Database())->getConnection();

try {
    $query = "SELECT id, first_name, last_name, email, password, status FROM users WHERE email = :email LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();

    if ($stmt->rowCount() === 1) {
        $user = $stmt->fetch();
        
        if (password_verify($password, $user['password'])) {
            // অ্যাকাউন্ট অ্যাক্টিভ কিনা চেক করুন (পেন্ডিং বা সাসপেন্ডেড হলে লগইন রিডাইরেক্ট করা যাবে না)
            if ($user['status'] === 'Suspended') {
                send_json_response('error', 'Your account is suspended. Contact Support.');
            }
            
            // সেশন ডাটা সেট
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
            
            // রেজিস্ট্রেশন পেন্ডিং থাকলে অটো অ্যাক্টিভ করে দেওয়া হচ্ছে ডেমো প্রজেক্টের সুবিধার্থে
            if ($user['status'] === 'Pending') {
                $update_query = "UPDATE users SET status = 'Active' WHERE id = :id";
                $update_stmt = $db->prepare($update_query);
                $update_stmt->execute([':id' => $user['id']]);
            }

            send_json_response('success', 'Logged in successfully.', [
                'redirect' => SITE_URL . '/feed/index.php'
            ]);
        } else {
            send_json_response('error', 'Wrong email or password.');
        }
    } else {
        send_json_response('error', 'Wrong email or password.');
    }

} catch (PDOException $e) {
    send_json_response('error', 'Database error occurred: ' . $e->getMessage());
}