<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request method.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security token mismatch.');
}

$first_name = sanitize_input($_POST['first_name'] ?? '');
$last_name = sanitize_input($_POST['last_name'] ?? '');
$email = sanitize_input($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$gender = sanitize_input($_POST['gender'] ?? 'Male');
$birthday = sanitize_input($_POST['birthday'] ?? '');

// বেসিক ভ্যালিডেশন
if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($birthday)) {
    send_json_response('error', 'All fields are required.');
}

if (!is_valid_email($email)) {
    send_json_response('error', 'Please enter a valid email address.');
}

if (strlen($password) < 6) {
    send_json_response('error', 'Password must be at least 6 characters.');
}

$db = (new Database())->getConnection();

try {
    // ইমেইল ইতিমধ্যে রেজিস্টার্ড কিনা চেক করুন
    $check_query = "SELECT id FROM users WHERE email = :email LIMIT 1";
    $check_stmt = $db->prepare($check_query);
    $check_stmt->execute([':email' => $email]);

    if ($check_stmt->rowCount() > 0) {
        send_json_response('error', 'Email address is already in use.');
    }

    // পাসওয়ার্ড হ্যাশিং
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // ডাটাবেজে ইউজার ইন্সার্ট
    $insert_query = "INSERT INTO users (first_name, last_name, email, password, gender, birthday, status) 
                     VALUES (:first_name, :last_name, :email, :password, :gender, :birthday, 'Pending')";
    
    $insert_stmt = $db->prepare($insert_query);
    $result = $insert_stmt->execute([
        ':first_name' => $first_name,
        ':last_name' => $last_name,
        ':email' => $email,
        ':password' => $hashed_password,
        ':gender' => $gender,
        ':birthday' => $birthday
    ]);

    if ($result) {
        send_json_response('success', 'User registered successfully.');
    } else {
        send_json_response('error', 'Registration failed. Try again later.');
    }

} catch (PDOException $e) {
    send_json_response('error', 'Database system error: ' . $e->getMessage());
}