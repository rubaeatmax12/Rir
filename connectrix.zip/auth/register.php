<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
redirect_if_logged_in();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up for Connectrix</title>
    <link rel="stylesheet" href="../assets/css/base/variables.css">
    <link rel="stylesheet" href="../assets/css/components/buttons.css">
    <link rel="stylesheet" href="../assets/css/auth/login-form.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="brand-section">
            <a href="#" class="brand-logo">connectrix</a>
        </div>
        
        <div class="auth-card">
            <h2 style="margin-top:0; margin-bottom: 5px; font-size:25px;">Create a new account</h2>
            <p style="color:var(--text-secondary); margin-top:0; margin-bottom:15px; font-size:14px;">It's quick and easy.</p>
            
            <div id="errorBox" class="error-alert"></div>

            <form id="registerForm">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div style="display: flex; gap: 8px;">
                    <div class="auth-form-group" style="flex: 1;">
                        <input type="text" name="first_name" class="auth-input" placeholder="First name" required>
                    </div>
                    <div class="auth-form-group" style="flex: 1;">
                        <input type="text" name="last_name" class="auth-input" placeholder="Surname" required>
                    </div>
                </div>

                <div class="auth-form-group">
                    <input type="email" name="email" class="auth-input" placeholder="Email address" required autocomplete="email">
                </div>
                
                <div class="auth-form-group">
                    <input type="password" name="password" class="auth-input" placeholder="New password" required autocomplete="new-password">
                </div>

                <div class="auth-form-group">
                    <label style="font-size: 13px; color: var(--text-secondary); display:block; margin-bottom:5px;">Gender</label>
                    <div style="display:flex; gap:10px;">
                        <label style="flex:1; border: 1px solid var(--border-color); padding: 8px; border-radius: 4px; display:flex; justify-content:space-between; align-items:center;">
                            Male <input type="radio" name="gender" value="Male" required>
                        </label>
                        <label style="flex:1; border: 1px solid var(--border-color); padding: 8px; border-radius: 4px; display:flex; justify-content:space-between; align-items:center;">
                            Female <input type="radio" name="gender" value="Female">
                        </label>
                    </div>
                </div>

                <div class="auth-form-group">
                    <label style="font-size: 13px; color: var(--text-secondary); display:block; margin-bottom:5px;">Birthday</label>
                    <input type="date" name="birthday" class="auth-input" style="padding: 10px;" required>
                </div>

                <button type="submit" class="btn-fb-success btn-custom" style="width: 100%;">Sign Up</button>
            </form>

            <div class="auth-divider"></div>

            <div style="text-align: center;">
                <a href="login.php" class="auth-link" style="font-weight: 600;">Already have an account?</a>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const errorBox = document.getElementById('errorBox');
            errorBox.style.display = 'none';

            const formData = new FormData(this);

            fetch('ajax/register_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Registration Successful! Please log in.');
                    window.location.href = 'login.php';
                } else {
                    errorBox.textContent = data.message;
                    errorBox.style.display = 'block';
                }
            })
            .catch(err => {
                errorBox.textContent = 'Server connection error.';
                errorBox.style.display = 'block';
            });
        });
    </script>
</body>
</html>