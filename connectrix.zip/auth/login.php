<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
redirect_if_logged_in();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connectrix - Log In or Sign Up</title>
    <link rel="stylesheet" href="../assets/css/base/variables.css">
    <link rel="stylesheet" href="../assets/css/components/buttons.css">
    <link rel="stylesheet" href="../assets/css/auth/login-form.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="brand-section">
            <a href="#" class="brand-logo">connectrix</a>
            <div class="brand-tagline">Connect with friends and the world around you.</div>
        </div>
        
        <div class="auth-card">
            <!-- এরর হ্যান্ডলিং অ্যালার্ট -->
            <div id="errorBox" class="error-alert"></div>

            <form id="loginForm">
                <!-- CSRF Token -->
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div class="auth-form-group">
                    <input type="email" name="email" class="auth-input" placeholder="Email address" required autocomplete="email">
                </div>
                
                <div class="auth-form-group">
                    <input type="password" name="password" class="auth-input" placeholder="Password" required autocomplete="current-password">
                </div>
                
                <button type="submit" class="btn-fb-primary" style="width: 100%; height: 48px; font-size: 20px;">Log In</button>
            </form>

            <div class="auth-link-container">
                <a href="forgot_password.php" class="auth-link">Forgotten password?</a>
            </div>

            <div class="auth-divider"></div>

            <div style="text-align: center;">
                <a href="register.php" class="btn-fb-success btn-custom">Create new account</a>
            </div>
        </div>
    </div>

    <!-- AJAX দিয়ে লগইন প্রোসেস করার সাধারণ স্ক্রিপ্ট -->
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const errorBox = document.getElementById('errorBox');
            errorBox.style.display = 'none';

            const formData = new FormData(this);

            fetch('ajax/login_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirect;
                } else {
                    errorBox.textContent = data.message;
                    errorBox.style.display = 'block';
                }
            })
            .catch(err => {
                errorBox.textContent = 'Something went wrong. Please try again.';
                errorBox.style.display = 'block';
            });
        });
    </script>
</body>
</html>