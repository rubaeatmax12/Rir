<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';

$db = (new Database())->getConnection();

try {
    // ৩০ দিন বা তার বেশি পুরনো এবং ইতিমধ্যে পঠিত (is_read = 1) নোটিফিকেশনগুলো মুছে ফেলা
    $cleanup_stmt = $db->prepare("DELETE FROM notifications WHERE is_read = 1 AND created_at <= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $cleanup_stmt->execute();
    
    $deleted_rows = $cleanup_stmt->rowCount();
    echo "Cleaned up " . $deleted_rows . " old read notifications from database.";

} catch (PDOException $e) {
    error_log("Cron Notification Cleanup Error: " . $e->getMessage());
    echo "Cron notification cleanup failed.";
}