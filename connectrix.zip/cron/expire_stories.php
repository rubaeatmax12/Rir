<?php
// ক্রন স্ক্রিপ্ট সরাসরি CLI বা লোকালহোস্ট থেকে রান করার জন্য টাইম লিমিট তুলে নেওয়া
set_time_limit(0);

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';

$db = (new Database())->getConnection();

try {
    // ১. মেয়াদ শেষ হয়ে যাওয়া স্টোরিগুলোর ইমেজ ফাইল এবং আইডি খুঁজে বের করা
    $expired_stmt = $db->prepare("SELECT id, media_path FROM stories WHERE expires_at <= NOW()");
    $expired_stmt->execute();
    $expired_stories = $expired_stmt->fetchAll();

    if (count($expired_stories) > 0) {
        $upload_dir = dirname(__DIR__) . '/uploads/stories/';
        
        foreach ($expired_stories as $story) {
            $file_path = $upload_dir . $story['media_path'];
            
            // সার্ভার স্টোরেজ খালি করতে ফিজিক্যাল ইমেজ ফাইলটি মুছে ফেলা
            if (file_exists($file_path)) {
                unlink($file_path);
            }
            
            // ডাটাবেজ থেকে রেকর্ড ডিলিট করা
            $delete_stmt = $db->prepare("DELETE FROM stories WHERE id = :id");
            $delete_stmt->execute([':id' => $story['id']]);
        }
        
        echo count($expired_stories) . " expired stories have been cleared from database and storage.";
    } else {
        echo "No expired stories found to clean up.";
    }

} catch (PDOException $e) {
    error_log("Cron Expire Stories Error: " . $e->getMessage());
    echo "Cron run failed. Check server error logs.";
}