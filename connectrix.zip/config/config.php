<?php
// সেশন সিকিউরিটি সেটিংস সহ ইনিশিয়ালাইজেশন
if (session_status() == PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    // সেশন লাইফটাইম ৩০ দিন সেট করতে
    ini_set('session.gc_maxlifetime', 2592000); 
    session_set_cookie_params(2592000);
    session_start();
}

// টাইমজোন সেট করুন
date_default_timezone_set('Asia/Dhaka');

// রুট পাথ এবং ইউআরএল ডেফিনিশন
define('SITE_URL', 'http://localhost/connectrix'); // আপনার লোকালহোস্ট পাথ অনুযায়ী এটি পরিবর্তন করুন
define('ROOT_PATH', dirname(__DIR__));

// ফাইল আপলোড সেটিংস
define('MAX_FILE_SIZE', 8 * 1024 * 1024); // 8MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'mp4']);

// CSRF টোকেন জেনারেট এবং ভ্যালিডেশন হেল্পার
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function validate_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}