<?php
class Database {
    private $host = "localhost";
    private $db_name = "connectrix_db"; // আপনার ডাটাবেজ নাম
    private $username = "root";         // আপনার ডাটাবেজ ইউজারনেম
    private $password = "root";             // আপনার ডাটাবেজ পাসওয়ার্ড
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
            die("Database connection failed. Please check logs.");
        }
        return $this->conn;
    }
}