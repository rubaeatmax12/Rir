<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

$user_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

// ইউজারের কারেন্ট ডাটা লোড
$stmt = $db->prepare("SELECT bio, city, hometown, relationship FROM users WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $user_id]);
$details = $stmt->fetch();
?>
<div class="main-layout-container" style="max-width: 600px; display:block; padding: 16px;">
    <div style="background:var(--card-background); border-radius:8px; padding:20px; box-shadow:var(--shadow-sm);">
        <h2 style="margin-top:0; border-bottom:1px solid var(--divider-color); padding-bottom:12px;">Edit Profile</h2>
        
        <!-- সাকসেস/এরর নোটিফিকেশন এলার্ট -->
        <div id="editAlert" style="display:none; padding:12px; border-radius:6px; margin-bottom:15px; font-size:14px;"></div>

        <!-- ১. ছবি আপলোডের ফর্ম -->
        <form id="avatarUploadForm" enctype="multipart/form-data" style="margin-bottom:20px; border-bottom:1px solid var(--divider-color); padding-bottom:20px;">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <label style="font-weight:600; display:block; margin-bottom:8px;">Change Profile Picture</label>
            <input type="file" name="profile_pic" accept="image/*" required style="font-size:14px; margin-bottom:8px;">
            <button type="submit" class="btn-fb-primary btn-custom" style="font-size:13px; height:30px;">Upload Picture</button>
        </form>

        <!-- ২. বিস্তারিত তথ্য পরিবর্তনের ফর্ম -->
        <form id="profileDetailsForm">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div style="margin-bottom:12px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Bio</label>
                <textarea name="bio" style="width:100%; height:80px; padding:10px; border-radius:6px; border:1px solid var(--border-color); resize:none; font-family:var(--font-stack);" placeholder="Describe who you are..."><?php echo clean_output($current_user['bio']); ?></textarea>
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Current City</label>
                <input type="text" name="city" value="<?php echo clean_output($details['city']); ?>" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color); box-sizing:border-box;">
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Hometown</label>
                <input type="text" name="hometown" value="<?php echo clean_output($details['hometown']); ?>" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color); box-sizing:border-box;">
            </div>

            <div style="margin-bottom:20px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Relationship Status</label>
                <select name="relationship" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color);">
                    <option value="Single" <?php echo ($details['relationship'] === 'Single') ? 'selected' : ''; ?>>Single</option>
                    <option value="In a relationship" <?php echo ($details['relationship'] === 'In a relationship') ? 'selected' : ''; ?>>In a relationship</option>
                    <option value="Married" <?php echo ($details['relationship'] === 'Married') ? 'selected' : ''; ?>>Married</option>
                    <option value="Unspecified" <?php echo ($details['relationship'] === 'Unspecified') ? 'selected' : ''; ?>>Unspecified</option>
                </select>
            </div>

            <button type="submit" class="btn-fb-success btn-custom" style="width:100%; height:45px;">Save Changes</button>
        </form>
    </div>
</div>

<script>
    // ছবি আপলোড AJAX
    document.getElementById('avatarUploadForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const alertBox = document.getElementById('editAlert');
        const formData = new FormData(this);

        fetch('ajax/upload_avatar.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            alertBox.style.display = 'block';
            if(data.status === 'success') {
                alertBox.className = 'error-alert'; // সাকসেস স্টাইল ডাইনামিক
                alertBox.style.backgroundColor = '#d4edda';
                alertBox.style.color = '#155724';
                alertBox.style.border = '1px solid #c3e6cb';
                alertBox.textContent = data.message;
                setTimeout(() => window.location.reload(), 1500);
            } else {
                alertBox.style.backgroundColor = '#ffebe9';
                alertBox.style.color = 'var(--danger-color)';
                alertBox.textContent = data.message;
            }
        });
    });

    // বায়ো এবং এড্রেস আপডেট AJAX
    document.getElementById('profileDetailsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const alertBox = document.getElementById('editAlert');
        const formData = new FormData(this);

        fetch('ajax/update_profile.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            alertBox.style.display = 'block';
            if(data.status === 'success') {
                alertBox.style.backgroundColor = '#d4edda';
                alertBox.style.color = '#155724';
                alertBox.style.border = '1px solid #c3e6cb';
                alertBox.textContent = data.message;
                setTimeout(() => window.location.href = 'view.php', 1500);
            } else {
                alertBox.style.backgroundColor = '#ffebe9';
                alertBox.style.color = 'var(--danger-color)';
                alertBox.textContent = data.message;
            }
        });
    });
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>