<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

$user_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

try {
    // ইউজারের বর্তমান ডার্ক মোড স্ট্যাটাস চেক করা
    $stmt = $db->prepare("SELECT dark_mode FROM users WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $user_id]);
    $current_status = $stmt->fetch()['dark_mode'];

    // টগল ভ্যালু পরিবর্তন
    $new_status = ($current_status == 1) ? 0 : 1;

    $update_stmt = $db->prepare("UPDATE users SET dark_mode = :status WHERE id = :id");
    $update_stmt->execute([':status' => $new_status, ':id' => $user_id]);

    send_json_response('success', 'Dark mode updated.', ['dark_mode' => $new_status]);

} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}