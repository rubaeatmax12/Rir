<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request method.');
}

if (!is_logged_in()) {
    send_json_response('error', 'Authorization required.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security token expired. Please refresh page.');
}

$bio = sanitize_input($_POST['bio'] ?? '');
$city = sanitize_input($_POST['city'] ?? '');
$hometown = sanitize_input($_POST['hometown'] ?? '');
$relationship = sanitize_input($_POST['relationship'] ?? 'Unspecified');

$user_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

try {
    $query = "UPDATE users SET bio = :bio, city = :city, hometown = :hometown, relationship = :relationship WHERE id = :id";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        ':bio' => $bio,
        ':city' => $city,
        ':hometown' => $hometown,
        ':relationship' => $relationship,
        ':id' => $user_id
    ]);

    if ($result) {
        send_json_response('success', 'Profile updated successfully!');
    } else {
        send_json_response('error', 'No modifications made.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'System error: ' . $e->getMessage());
}