<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request method.');
}

if (!is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security mismatch.');
}

$file = $_FILES['profile_pic'] ?? null;

if ($file && $file['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        $upload_dir = dirname(__DIR__, 2) . '/uploads/profile/';
        
        // ডিরেক্টরি না থাকলে তৈরি করা হবে
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $new_filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $ext;
        $destination = $upload_dir . $new_filename;

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            $db = (new Database())->getConnection();
            $query = "UPDATE users SET profile_pic = :pic WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->execute([
                ':pic' => $new_filename,
                ':id' => $_SESSION['user_id']
            ]);

            send_json_response('success', 'Profile picture updated successfully!');
        } else {
            send_json_response('error', 'Failed to move uploaded file.');
        }
    } else {
        send_json_response('error', 'Only image files are allowed.');
    }
} else {
    send_json_response('error', 'Please select a valid file.');
}