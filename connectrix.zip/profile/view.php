<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

// অতিরিক্ত সিএসএস মডিউল লোড
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/profile/profile-header.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/profile/profile-tabs.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/post-card.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/comment-section.css">';

// কার প্রোফাইল দেখা হচ্ছে তার আইডি
$profile_id = intval($_GET['id'] ?? $_SESSION['user_id']);
$profile_user = get_user_data($profile_id);

if (!$profile_user) {
    echo '<div style="text-align:center; padding:50px;"><h2>User not found.</h2><a href="../feed/index.php">Go to Feed</a></div>';
    require_once dirname(__DIR__) . '/includes/footer.php';
    exit();
}

$is_my_profile = ($profile_id === $_SESSION['user_id']);
$db = (new Database())->getConnection();

// বর্তমান প্রোফাইল ইউজারের বিস্তারিত তথ্য
$intro_stmt = $db->prepare("SELECT city, hometown, relationship, birthday FROM users WHERE id = :id LIMIT 1");
$intro_stmt->execute([':id' => $profile_id]);
$intro_data = $intro_stmt->fetch();

// সিলেক্টেড ট্যাব নির্ধারণ (ডিফল্ট: posts)
$active_tab = sanitize_input($_GET['tab'] ?? 'posts');
?>

<div class="profile-container">
    <!-- Cover Photo -->
    <div class="cover-photo-container">
        <img class="cover-photo" src="<?php echo SITE_URL; ?>/uploads/cover/<?php echo clean_output($profile_user['cover_pic']); ?>" alt="Cover">
    </div>

    <!-- Profile Meta Info Header -->
    <div class="profile-meta-wrap">
        <div class="profile-avatar-holder">
            <img class="profile-main-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($profile_user['profile_pic']); ?>" alt="Avatar">
        </div>
        <div class="profile-user-details">
            <h1 class="profile-user-fullname"><?php echo clean_output($profile_user['first_name'] . ' ' . $profile_user['last_name']); ?></h1>
            <p class="profile-bio-text"><?php echo clean_output($profile_user['bio'] ?? 'No bio description added.'); ?></p>
        </div>
        <div class="profile-header-actions">
            <?php if ($is_my_profile): ?>
                <a href="edit.php" class="btn-fb-secondary btn-custom" style="gap:6px;"><i class="fa-solid fa-pen"></i> Edit Profile</a>
            <?php else: ?>
                <button class="btn-fb-primary btn-custom" style="gap:6px;"><i class="fa-solid fa-user-plus"></i> Add Friend</button>
                <button class="btn-fb-secondary btn-custom" style="gap:6px;"><i class="fa-solid fa-message"></i> Message</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Navigation Tabs Menu -->
    <ul class="profile-nav-tabs">
        <li class="profile-tab-item <?php echo ($active_tab === 'posts') ? 'active' : ''; ?>">
            <a href="view.php?id=<?php echo $profile_id; ?>&tab=posts">Posts</a>
        </li>
        <li class="profile-tab-item <?php echo ($active_tab === 'about') ? 'active' : ''; ?>">
            <a href="view.php?id=<?php echo $profile_id; ?>&tab=about">About</a>
        </li>
    </ul>
</div>

<div class="main-layout-container" style="max-width: 1095px; padding:0;">
    <div class="profile-body-layout" style="width: 100%;">
        
        <!-- Left Column: Intro Box -->
        <div class="profile-left-column">
            <div class="profile-intro-card">
                <h3 style="margin-top:0; margin-bottom:12px; font-size:18px;">Intro</h3>
                <ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:12px; font-size:14px;">
                    <?php if (!empty($intro_data['city'])): ?>
                        <li><i class="fa-solid fa-house-chimney" style="color:var(--text-secondary); width:20px;"></i> Lives in <strong><?php echo clean_output($intro_data['city']); ?></strong></li>
                    <?php endif; ?>
                    <?php if (!empty($intro_data['hometown'])): ?>
                        <li><i class="fa-solid fa-location-dot" style="color:var(--text-secondary); width:20px;"></i> From <strong><?php echo clean_output($intro_data['hometown']); ?></strong></li>
                    <?php endif; ?>
                    <?php if (!empty($intro_data['relationship']) && $intro_data['relationship'] !== 'Unspecified'): ?>
                        <li><i class="fa-solid fa-heart" style="color:var(--text-secondary); width:20px;"></i> Relationship: <strong><?php echo clean_output($intro_data['relationship']); ?></strong></li>
                    <?php endif; ?>
                    <li><i class="fa-solid fa-cake-candles" style="color:var(--text-secondary); width:20px;"></i> Birthday: <strong><?php echo date('F d, Y', strtotime($intro_data['birthday'])); ?></strong></li>
                </ul>
            </div>
        </div>

        <!-- Right Column: Content Area (ট্যাব অনুযায়ী লোড হবে) -->
        <div class="profile-right-column">
            <?php
            if ($active_tab === 'posts') {
                require_once __DIR__ . '/tabs/posts_tab.php';
            } elseif ($active_tab === 'about') {
                require_once __DIR__ . '/tabs/about_tab.php';
            }
            ?>
        </div>

    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/post/reaction-handler.js" defer></script>
<script src="<?php echo SITE_URL; ?>/assets/js/post/comment-handler.js" defer></script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>