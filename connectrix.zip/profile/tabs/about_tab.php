<div style="background-color: var(--card-background); padding: 20px; border-radius: 8px; box-shadow: var(--shadow-sm);">
    <h3 style="margin-top:0; margin-bottom:16px;">About Details</h3>
    <table style="width: 100%; border-collapse: collapse; font-size: 15px;">
        <tr style="border-bottom: 1px solid var(--divider-color);">
            <td style="padding:12px 0; color:var(--text-secondary); width: 150px;">Full Name</td>
            <td style="padding:12px 0;"><strong><?php echo clean_output($profile_user['first_name'] . ' ' . $profile_user['last_name']); ?></strong></td>
        </tr>
        <tr style="border-bottom: 1px solid var(--divider-color);">
            <td style="padding:12px 0; color:var(--text-secondary);">Email</td>
            <td style="padding:12px 0;"><?php echo clean_output($profile_user['email']); ?></td>
        </tr>
        <tr style="border-bottom: 1px solid var(--divider-color);">
            <td style="padding:12px 0; color:var(--text-secondary);">Current City</td>
            <td style="padding:12px 0;"><?php echo clean_output($intro_data['city'] ?? 'Not specified'); ?></td>
        </tr>
        <tr style="border-bottom: 1px solid var(--divider-color);">
            <td style="padding:12px 0; color:var(--text-secondary);">Hometown</td>
            <td style="padding:12px 0;"><?php echo clean_output($intro_data['hometown'] ?? 'Not specified'); ?></td>
        </tr>
        <tr style="border-bottom: 1px solid var(--divider-color);">
            <td style="padding:12px 0; color:var(--text-secondary);">Relationship</td>
            <td style="padding:12px 0;"><?php echo clean_output($intro_data['relationship'] ?? 'Not specified'); ?></td>
        </tr>
    </table>
</div>