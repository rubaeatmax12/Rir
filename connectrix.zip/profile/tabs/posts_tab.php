<?php
// প্রোফাইলের ইউজারের পোস্টগুলো তুলে আনা
$profile_posts_query = "SELECT p.id as post_id, p.content, p.created_at, p.user_id, u.first_name, u.last_name, u.profile_pic 
                        FROM posts p 
                        JOIN users u ON p.user_id = u.id 
                        WHERE p.user_id = :profile_id 
                        ORDER BY p.created_at DESC";
$profile_posts_stmt = $db->prepare($profile_posts_query);
$profile_posts_stmt->execute([':profile_id' => $profile_id]);
$profile_posts = $profile_posts_stmt->fetchAll();

if (count($profile_posts) > 0) {
    foreach ($profile_posts as $post) {
        // রিয়ুজেবল পোস্ট কার্ড রেন্ডার হচ্ছে
        require dirname(__DIR__, 2) . '/feed/partials/post_card_partial.php';
    }
} else {
    echo '<div style="background:var(--card-background); padding:30px; border-radius:8px; text-align:center; box-shadow:var(--shadow-sm); color:var(--text-secondary);">';
    echo '<i class="fa-solid fa-notes-medical" style="font-size:36px; margin-bottom:10px;"></i>';
    echo '<p>No posts published yet by this user.</p>';
    echo '</div>';
}