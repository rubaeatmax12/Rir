<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if (!is_logged_in()) {
    send_json_response('error', 'Unauthorized.');
}

$recipient_id = intval($_GET['recipient_id'] ?? 0);
$my_id = $_SESSION['user_id'];

if ($recipient_id === 0) {
    send_json_response('error', 'Invalid Recipient.');
}

$db = (new Database())->getConnection();

try {
    // কনভারসেশন আইডি খুঁজে বের করা
    $convo_query = "SELECT c.id FROM conversations c 
                    JOIN conversation_members m1 ON c.id = m1.conversation_id 
                    JOIN conversation_members m2 ON c.id = m2.conversation_id 
                    WHERE m1.user_id = :s_id AND m2.user_id = :r_id AND c.is_group = 0 LIMIT 1";
    $stmt = $db->prepare($convo_query);
    $stmt->execute([':s_id' => $my_id, ':r_id' => $recipient_id]);

    $all_messages = [];
    
    if ($stmt->rowCount() > 0) {
        $convo_id = $stmt->fetch()['id'];
        
        // সংশ্লিষ্ট মেসেজগুলো রিট্রিভ করা
        $msg_query = "SELECT sender_id, message, created_at FROM messages 
                      WHERE conversation_id = :convo ORDER BY created_at ASC";
        $msg_stmt = $db->prepare($msg_query);
        $msg_stmt->execute([':convo' => $convo_id]);
        $all_messages = $msg_stmt->fetchAll();
    }

    send_json_response('success', 'Messages loaded.', ['messages' => $all_messages, 'my_id' => $my_id]);

} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}