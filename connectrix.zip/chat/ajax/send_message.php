<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security token expired.');
}

$recipient_id = intval($_POST['recipient_id'] ?? 0);
$message = sanitize_input($_POST['message'] ?? '');
$sender_id = $_SESSION['user_id'];

if ($recipient_id === 0 || empty($message)) {
    send_json_response('error', 'Message cannot be empty.');
}

$db = (new Database())->getConnection();

try {
    // ১. আগের কোনো কনভারসেশন আছে কিনা চেক করা
    $convo_id = 0;
    $convo_check = "SELECT c.id FROM conversations c 
                    JOIN conversation_members m1 ON c.id = m1.conversation_id 
                    JOIN conversation_members m2 ON c.id = m2.conversation_id 
                    WHERE m1.user_id = :s_id AND m2.user_id = :r_id AND c.is_group = 0 LIMIT 1";
    $stmt = $db->prepare($convo_check);
    $stmt->execute([':s_id' => $sender_id, ':r_id' => $recipient_id]);
    
    if ($stmt->rowCount() > 0) {
        $convo_id = $stmt->fetch()['id'];
    } else {
        // নতুন কনভারসেশন তৈরি
        $db->beginTransaction();
        
        $db->exec("INSERT INTO conversations (is_group) VALUES (0)");
        $convo_id = $db->lastInsertId();
        
        // মেম্বার এন্ট্রি
        $stmt_mem = $db->prepare("INSERT INTO conversation_members (conversation_id, user_id) VALUES (:convo, :user)");
        $stmt_mem->execute([':convo' => $convo_id, ':user' => $sender_id]);
        $stmt_mem->execute([':convo' => $convo_id, ':user' => $recipient_id]);
        
        $db->commit();
    }

    // ২. মেসেজ টেবিলে মেসেজ ইন্সার্ট করা
    $msg_query = "INSERT INTO messages (conversation_id, sender_id, message) VALUES (:convo, :sender, :msg)";
    $msg_stmt = $db->prepare($msg_query);
    $result = $msg_stmt->execute([
        ':convo' => $convo_id,
        ':sender' => $sender_id,
        ':msg' => $message
    ]);

    if ($result) {
        send_json_response('success', 'Message sent successfully.');
    } else {
        send_json_response('error', 'Failed to store message.');
    }

} catch (PDOException $e) {
    if ($db->inTransaction()) $db->rollBack();
    send_json_response('error', 'DB error: ' . $e->getMessage());
}