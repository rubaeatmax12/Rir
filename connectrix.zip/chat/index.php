<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/chat/chat-inbox.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/chat/chat-message.css">';

$my_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

// বন্ধুদের লিস্ট রিট্রিভ করা (যাদের সাথে চ্যাট স্টার্ট করা যাবে)
$convo_query = "SELECT u.id as friend_id, u.first_name, u.last_name, u.profile_pic 
                FROM friends f 
                JOIN users u ON (f.user_one = u.id OR f.user_two = u.id) 
                WHERE (f.user_one = :my_id OR f.user_two = :my_id) 
                AND f.status = 'Accepted' AND u.id != :my_id";
$convo_stmt = $db->prepare($convo_query);
$convo_stmt->execute([':my_id' => $my_id]);
$all_friends = $convo_stmt->fetchAll();
?>

<div class="messenger-container">
    <!-- চ্যাট সাইডবার (বাম পাশ) -->
    <div class="chat-sidebar">
        <div class="chat-sidebar-header">Chats</div>
        <ul class="conversation-list">
            <?php if (count($all_friends) > 0): ?>
                <?php foreach ($all_friends as $friend): ?>
                    <li class="conversation-item" onclick="loadActiveChat(<?php echo $friend['friend_id']; ?>, '<?php echo clean_output($friend['first_name'] . ' ' . $friend['last_name']); ?>', '<?php echo SITE_URL . '/uploads/profile/' . $friend['profile_pic']; ?>', this)">
                        <img class="convo-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($friend['profile_pic']); ?>" alt="User">
                        <div class="convo-details">
                            <div class="convo-name"><?php echo clean_output($friend['first_name'] . ' ' . $friend['last_name']); ?></div>
                            <div class="convo-preview">Click to start chatting...</div>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding:20px; text-align:center; color:var(--text-secondary); font-size:14px;">Make friends first to chat!</div>
            <?php endif; ?>
        </ul>
    </div>

    <!-- চ্যাট উইন্ডো (ডান পাশ) -->
    <div class="chat-window" id="emptyChatPlaceholder" style="display:flex; align-items:center; justify-content:center; color:var(--text-secondary); height:100%;">
        <div style="text-align:center;">
            <i class="fa-solid fa-comments" style="font-size:64px; color:var(--divider-color); margin-bottom:12px;"></i>
            <h3>Select a Conversation</h3>
            <p>Select a friend from the list to start messaging.</p>
        </div>
    </div>

    <!-- চ্যাট উইন্ডো (ডাইনামিকালি লোড হবে) -->
    <div class="chat-window" id="activeChatWindow" style="display:none;">
        <div class="chat-window-header">
            <img id="activeChatAvatar" class="convo-avatar" src="" alt="user">
            <div>
                <div id="activeChatName" class="convo-name">User Name</div>
                <div style="font-size:12px; color:var(--online-indicator);"><i class="fa-solid fa-circle"></i> Active now</div>
            </div>
        </div>

        <!-- মেসেজ স্ক্রোল এরিয়া -->
        <div class="messages-area" id="messagesScroller"></div>

        <!-- মেসেজ ইনপুট বার -->
        <div class="chat-input-bar">
            <form id="messengerSendForm" class="chat-input-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" id="recipientId" name="recipient_id" value="">
                <input type="text" id="messageField" name="message" class="chat-input-field" placeholder="Type a message..." autocomplete="off" required>
                <button type="submit" class="btn-fb-primary btn-custom" style="width:40px; height:40px; border-radius:50%; padding:0;"><i class="fa-solid fa-paper-plane"></i></button>
            </form>
        </div>
    </div>
</div>

<!-- জাভাস্ক্রিপ্ট মডিউলস ইমপোর্ট -->
<script src="<?php echo SITE_URL; ?>/assets/js/chat/send-message.js" defer></script>
<script src="<?php echo SITE_URL; ?>/assets/js/chat/fetch-messages-poll.js" defer></script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>