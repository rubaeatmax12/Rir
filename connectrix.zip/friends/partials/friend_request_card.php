<div class="friend-card" id="req-card-<?php echo $request['sender_id']; ?>">
    <img class="friend-card-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($request['profile_pic']); ?>" alt="User">
    <div class="friend-card-info">
        <a href="<?php echo SITE_URL; ?>/profile/view.php?id=<?php echo $request['sender_id']; ?>" class="friend-card-name">
            <?php echo clean_output($request['first_name'] . ' ' . $request['last_name']); ?>
        </a>
        <div class="friend-card-actions">
            <button class="btn-fb-primary btn-custom" onclick="acceptFriendRequest(<?php echo $request['sender_id']; ?>, 'req-card-<?php echo $request['sender_id']; ?>')">Confirm</button>
            <button class="btn-fb-secondary btn-custom" onclick="rejectFriendRequest(<?php echo $request['sender_id']; ?>, 'req-card-<?php echo $request['sender_id']; ?>')">Delete</button>
        </div>
    </div>
</div>