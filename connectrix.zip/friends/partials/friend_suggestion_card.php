<div class="friend-card" id="suggest-card-<?php echo $suggest['id']; ?>">
    <img class="friend-card-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($suggest['profile_pic']); ?>" alt="User">
    <div class="friend-card-info">
        <a href="<?php echo SITE_URL; ?>/profile/view.php?id=<?php echo $suggest['id']; ?>" class="friend-card-name">
            <?php echo clean_output($suggest['first_name'] . ' ' . $suggest['last_name']); ?>
        </a>
        <div class="friend-card-actions">
            <button class="btn-fb-primary btn-custom" onclick="sendFriendRequest(<?php echo $suggest['id']; ?>, this)">Add Friend</button>
            <button class="btn-fb-secondary btn-custom" onclick="document.getElementById('suggest-card-<?php echo $suggest['id']; ?>').remove()">Remove</button>
        </div>
    </div>
</div>