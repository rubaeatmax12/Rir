<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/friends/friend-card.css">';

$user_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

// ১. ইনকামিং রিকোয়েস্টগুলো কুয়েরি করা (যারা আমাকে রিকোয়েস্ট পাঠিয়েছে)
$requests_query = "SELECT f.id as friendship_id, u.id as sender_id, u.first_name, u.last_name, u.profile_pic 
                   FROM friends f 
                   JOIN users u ON f.action_user_id = u.id 
                   WHERE ((f.user_one = :uid AND f.user_two = u.id) OR (f.user_two = :uid AND f.user_one = u.id)) 
                   AND f.status = 'Pending' AND f.action_user_id != :uid";
$requests_stmt = $db->prepare($requests_query);
$requests_stmt->execute([':uid' => $user_id]);
$pending_requests = $requests_stmt->fetchAll();

// ২. ফ্রেন্ড সাজেশন কুয়েরি করা (যারা এখনও আমার ফ্রেন্ড তালিকায় নেই এবং আমি রিকোয়েস্ট পাঠাইনি)
$suggestions_query = "SELECT id, first_name, last_name, profile_pic 
                      FROM users 
                      WHERE id != :uid 
                      AND id NOT IN (
                          SELECT CASE WHEN user_one = :uid THEN user_two ELSE user_one END 
                          FROM friends 
                          WHERE user_one = :uid OR user_two = :uid
                      ) LIMIT 10";
$suggestions_stmt = $db->prepare($suggestions_query);
$suggestions_stmt->execute([':uid' => $user_id]);
$friend_suggestions = $suggestions_stmt->fetchAll();
?>

<div class="main-layout-container" style="max-width: 1100px; display: block; padding: 16px;">
    
    <!-- ফ্রেন্ড রিকোয়েস্ট সেকশন -->
    <div style="margin-bottom: 32px;">
        <h2 style="margin-top:0;">Friend Requests (<?php echo count($pending_requests); ?>)</h2>
        <?php if (count($pending_requests) > 0): ?>
            <div class="friends-layout-grid">
                <?php foreach ($pending_requests as $request) {
                    require __DIR__ . '/partials/friend_request_card.php';
                } ?>
            </div>
        <?php else: ?>
            <p style="color: var(--text-secondary); font-size: 15px;">No pending friend requests.</p>
        <?php endif; ?>
    </div>

    <hr style="border: 0; border-top: 1px solid var(--divider-color); margin: 24px 0;">

    <!-- ফ্রেন্ড সাজেশন সেকশন (People you may know) -->
    <div>
        <h2>People You May Know</h2>
        <?php if (count($friend_suggestions) > 0): ?>
            <div class="friends-layout-grid">
                <?php foreach ($friend_suggestions as $suggest) {
                    require __DIR__ . '/partials/friend_suggestion_card.php';
                } ?>
            </div>
        <?php else: ?>
            <p style="color: var(--text-secondary); font-size: 15px;">No suggestions available right now.</p>
        <?php endif; ?>
    </div>

</div>

<!-- ফ্রেন্ড রিকোয়েস্ট রিয়েল-টাইম AJAX স্ক্রিপ্ট -->
<script>
function sendFriendRequest(targetUserId, btn) {
    const formData = new FormData();
    formData.append('target_user_id', targetUserId);
    formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');

    btn.disabled = true;
    btn.textContent = 'Sending...';

    fetch('ajax/send_request.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            btn.className = 'btn-fb-secondary btn-custom';
            btn.textContent = 'Request Sent';
        } else {
            alert(data.message);
            btn.disabled = false;
            btn.textContent = 'Add Friend';
        }
    });
}

function acceptFriendRequest(targetUserId, cardId) {
    const formData = new FormData();
    formData.append('target_user_id', targetUserId);
    formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');

    fetch('ajax/accept_request.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            document.getElementById(cardId).innerHTML = `
                <div style="padding: 16px; text-align: center; color: var(--secondary-color); font-weight: 600;">
                    <i class="fa-solid fa-circle-check"></i> Request Accepted
                </div>
            `;
            setTimeout(() => document.getElementById(cardId).remove(), 2000);
        } else {
            alert(data.message);
        }
    });
}

function rejectFriendRequest(targetUserId, cardId) {
    const formData = new FormData();
    formData.append('target_user_id', targetUserId);
    formData.append('csrf_token', '<?php echo $_SESSION['csrf_token']; ?>');

    fetch('ajax/reject_request.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            document.getElementById(cardId).innerHTML = `
                <div style="padding: 16px; text-align: center; color: var(--text-secondary);">
                    Request Removed
                </div>
            `;
            setTimeout(() => document.getElementById(cardId).remove(), 2000);
        } else {
            alert(data.message);
        }
    });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>