<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/notification_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security mismatched.');
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);
$my_id = $_SESSION['user_id'];

if ($target_user_id === 0 || $target_user_id === $my_id) {
    send_json_response('error', 'Invalid User ID.');
}

// ডাটাবেজ ডুপ্লিকেশন এড়াতে সবসময় ছোট আইডি user_one এবং বড় আইডি user_two তে বসবে
$user_one = min($my_id, $target_user_id);
$user_two = max($my_id, $target_user_id);

$db = (new Database())->getConnection();

try {
    // আগের কোনো রিকোয়েস্ট আছে কিনা চেক করা
    $stmt = $db->prepare("SELECT id FROM friends WHERE user_one = :u1 AND user_two = :u2 LIMIT 1");
    $stmt->execute([':u1' => $user_one, ':u2' => $user_two]);

    if ($stmt->rowCount() > 0) {
        send_json_response('error', 'Relation already exists.');
    }

    $insert_query = "INSERT INTO friends (user_one, user_two, status, action_user_id) VALUES (:u1, :u2, 'Pending', :action_id)";
    $insert_stmt = $db->prepare($insert_query);
    $result = $insert_stmt->execute([
        ':u1' => $user_one,
        ':u2' => $user_two,
        ':action_id' => $my_id
    ]);

    if ($result) {
        // ফ্রেন্ড রিকোয়েস্টের নোটিফিকেশন পাঠানো
        create_notification($my_id, $target_user_id, $my_id, 'Friend_Request');

        send_json_response('success', 'Friend request sent.');
    } else {
        send_json_response('error', 'Failed to send request.');
    }

} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}