<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/notification_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security token expired.');
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);
$my_id = $_SESSION['user_id'];

$user_one = min($my_id, $target_user_id);
$user_two = max($my_id, $target_user_id);

$db = (new Database())->getConnection();

try {
    $update_query = "UPDATE friends SET status = 'Accepted', action_user_id = :my_id 
                     WHERE user_one = :u1 AND user_two = :u2 AND status = 'Pending'";
    $stmt = $db->prepare($update_query);
    $result = $stmt->execute([
        ':my_id' => $my_id,
        ':u1' => $user_one,
        ':u2' => $user_two
    ]);

    if ($result && $stmt->rowCount() > 0) {
        // ফ্রেন্ড রিকোয়েস্ট একসেপ্টের নোটিফিকেশন পাঠানো
        create_notification($my_id, $target_user_id, $my_id, 'Accept_Request');

        send_json_response('success', 'Friend request accepted.');
    } else {
        send_json_response('error', 'No pending request found.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}