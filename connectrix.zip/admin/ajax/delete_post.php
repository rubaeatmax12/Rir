<?php
require_once dirname(__DIR__) . '/admin_auth_check.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request.');
}

$post_id = intval($_POST['post_id'] ?? 0);
$report_id = intval($_POST['report_id'] ?? 0);

if ($post_id === 0 || $report_id === 0) {
    send_json_response('error', 'Invalid IDs.');
}

$db = (new Database())->getConnection();

try {
    $db->beginTransaction();

    // ১. মূল পোস্ট মুছে ফেলা
    $stmt1 = $db->prepare("DELETE FROM posts WHERE id = :post_id");
    $stmt1->execute([':post_id' => $post_id]);

    // ২. সংশ্লিষ্ট রিপোর্ট মুছে ফেলা
    $stmt2 = $db->prepare("DELETE FROM reports WHERE id = :report_id");
    $stmt2->execute([':report_id' => $report_id]);

    $db->commit();
    send_json_response('success', 'Post and report resolved successfully!');
} catch (PDOException $e) {
    if ($db->inTransaction()) $db->rollBack();
    send_json_response('error', 'DB execution failed: ' . $e->getMessage());
}