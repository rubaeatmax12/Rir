<?php
require_once dirname(__DIR__) . '/admin_auth_check.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request.');
}

$user_id = intval($_POST['user_id'] ?? 0);
$current_status = sanitize_input($_POST['current_status'] ?? '');

if ($user_id === 0 || empty($current_status)) {
    send_json_response('error', 'Invalid arguments.');
}

$new_status = ($current_status === 'Suspended') ? 'Active' : 'Suspended';

$db = (new Database())->getConnection();

try {
    $stmt = $db->prepare("UPDATE users SET status = :status WHERE id = :id");
    $result = $stmt->execute([':status' => $new_status, ':id' => $user_id]);

    if ($result) {
        send_json_response('success', 'User status toggled.', ['new_status' => $new_status]);
    } else {
        send_json_response('error', 'Failed to update user status.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}