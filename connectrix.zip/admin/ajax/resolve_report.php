<?php
require_once dirname(__DIR__) . '/admin_auth_check.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request.');
}

$report_id = intval($_POST['report_id'] ?? 0);

if ($report_id === 0) {
    send_json_response('error', 'Invalid ID.');
}

$db = (new Database())->getConnection();

try {
    // পোস্ট ডিলিট না করে শুধুমাত্র রিপোর্টটি ডাটাবেজ থেকে মুছে ফেলা
    $stmt = $db->prepare("DELETE FROM reports WHERE id = :report_id");
    $result = $stmt->execute([':report_id' => $report_id]);

    if ($result) {
        send_json_response('success', 'Report resolved.');
    } else {
        send_json_response('error', 'Could not resolve report.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'DB execution failed: ' . $e->getMessage());
}