<?php
require_once __DIR__ . '/admin_auth_check.php';
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/admin/dashboard.css">';

$db = (new Database())->getConnection();

// এডমিন ছাড়া সাধারণ সব ইউজারদের তুলে নিয়ে আসা
$users_stmt = $db->query("SELECT id, first_name, last_name, email, status, created_at FROM users WHERE is_admin = 0 ORDER BY created_at DESC");
$all_users = $users_stmt->fetchAll();
?>

<div class="admin-layout-container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <h2 style="margin:0;"><i class="fa-solid fa-users-gear"></i> Manage Users</h2>
        <a href="dashboard.php" class="btn-fb-secondary btn-custom"><i class="fa-solid fa-gauge-high"></i> Dashboard Home</a>
    </div>

    <div class="admin-table-card">
        <div class="admin-table-header">Registered Members List</div>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Email Address</th>
                    <th>Status</th>
                    <th>Joined Date</th>
                    <th style="text-align:right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($all_users as $user): 
                    $status_class = 'status-active';
                    if ($user['status'] === 'Pending') $status_class = 'status-pending';
                    if ($user['status'] === 'Suspended') $status_class = 'status-suspended';
                    ?>
                    <tr id="user-row-<?php echo $user['id']; ?>">
                        <td>#<?php echo $user['id']; ?></td>
                        <td><strong><?php echo clean_output($user['first_name'] . ' ' . $user['last_name']); ?></strong></td>
                        <td><?php echo clean_output($user['email']); ?></td>
                        <td><span id="badge-<?php echo $user['id']; ?>" class="status-badge <?php echo $status_class; ?>"><?php echo $user['status']; ?></span></td>
                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        <td style="text-align:right; display:flex; gap:8px; justify-content:flex-end;">
                            <button id="btn-suspend-<?php echo $user['id']; ?>" onclick="toggleUserStatus(<?php echo $user['id']; ?>, '<?php echo $user['status']; ?>', this)" class="btn-fb-primary btn-custom" style="height:30px; font-size:12px; background-color: <?php echo ($user['status'] === 'Suspended') ? 'var(--secondary-color)' : 'var(--danger-color)'; ?>;">
                                <?php echo ($user['status'] === 'Suspended') ? '<i class="fa-solid fa-user-check"></i> Activate' : '<i class="fa-solid fa-user-slash"></i> Suspend'; ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function toggleUserStatus(userId, currentStatus, btn) {
    btn.disabled = true;
    const formData = new FormData();
    formData.append('user_id', userId);
    formData.append('current_status', currentStatus);

    fetch('ajax/user_action.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const badge = document.getElementById(`badge-${userId}`);
            
            if (data.new_status === 'Suspended') {
                badge.className = 'status-badge status-suspended';
                badge.textContent = 'Suspended';
                btn.innerHTML = '<i class="fa-solid fa-user-check"></i> Activate';
                btn.style.backgroundColor = 'var(--secondary-color)';
            } else {
                badge.className = 'status-badge status-active';
                badge.textContent = 'Active';
                btn.innerHTML = '<i class="fa-solid fa-user-slash"></i> Suspend';
                btn.style.backgroundColor = 'var(--danger-color)';
            }
            
            // ডাটা আপডেট সচল রাখতে ইনলাইন স্ট্যাটাস প্যারামিটার রিলোড ছাড়াই মেমোরি বদল
            btn.setAttribute('onclick', `toggleUserStatus(${userId}, '${data.new_status}', this)`);
            btn.disabled = false;
        } else {
            alert(data.message);
            btn.disabled = false;
        }
    });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>