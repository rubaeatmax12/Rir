<?php
require_once __DIR__ . '/admin_auth_check.php';
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/admin/dashboard.css">';

$db = (new Database())->getConnection();

// ১. পরিসংখ্যানের জন্য কুয়েরি চালানো
$users_count = $db->query("SELECT COUNT(id) FROM users")->fetchColumn();
$posts_count = $db->query("SELECT COUNT(id) FROM posts")->fetchColumn();
$reports_count = $db->query("SELECT COUNT(id) FROM reports WHERE status = 'Pending'")->fetchColumn();

// ২. পেন্ডিং রিপোর্টের তালিকা নিয়ে আসা
$reports_stmt = $db->query("SELECT r.id as report_id, r.reason, r.created_at, u.first_name, u.last_name, p.content, p.id as post_id 
                            FROM reports r 
                            JOIN users u ON r.reporter_id = u.id 
                            JOIN posts p ON r.reported_post_id = p.id 
                            WHERE r.status = 'Pending' ORDER BY r.created_at DESC");
$all_reports = $reports_stmt->fetchAll();
?>

<div class="admin-layout-container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <h2 style="margin:0;"><i class="fa-solid fa-gauge-high"></i> Super-Admin Dashboard</h2>
        <a href="users.php" class="btn-fb-primary btn-custom"><i class="fa-solid fa-users-gear"></i> Manage Users</a>
    </div>

    <!-- ৩টি পরিসংখ্যান কার্ড গ্রিড -->
    <div class="admin-stats-grid">
        <div class="admin-stat-card">
            <i class="fa-solid fa-users admin-stat-icon"></i>
            <div>
                <h3 class="admin-stat-number"><?php echo $users_count; ?></h3>
                <span class="admin-stat-label">Total Users</span>
            </div>
        </div>
        <div class="admin-stat-card">
            <i class="fa-solid fa-file-invoice admin-stat-icon" style="color:var(--secondary-color);"></i>
            <div>
                <h3 class="admin-stat-number"><?php echo $posts_count; ?></h3>
                <span class="admin-stat-label">Total Posts</span>
            </div>
        </div>
        <div class="admin-stat-card">
            <i class="fa-solid fa-triangle-exclamation admin-stat-icon" style="color:var(--danger-color);"></i>
            <div>
                <h3 class="admin-stat-number"><?php echo $reports_count; ?></h3>
                <span class="admin-stat-label">Pending Reports</span>
            </div>
        </div>
    </div>

    <!-- রিপোর্ট ম্যানেজমেন্ট সেকশন -->
    <div class="admin-table-card">
        <div class="admin-table-header" style="color: var(--danger-color);"><i class="fa-solid fa-circle-exclamation"></i> Reported Posts Queue</div>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Reporter</th>
                    <th>Post Content Preview</th>
                    <th>Reason</th>
                    <th>Date</th>
                    <th style="text-align:right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($all_reports) > 0): ?>
                    <?php foreach ($all_reports as $report): ?>
                        <tr id="report-row-<?php echo $report['report_id']; ?>">
                            <td><strong><?php echo clean_output($report['first_name'] . ' ' . $report['last_name']); ?></strong></td>
                            <td style="max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?php echo clean_output($report['content']); ?></td>
                            <td><span style="color:var(--danger-color);"><?php echo clean_output($report['reason']); ?></span></td>
                            <td><?php echo date('M d, Y', strtotime($report['created_at'])); ?></td>
                            <td style="text-align:right; display:flex; gap:8px; justify-content:flex-end;">
                                <button onclick="deletePost(<?php echo $report['post_id']; ?>, <?php echo $report['report_id']; ?>, this)" class="btn-fb-primary btn-custom" style="height:30px; font-size:12px; background-color:var(--danger-color);"><i class="fa-solid fa-trash"></i> Delete Post</button>
                                <button onclick="resolveReport(<?php echo $report['report_id']; ?>, this)" class="btn-fb-secondary btn-custom" style="height:30px; font-size:12px;"><i class="fa-solid fa-circle-check"></i> Ignore</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align:center; padding:30px; color:var(--text-secondary);">No active reports found. Everything is clean!</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// রিপোর্ট বাস্ট ডিলিট AJAX
function deletePost(postId, reportId, btn) {
    if(!confirm('Are you sure you want to delete this post? This action cannot be undone.')) return;
    
    btn.disabled = true;
    const formData = new FormData();
    formData.append('post_id', postId);
    formData.append('report_id', reportId);

    fetch('ajax/delete_post.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById(`report-row-${reportId}`).remove();
        } else {
            alert(data.message);
            btn.disabled = false;
        }
    });
}

function resolveReport(reportId, btn) {
    btn.disabled = true;
    const formData = new FormData();
    formData.append('report_id', reportId);

    fetch('ajax/resolve_report.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            document.getElementById(`report-row-${reportId}`).remove();
        } else {
            alert(data.message);
            btn.disabled = false;
        }
    });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>