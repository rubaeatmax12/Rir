<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';

// লগইন করা না থাকলে রিডাইরেক্ট
redirect_if_not_logged_in();

// লগইন করা ইউজারের এডমিন স্ট্যাটাস চেক করা
$user_check = get_user_data($_SESSION['user_id']);

if (!$user_check || $user_check['is_admin'] != 1) {
    // এডমিন না হলে ৪MD (Forbidden) মেসেজ দিয়ে বিদায় করা হবে
    header("HTTP/1.1 403 Forbidden");
    echo "<div style='text-align:center; padding:50px;'><h1>403 Forbidden</h1><p>You do not have administrative privileges to access this area.</p><a href='../feed/index.php'>Go Back to Home Feed</a></div>";
    exit();
}