document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('.navbar-search-input');
    const searchContainer = document.querySelector('.search-box-container');

    if (!searchInput || !searchContainer) return;

    // ডাইনামিকালি রেজাল্ট ড্রপডাউন প্যানেলটি সার্চ কন্টেইনারে তৈরি ও যুক্ত করা হচ্ছে
    const resultsPanel = document.createElement('div');
    resultsPanel.className = 'live-search-results-panel';
    searchContainer.appendChild(resultsPanel);

    // টাইপ করা শুরু করলে এপিআই ট্রিগার করা
    searchInput.addEventListener('input', function() {
        const query = searchInput.value.trim();

        if (query.length === 0) {
            resultsPanel.innerHTML = '';
            resultsPanel.style.display = 'none';
            return;
        }

        fetch(`/connectrix/search/live_search.php?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                resultsPanel.innerHTML = '';
                resultsPanel.style.display = 'block';

                if (data.results.length > 0) {
                    data.results.forEach(user => {
                        const item = document.createElement('a');
                        item.className = 'search-result-item';
                        item.href = `/connectrix/profile/view.php?id=${user.id}`;
                        item.innerHTML = `
                            <img class="search-result-avatar" src="/connectrix/uploads/profile/${user.profile_pic}" alt="user">
                            <span class="search-result-name">${escapeHTML(user.first_name)} ${escapeHTML(user.last_name)}</span>
                        `;
                        resultsPanel.appendChild(item);
                    });
                } else {
                    resultsPanel.innerHTML = '<div class="search-no-result">No results found</div>';
                }
            }
        })
        .catch(err => console.error('Error fetching search results:', err));
    });

    // সার্চ বক্সের বাইরে ক্লিক করলে রেজাল্ট প্যানেল বন্ধ করা
    document.addEventListener('click', function(e) {
        if (!searchContainer.contains(e.target)) {
            resultsPanel.style.display = 'none';
        }
    });

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            }[tag] || tag)
        );
    }
});