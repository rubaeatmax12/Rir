let storyTimeout;
let progressInterval;

function openStoryViewer(mediaSrc, userName, userAvatar) {
    const overlay = document.getElementById('storyViewerOverlay');
    const viewerMedia = document.getElementById('viewerStoryMedia');
    const viewerName = document.getElementById('viewerUserName');
    const viewerAvatar = document.getElementById('viewerUserAvatar');
    const progressBarFill = document.getElementById('storyProgressBarFill');

    // ডাটা বসানো
    viewerMedia.src = mediaSrc;
    viewerName.textContent = userName;
    viewerAvatar.src = userAvatar;
    progressBarFill.style.width = '0%';

    overlay.style.display = 'flex';

    // ৫ সেকেন্ড প্লেব্যাক এবং প্রোগ্রেস বার রানিং
    let progress = 0;
    clearInterval(progressInterval);
    progressInterval = setInterval(() => {
        progress += 2; // প্রতি ১০০ মিলি-সেকেন্ডে প্রোগ্রেস বাড়বে
        progressBarFill.style.width = `${progress}%`;
        if (progress >= 100) {
            clearInterval(progressInterval);
        }
    }, 100);

    // ৫ সেকেন্ড পর অটোমেটিক ক্লোজ
    clearTimeout(storyTimeout);
    storyTimeout = setTimeout(() => {
        closeStoryViewer();
    }, 5000);
}

function closeStoryViewer() {
    document.getElementById('storyViewerOverlay').style.display = 'none';
    clearInterval(progressInterval);
    clearTimeout(storyTimeout);
}