function openReportModal(postId) {
    const reason = prompt("Why are you reporting this post?\n1. Spam\n2. Harassment\n3. Hate Speech\n4. Violence");
    
    if (reason === null) return; // ইউজার ক্যান্সেল করলে থেমে যাবে
    
    const cleanReason = reason.trim();
    if (cleanReason === "") {
        alert("Please provide a reason to submit report.");
        return;
    }

    // টেম্পোরারি CSRF টোকেন জোগাড় করা (মেটা ট্যাগ বা ফর্ম থেকে)
    const csrfToken = document.querySelector('input[name="csrf_token"]').value;

    const formData = new FormData();
    formData.append('post_id', postId);
    formData.append('reason', cleanReason);
    formData.append('csrf_token', csrfToken);

    fetch('/connectrix/posts/report_post.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            alert(data.message);
        } else {
            alert(data.message);
        }
    })
    .catch(err => console.error('Error submitting report:', err));
}