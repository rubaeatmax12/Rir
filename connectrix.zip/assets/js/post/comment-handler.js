// কমেন্ট বক্স ওপেন/ক্লোজ টগল করার জন্য
function toggleCommentSection(postId) {
    const commentSection = document.getElementById(`comments-area-${postId}`);
    if (commentSection.style.display === 'none' || commentSection.style.display === '') {
        commentSection.style.display = 'block';
    } else {
        commentSection.style.display = 'none';
    }
}

// নতুন কমেন্ট সাবমিট করা
function submitComment(e, postId) {
    e.preventDefault();
    const form = e.target;
    const input = form.querySelector('input[name="content"]');
    const commentsList = document.getElementById(`comments-list-${postId}`);
    const commentCountText = document.querySelector(`#post-${postId} .comment-count-text`);

    if (input.value.trim() === '') return;

    const formData = new FormData(form);
    formData.append('post_id', postId);

    fetch('../../posts/comment.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            // নতুন কমেন্ট বাবল ডাইনামিকালি ডমে যুক্ত করা হচ্ছে
            const newCommentHtml = `
                <li class="comment-item">
                    <img class="comment-input-avatar" src="../uploads/profile/${data.profile_pic}" alt="user">
                    <div>
                        <div class="comment-bubble-wrapper">
                            <a href="#" class="commenter-name">${data.first_name} ${data.last_name}</a>
                            <div class="comment-text">${data.content}</div>
                        </div>
                        <div class="comment-actions">
                            <span class="comment-action-link">Like</span>
                            <span class="comment-action-link">Reply</span>
                            <span>Just now</span>
                        </div>
                    </div>
                </li>
            `;
            commentsList.insertAdjacentHTML('beforeend', newCommentHtml);
            input.value = ''; // ইনপুট বক্স খালি করা

            // কমেন্ট সংখ্যা এক বাড়ানো
            let currentCount = parseInt(commentCountText.textContent) || 0;
            commentCountText.textContent = `${currentCount + 1} Comments`;
        } else {
            alert(data.message);
        }
    })
    .catch(err => console.error('Error submitting comment:', err));
}