document.addEventListener('DOMContentLoaded', function() {
    const postForm = document.getElementById('ajaxCreatePostForm');
    
    if (postForm) {
        postForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const submitBtn = postForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Publishing...';

            const formData = new FormData(postForm);

            fetch('../../posts/create_post.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Post';
                
                if (data.status === 'success') {
                    closePostModal();
                    // পেজ রিলোড করে নতুন পোস্ট দেখানোর জন্য
                    window.location.reload(); 
                } else {
                    alert(data.message);
                }
            })
            .catch(err => {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Post';
                alert('Something went wrong. Please try again.');
            });
        });
    }
});