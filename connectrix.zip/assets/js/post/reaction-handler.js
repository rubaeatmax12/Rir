function toggleLike(postId) {
    const likeButton = document.querySelector(`#post-${postId} .like-btn`);
    const countDisplay = document.querySelector(`#post-${postId} .like-count-text`);

    const formData = new FormData();
    formData.append('post_id', postId);

    fetch('../../posts/like_post.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            if (data.liked) {
                likeButton.classList.add('active-like');
                likeButton.querySelector('i').className = 'fa-solid fa-thumbs-up';
            } else {
                likeButton.classList.remove('active-like');
                likeButton.querySelector('i').className = 'fa-regular fa-thumbs-up';
            }
            countDisplay.textContent = `${data.total_likes} Likes`;
        } else {
            alert(data.message);
        }
    })
    .catch(err => console.error('Error toggling like:', err));
}