document.addEventListener('DOMContentLoaded', function() {
    // প্রতি ৫ সেকেন্ডে ব্যাকগ্রাউন্ডে নোটিফিকেশন চেক হবে
    checkNewNotifications();
    setInterval(checkNewNotifications, 5000);
});

function checkNewNotifications() {
    // প্রজেক্টের আপেক্ষিক পাথ নির্ধারণ (রুট ডিরেক্টরি অনুযায়ী)
    fetch('/connectrix/notifications/ajax/fetch_notifications.php')
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const badge = document.getElementById('notificationBadgeCounter');
            if (badge) {
                if (data.unread_count > 0) {
                    badge.textContent = data.unread_count;
                    badge.style.display = 'flex'; // কাউন্ট থাকলে শো করবে
                } else {
                    badge.style.display = 'none'; // কাউন্ট ০ হলে লাল ব্যাজ লুকাবে
                }
            }
        }
    })
    .catch(err => console.error('Error fetching notification count:', err));
}