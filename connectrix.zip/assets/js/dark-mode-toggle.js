function toggleDarkModeBtn() {
    fetch('/connectrix/profile/ajax/toggle_dark_mode.php', {
        method: 'POST'
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const body = document.body;
            const darkIcon = document.getElementById('darkModeIcon');
            
            if (data.dark_mode === 1) {
                body.classList.add('dark-mode');
                darkIcon.className = 'fa-solid fa-sun'; // সুর্য আইকন (লাইট মোডে যাওয়ার জন্য)
            } else {
                body.classList.remove('dark-mode');
                darkIcon.className = 'fa-solid fa-moon'; // চাঁদ আইকন (ডার্ক মোডে যাওয়ার জন্য)
            }
        } else {
            alert('Could not update theme preference.');
        }
    })
    .catch(err => console.error('Error toggling dark mode:', err));
}