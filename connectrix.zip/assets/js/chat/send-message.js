document.getElementById('messengerSendForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const messageField = document.getElementById('messageField');
    const messageText = messageField.value.trim();
    const recipientId = document.getElementById('recipientId').value;
    
    if (messageText === '' || recipientId === '') return;

    const formData = new FormData(this);

    // মেসেজ ফিল্ড তাৎক্ষণিকভাবে খালি করে দেওয়া যাতে ইউজার ভালো এক্সপেরিয়েন্স পান
    messageField.value = '';

    fetch('ajax/send_message.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            // মেসেজ সফলভাবে গেছে, পোলিং ফাইল অটোমেটিকাল লোড করবে
            fetchActiveConversationMessages(); 
        } else {
            alert(data.message);
        }
    })
    .catch(err => console.error('Error sending message:', err));
});