let activeRecipientId = null;
let pollInterval = null;

function loadActiveChat(friendId, friendName, friendAvatar, listItem) {
    // অ্যাক্টিভ চ্যাট হাইলাইট করা
    document.querySelectorAll('.conversation-item').forEach(item => {
        item.classList.remove('active-chat');
    });
    listItem.classList.add('active-chat');

    // প্লেসহোল্ডার হাইড করে চ্যাট উইন্ডো শো করা
    document.getElementById('emptyChatPlaceholder').style.display = 'none';
    document.getElementById('activeChatWindow').style.display = 'flex';

    // ডাটা সেটআপ
    document.getElementById('activeChatName').textContent = friendName;
    document.getElementById('activeChatAvatar').src = friendAvatar;
    document.getElementById('recipientId').value = friendId;
    
    activeRecipientId = friendId;

    // নতুন ইউজারের চ্যাট লোড করা
    fetchActiveConversationMessages();

    // আগের পোল বন্ধ করে নতুন পোলিং চালু করা (প্রতি ২ সেকেন্ড পরপর)
    clearInterval(pollInterval);
    pollInterval = setInterval(fetchActiveConversationMessages, 2000);
}

function fetchActiveConversationMessages() {
    if (!activeRecipientId) return;

    fetch(`ajax/fetch_messages.php?recipient_id=${activeRecipientId}`)
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const scroller = document.getElementById('messagesScroller');
            let messagesHtml = '';

            data.messages.forEach(msg => {
                const isSent = (parseInt(msg.sender_id) === parseInt(data.my_id));
                const rowClass = isSent ? 'msg-sent' : 'msg-received';

                messagesHtml += `
                    <div class="msg-row ${rowClass}">
                        <div class="msg-bubble">
                            ${escapeHTML(msg.message)}
                        </div>
                    </div>
                `;
            });

            // স্ক্রোলার আপডেট
            const prevHeight = scroller.scrollHeight;
            scroller.innerHTML = messagesHtml;

            // নতুন মেসেজ থাকলে স্ক্রল নিচে নামিয়ে দেওয়া
            if (scroller.scrollHeight > prevHeight) {
                scroller.scrollTop = scroller.scrollHeight;
            }
        }
    })
    .catch(err => console.error('Error fetching messages:', err));
}

// XSS প্রিভেনশনের জন্য স্ক্রিপ্ট ফিল্টারিং
function escapeHTML(str) {
    return str.replace(/[&<>'"]/g, 
        tag => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#39;',
            '"': '&quot;'
        }[tag] || tag)
    );
}