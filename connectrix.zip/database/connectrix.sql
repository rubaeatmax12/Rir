-- Connectrix Database Schema
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `users`, `friends`, `posts`, `post_reactions`, `comments`, `conversations`, `messages`, `notifications`, `stories`, `story_views`, `saved_posts`;
SET FOREIGN_KEY_CHECKS = 1;

-- ১. ইউজার টেবিল
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `gender` ENUM('Male', 'Female', 'Other') DEFAULT NULL,
  `birthday` DATE DEFAULT NULL,
  `profile_pic` VARCHAR(255) DEFAULT 'default-avatar.png',
  `cover_pic` VARCHAR(255) DEFAULT 'default-cover.png',
  `bio` VARCHAR(255) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `hometown` VARCHAR(100) DEFAULT NULL,
  `relationship` ENUM('Single', 'In a relationship', 'Married', 'Engaged', 'Unspecified') DEFAULT 'Unspecified',
  `status` ENUM('Active', 'Pending', 'Suspended') DEFAULT 'Pending',
  `verification_token` VARCHAR(255) DEFAULT NULL,
  `reset_token` VARCHAR(255) DEFAULT NULL,
  `dark_mode` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ২. ফ্রেন্ডস টেবিল
CREATE TABLE `friends` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_one` INT NOT NULL,
  `user_two` INT NOT NULL,
  `status` ENUM('Pending', 'Accepted', 'Blocked') DEFAULT 'Pending',
  `action_user_id` INT NOT NULL, -- কে রিকোয়েস্ট পাঠিয়েছে বা ব্লক করেছে তার আইডি
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_one`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_two`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `friendship_unique` (`user_one`, `user_two`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ৩. পোস্ট টেবিল
CREATE TABLE `posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `content` TEXT DEFAULT NULL,
  `privacy` ENUM('Public', 'Friends', 'Only_Me') DEFAULT 'Public',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ৪. পোস্ট রিঅ্যাকশন টেবিল
CREATE TABLE `post_reactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `post_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `type` ENUM('Like', 'Love', 'Haha', 'Wow', 'Sad', 'Angry') DEFAULT 'Like',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `reaction_unique` (`post_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ৫. কমেন্ট টেবিল
CREATE TABLE `comments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `post_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `parent_id` INT DEFAULT NULL, -- সাব-কমেন্টের জন্য প্যারেন্ট কমেন্ট আইডি
  `content` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`parent_id`) REFERENCES `comments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ৬. মেসেঞ্জার কনভারসেশন টেবিল
CREATE TABLE `conversations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `is_group` TINYINT(1) DEFAULT 0,
  `title` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- কনভারসেশন মেম্বার
CREATE TABLE `conversation_members` (
  `conversation_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  PRIMARY KEY (`conversation_id`, `user_id`),
  FOREIGN KEY (`conversation_id`) REFERENCES `conversations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ৭. মেসেজ টেবিল
CREATE TABLE `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `conversation_id` INT NOT NULL,
  `sender_id` INT NOT NULL,
  `message` TEXT DEFAULT NULL,
  `attachment_path` VARCHAR(255) DEFAULT NULL,
  `attachment_type` VARCHAR(50) DEFAULT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`conversation_id`) REFERENCES `conversations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ৮. নোটিফিকেশন টেবিল
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `notifier_id` INT NOT NULL, -- যে নোটিফিকেশনটি অ্যাকশনের মাধ্যমে তৈরি করল
  `receiver_id` INT NOT NULL, -- যে নোটিফিকেশনটি পাবে
  `entity_id` INT DEFAULT NULL, -- পোস্ট আইডি, কমেন্ট আইডি বা মেসেজ আইডি
  `type` ENUM('Friend_Request', 'Accept_Request', 'Like_Post', 'Comment_Post', 'Share_Post', 'Mention') NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`notifier_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ৯. স্টোরি টেবিল
CREATE TABLE `stories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `media_path` VARCHAR(255) NOT NULL,
  `media_type` ENUM('Image', 'Video') DEFAULT 'Image',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `expires_at` TIMESTAMP NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ১০. স্টোরি ভিউ টেবিল
CREATE TABLE `story_views` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `story_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `viewed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`story_id`) REFERENCES `stories`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `view_unique` (`story_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ১১. সেভড পোস্ট টেবিল
CREATE TABLE `saved_posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `post_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `saved_unique` (`user_id`, `post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;