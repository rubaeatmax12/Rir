<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__) . '/includes/functions/sanitize_functions.php';
require_once dirname(__DIR__) . '/includes/functions/notification_functions.php';

if (!is_logged_in()) {
    send_json_response('error', 'Authentication required.');
}

$post_id = intval($_POST['post_id'] ?? 0);
$content = sanitize_input($_POST['content'] ?? '');
$user_id = $_SESSION['user_id'];

if ($post_id === 0 || empty($content)) {
    send_json_response('error', 'Invalid parameters.');
}

$db = (new Database())->getConnection();

try {
    $query = "INSERT INTO comments (post_id, user_id, content) VALUES (:post_id, :user_id, :content)";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        ':post_id' => $post_id,
        ':user_id' => $user_id,
        ':content' => $content
    ]);

    if ($result) {
        $comment_id = $db->lastInsertId();
        
        // সদ্য তৈরি হওয়া কমেন্টের ইউজারের ডিটেইলস নিয়ে আসা
        $user_query = "SELECT first_name, last_name, profile_pic FROM users WHERE id = :id LIMIT 1";
        $user_stmt = $db->prepare($user_query);
        $user_stmt->execute([':id' => $user_id]);
        $user_data = $user_stmt->fetch();

        // পোস্ট কার মালিক সেটি বের করা
        $post_owner_stmt = $db->prepare("SELECT user_id FROM posts WHERE id = :p_id LIMIT 1");
        $post_owner_stmt->execute([':p_id' => $post_id]);
        $post_owner_id = $post_owner_stmt->fetch()['user_id'];

        // পোস্টের মালিককে কমেন্ট নোটিফিকেশন পাঠানো (যদি নিজের পোস্টে নিজে কমেন্ট না করে)
        if ($user_id !== $post_owner_id) {
            create_notification($user_id, $post_owner_id, $post_id, 'Comment_Post');
        }

        send_json_response('success', 'Comment saved.', [
            'comment_id' => $comment_id,
            'content' => $content,
            'first_name' => $user_data['first_name'],
            'last_name' => $user_data['last_name'],
            'profile_pic' => $user_data['profile_pic']
        ]);
    } else {
        send_json_response('error', 'Failed to save comment.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'System error: ' . $e->getMessage());
}