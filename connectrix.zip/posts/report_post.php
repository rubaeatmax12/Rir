<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security mismatch. Refresh page.');
}

$reported_post_id = intval($_POST['post_id'] ?? 0);
$reason = sanitize_input($_POST['reason'] ?? '');
$reporter_id = $_SESSION['user_id'];

if ($reported_post_id === 0 || empty($reason)) {
    send_json_response('error', 'Please select a reason for reporting.');
}

$db = (new Database())->getConnection();

try {
    // একই ইউজার একই পোস্টে একাধিকবার রিপোর্ট করেছে কিনা চেক করা
    $check_stmt = $db->prepare("SELECT id FROM reports WHERE reporter_id = :reporter_id AND reported_post_id = :post_id LIMIT 1");
    $check_stmt->execute([':reporter_id' => $reporter_id, ':post_id' => $reported_post_id]);

    if ($check_stmt->rowCount() > 0) {
        send_json_response('error', 'You have already submitted a report for this post.');
    }

    // রিপোর্ট ইন্সার্ট করা
    $insert_stmt = $db->prepare("INSERT INTO reports (reporter_id, reported_post_id, reason) VALUES (:reporter_id, :post_id, :reason)");
    $result = $insert_stmt->execute([
        ':reporter_id' => $reporter_id,
        ':post_id' => $reported_post_id,
        ':reason' => $reason
    ]);

    if ($result) {
        send_json_response('success', 'Thank you. We have received your report and will review it shortly.');
    } else {
        send_json_response('error', 'Failed to submit report.');
    }

} catch (PDOException $e) {
    send_json_response('error', 'System DB error: ' . $e->getMessage());
}