<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response('error', 'Invalid request method.');
}

if (!is_logged_in()) {
    send_json_response('error', 'Authentication required.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security token expired. Please refresh.');
}

$content = sanitize_input($_POST['content'] ?? '');

if (empty($content)) {
    send_json_response('error', "Post content cannot be empty.");
}

$user_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

try {
    $query = "INSERT INTO posts (user_id, content, privacy) VALUES (:user_id, :content, 'Public')";
    $stmt = $db->prepare($query);
    $result = $stmt->execute([
        ':user_id' => $user_id,
        ':content' => $content
    ]);

    if ($result) {
        send_json_response('success', 'Post published successfully!');
    } else {
        send_json_response('error', 'Failed to publish post.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'System error: ' . $e->getMessage());
}