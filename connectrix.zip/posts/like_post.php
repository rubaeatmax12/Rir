<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__) . '/includes/functions/sanitize_functions.php';
require_once dirname(__DIR__) . '/includes/functions/notification_functions.php';

if (!is_logged_in()) {
    send_json_response('error', 'Authentication required.');
}

$post_id = intval($_POST['post_id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($post_id === 0) {
    send_json_response('error', 'Invalid post ID.');
}

$db = (new Database())->getConnection();

try {
    // ইতিমধ্যে লাইক করা আছে কিনা চেক করুন
    $check_query = "SELECT id FROM post_reactions WHERE post_id = :post_id AND user_id = :user_id LIMIT 1";
    $stmt = $db->prepare($check_query);
    $stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);
    
    if ($stmt->rowCount() > 0) {
        // লাইক করা থাকলে তা রিমুভ (Unlike) করা হবে
        $delete_query = "DELETE FROM post_reactions WHERE post_id = :post_id AND user_id = :user_id";
        $delete_stmt = $db->prepare($delete_query);
        $delete_stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);
        
        $liked = false;
    } else {
        // লাইক না থাকলে নতুন ইন্সার্ট হবে
        $insert_query = "INSERT INTO post_reactions (post_id, user_id, type) VALUES (:post_id, :user_id, 'Like')";
        $insert_stmt = $db->prepare($insert_query);
        $insert_stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);
        
        $liked = true;

        // পোস্ট কার মালিক সেটি বের করা
        $post_owner_stmt = $db->prepare("SELECT user_id FROM posts WHERE id = :p_id LIMIT 1");
        $post_owner_stmt->execute([':p_id' => $post_id]);
        $post_owner_id = $post_owner_stmt->fetch()['user_id'];

        // পোস্টের মালিককে লাইক নোটিফিকেশন পাঠানো (যদি মালিক নিজে লাইক না করে থাকে)
        if ($user_id !== $post_owner_id) {
            create_notification($user_id, $post_owner_id, $post_id, 'Like_Post');
        }
    }

    // আপডেটেড মোট লাইক সংখ্যা গণনা করা
    $count_query = "SELECT COUNT(id) as total_likes FROM post_reactions WHERE post_id = :post_id";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute([':post_id' => $post_id]);
    $likes_data = $count_stmt->fetch();

    send_json_response('success', 'Like toggled.', [
        'liked' => $liked,
        'total_likes' => $likes_data['total_likes']
    ]);

} catch (PDOException $e) {
    send_json_response('error', 'System error: ' . $e->getMessage());
}