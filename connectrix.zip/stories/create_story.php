<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__) . '/config/database.php';
redirect_if_not_logged_in();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
        $error = "Security token mismatch.";
    } else {
        $file = $_FILES['story_image'] ?? null;
        
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                
                // আপলোড ডিরেক্টরি তৈরি (যদি না থাকে)
                $upload_dir = dirname(__DIR__) . '/uploads/stories/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                $new_filename = 'story_' . time() . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
                $destination = $upload_dir . $new_filename;

                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    $db = (new Database())->getConnection();
                    // স্টোরি এক্সপায়ারি টাইম ২৪ ঘণ্টা পর সেট করা হচ্ছে
                    $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));

                    $query = "INSERT INTO stories (user_id, media_path, media_type, expires_at) VALUES (:user_id, :media_path, 'Image', :expires_at)";
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute([
                        ':user_id' => $_SESSION['user_id'],
                        ':media_path' => $new_filename,
                        ':expires_at' => $expires_at
                    ]);

                    if ($result) {
                        $success = "Story uploaded successfully!";
                        header("Refresh: 2; url=" . SITE_URL . "/feed/index.php");
                    } else {
                        $error = "Database insertion failed.";
                    }
                } else {
                    $error = "Failed to save uploaded file.";
                }
            } else {
                $error = "Invalid file type. Only JPG, PNG, and GIF are allowed.";
            }
        } else {
            $error = "Please select an image file.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Story - Connectrix</title>
    <link rel="stylesheet" href="../assets/css/base/variables.css">
    <link rel="stylesheet" href="../assets/css/components/buttons.css">
    <link rel="stylesheet" href="../assets/css/auth/login-form.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card" style="text-align: center;">
            <h2 style="margin-top:0;">Create a Story</h2>
            <p style="color:var(--text-secondary); font-size:14px; margin-bottom: 20px;">Share a photo that disappears in 24 hours.</p>

            <?php if (!empty($error)): ?>
                <div class="error-alert" style="display:block;"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div style="background-color:#d4edda; color:#155724; border:1px solid #c3e6cb; padding:12px; border-radius:6px; font-size:14px; margin-bottom:12px;">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <form action="create_story.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div class="auth-form-group" style="border: 2px dashed var(--border-color); padding: 30px; border-radius:8px; background:var(--background-color);">
                    <i class="fa-solid fa-cloud-arrow-up" style="font-size:32px; color:var(--text-secondary); margin-bottom:10px;"></i>
                    <input type="file" name="story_image" accept="image/*" required style="font-size:14px;">
                </div>

                <button type="submit" class="btn-fb-primary btn-custom" style="width: 100%; height:45px; margin-top:15px;">Share to Story</button>
            </form>
            <div style="margin-top:15px;">
                <a href="../feed/index.php" class="auth-link">Back to Feed</a>
            </div>
        </div>
    </div>
</body>
</html>