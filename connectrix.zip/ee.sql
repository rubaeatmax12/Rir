CREATE TABLE IF NOT EXISTS `marketplace_products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL, -- বিক্রেতার আইডি
  `title` VARCHAR(150) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `category` ENUM('Electronics', 'Vehicles', 'Property', 'Apparel', 'Home Goods', 'Others') DEFAULT 'Others',
  `location` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `image_path` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;