<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/notification_functions.php';

if (!is_logged_in()) {
    send_json_response('error', 'Unauthorized.');
}

$user_id = $_SESSION['user_id'];
$unread_count = get_unread_notifications_count($user_id);

send_json_response('success', 'Count loaded.', [
    'unread_count' => intval($unread_count)
]);