<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/date_functions.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/notification/notification-dropdown.css">';

$user_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

// ডাটাবেজ থেকে সমস্ত নোটিফিকেশন এবং রিসিভারের বিবরণ তুলে আনা
$query = "SELECT n.id, n.type, n.is_read, n.entity_id, n.created_at, u.first_name, u.last_name, u.profile_pic 
          FROM notifications n 
          JOIN users u ON n.notifier_id = u.id 
          WHERE n.receiver_id = :uid 
          ORDER BY n.created_at DESC LIMIT 30";
$stmt = $db->prepare($query);
$stmt->execute([':uid' => $user_id]);
$all_notifications = $stmt->fetchAll();

// ব্যবহারকারী পেজে প্রবেশ করলেই সব নোটিফিকেশন অটোমেটিক 'Read' হয়ে যাবে
$mark_read = $db->prepare("UPDATE notifications SET is_read = 1 WHERE receiver_id = :uid");
$mark_read->execute([':uid' => $user_id]);
?>

<div class="main-layout-container" style="max-width: 650px; display: block; padding: 16px;">
    <div class="notification-list-container">
        <div class="notification-header">Notifications</div>
        
        <?php if (count($all_notifications) > 0): ?>
            <?php foreach ($all_notifications as $notify): 
                $unread_class = ($notify['is_read'] == 0) ? 'unread-notify' : '';
                
                // নোটিফিকেশন টাইপ অনুযায়ী টেক্সট এবং ইউআরএল ডিফাইন করা
                $notify_text = "";
                $target_url = "#";
                $notifier_name = "<strong>" . clean_output($notify['first_name'] . ' ' . $notify['last_name']) . "</strong>";

                switch ($notify['type']) {
                    case 'Friend_Request':
                        $notify_text = "sent you a friend request.";
                        $target_url = SITE_URL . "/friends/index.php";
                        break;
                    case 'Accept_Request':
                        $notify_text = "accepted your friend request.";
                        $target_url = SITE_URL . "/profile/view.php?id=" . $notify['entity_id'];
                        break;
                    case 'Like_Post':
                        $notify_text = "liked your post.";
                        $target_url = SITE_URL . "/feed/index.php#post-" . $notify['entity_id'];
                        break;
                    case 'Comment_Post':
                        $notify_text = "commented on your post.";
                        $target_url = SITE_URL . "/feed/index.php#post-" . $notify['entity_id'];
                        break;
                }
                ?>
                <a href="<?php echo $target_url; ?>" class="notification-item-row <?php echo $unread_class; ?>">
                    <img class="notification-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($notify['profile_pic']); ?>" alt="User">
                    <div class="notification-text-content">
                        <span><?php echo $notifier_name; ?> <?php echo $notify_text; ?></span>
                        <span class="notification-time"><?php echo get_time_ago($notify['created_at']); ?></span>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                <i class="fa-solid fa-bell-slash" style="font-size: 48px; margin-bottom: 12px; color: var(--divider-color);"></i>
                <p>No notifications yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>