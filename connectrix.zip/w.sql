-- ১. ইউজার টেবিলে এডমিন ফ্ল্যাগ যুক্ত করা
ALTER TABLE `users` ADD COLUMN `is_admin` TINYINT(1) DEFAULT 0 AFTER `status`;

-- ২. টেস্ট করার জন্য যেকোনো একটি ইউজারকে এডমিন বানানো (আপনার তৈরি করা প্রথম ইউজারের আইডি ১ হলে এটি কাজ করবে)
UPDATE `users` SET `is_admin` = 1 WHERE `id` = 1;

-- ৩. পোস্ট রিপোর্ট জমা রাখার টেবিল
CREATE TABLE IF NOT EXISTS `reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `reporter_id` INT NOT NULL,
  `reported_post_id` INT NOT NULL,
  `reason` VARCHAR(255) NOT NULL,
  `status` ENUM('Pending', 'Resolved') DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reported_post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;