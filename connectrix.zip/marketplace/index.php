<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/marketplace/product-grid.css">';

$db = (new Database())->getConnection();

// ক্যাটাগরি ফিল্টার প্রসেস
$category_filter = sanitize_input($_GET['category'] ?? '');

$query = "SELECT id, title, price, location, image_path FROM marketplace_products";
if (!empty($category_filter)) {
    $query .= " WHERE category = :category";
}
$query .= " ORDER BY created_at DESC";

$stmt = $db->prepare($query);
if (!empty($category_filter)) {
    $stmt->execute([':category' => $category_filter]);
} else {
    $stmt->execute();
}
$all_products = $stmt->fetchAll();
?>

<div class="marketplace-layout">
    <!-- বাম পাশের ক্যাটাগরি মেনু -->
    <aside style="background-color:var(--card-background); padding:16px; border-radius:8px; box-shadow:var(--shadow-sm); height:fit-content;">
        <h3 style="margin-top:0; margin-bottom:15px;">Categories</h3>
        <ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:10px;">
            <li><a href="index.php" style="text-decoration:none; color:var(--text-primary); font-weight:600;"><i class="fa-solid fa-store" style="width:20px; color:var(--primary-color);"></i> All items</a></li>
            <li><a href="index.php?category=Electronics" style="text-decoration:none; color:var(--text-secondary);"><i class="fa-solid fa-laptop" style="width:20px;"></i> Electronics</a></li>
            <li><a href="index.php?category=Vehicles" style="text-decoration:none; color:var(--text-secondary);"><i class="fa-solid fa-car" style="width:20px;"></i> Vehicles</a></li>
            <li><a href="index.php?category=Apparel" style="text-decoration:none; color:var(--text-secondary);"><i class="fa-solid fa-shirt" style="width:20px;"></i> Apparel</a></li>
            <li><a href="index.php?category=Home Goods" style="text-decoration:none; color:var(--text-secondary);"><i class="fa-solid fa-couch" style="width:20px;"></i> Home Goods</a></li>
        </ul>
        <hr style="border:0; border-top:1px solid var(--divider-color); margin:15px 0;">
        <a href="create_listing.php" class="btn-fb-primary btn-custom" style="width:100%;"><i class="fa-solid fa-plus"></i> Create Listing</a>
    </aside>

    <!-- ডান পাশের পণ্য প্রদর্শনী গ্রিড -->
    <main>
        <h2 style="margin-top:0; margin-bottom:20px;">Today's Picks <?php echo !empty($category_filter) ? "in " . clean_output($category_filter) : ""; ?></h2>
        
        <?php if (count($all_products) > 0): ?>
            <div class="product-grid">
                <?php foreach ($all_products as $product): ?>
                    <a href="view_product.php?id=<?php echo $product['id']; ?>" class="product-card">
                        <img class="product-img" src="<?php echo SITE_URL; ?>/uploads/marketplace/<?php echo clean_output($product['image_path']); ?>" alt="product">
                        <div class="product-info">
                            <span class="product-price">$<?php echo number_format($product['price'], 2); ?></span>
                            <span class="product-title"><?php echo clean_output($product['title']); ?></span>
                            <span class="product-location"><?php echo clean_output($product['location']); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="background-color:var(--card-background); padding:40px; text-align:center; border-radius:8px; color:var(--text-secondary); box-shadow:var(--shadow-sm);">
                <i class="fa-solid fa-basket-shopping" style="font-size:48px; margin-bottom:12px;"></i>
                <h3>No items found</h3>
                <p>Be the first to create a listing in this category!</p>
            </div>
        <?php endif; ?>
    </main>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>