<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

$product_id = intval($_GET['id'] ?? 0);
$db = (new Database())->getConnection();

// প্রোডাক্টের এবং বিক্রেতার ডিটেইলস তুলে আনা
$query = "SELECT p.*, u.first_name, u.last_name, u.profile_pic 
          FROM marketplace_products p 
          JOIN users u ON p.user_id = u.id 
          WHERE p.id = :id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->execute([':id' => $product_id]);
$product = $product_stmt = $stmt->fetch();

if (!$product) {
    echo '<div style="text-align:center; padding:50px;"><h2>Listing not found.</h2><a href="index.php">Back to Marketplace</a></div>';
    require_once dirname(__DIR__) . '/includes/footer.php';
    exit();
}
?>

<div class="main-layout-container" style="max-width: 900px; padding: 16px; display: grid; grid-template-columns: 1.2fr 1fr; gap:24px; background-color:var(--card-background); border-radius:8px; box-shadow:var(--shadow-sm); margin-top:20px;">
    
    <!-- বাম কলাম: বড় পণ্য ছবি -->
    <div>
        <img style="width:100%; border-radius:8px; object-fit:cover; max-height:450px;" src="<?php echo SITE_URL; ?>/uploads/marketplace/<?php echo clean_output($product['image_path']); ?>" alt="product">
    </div>

    <!-- ডান কলাম: বিবরণ এবং মেসেঞ্জার ট্রিগার বাটন -->
    <div style="display:flex; flex-direction:column; gap:16px;">
        <div>
            <h1 style="margin:0; font-size:24px; font-weight:700;"><?php echo clean_output($product['title']); ?></h1>
            <h2 style="margin:8px 0 0 0; color:var(--text-primary); font-size:22px;">$<?php echo number_format($product['price'], 2); ?></h2>
        </div>

        <hr style="border:0; border-top:1px solid var(--divider-color); margin:0;">

        <div>
            <h3 style="margin-top:0; margin-bottom:6px; font-size:16px; color:var(--text-secondary);">Details</h3>
            <p style="margin:4px 0; font-size:14px;">Category: <strong><?php echo clean_output($product['category']); ?></strong></p>
            <p style="margin:4px 0; font-size:14px;">Location: <strong><?php echo clean_output($product['location']); ?></strong></p>
        </div>

        <div>
            <h3 style="margin-top:0; margin-bottom:6px; font-size:16px; color:var(--text-secondary);">Description</h3>
            <p style="margin:0; font-size:14px; line-height:1.4;"><?php echo nl2br(clean_output($product['description'])); ?></p>
        </div>

        <hr style="border:0; border-top:1px solid var(--divider-color); margin:0;">

        <!-- বিক্রেতার প্রোফাইল কার্ড -->
        <div style="display:flex; align-items:center; gap:12px;">
            <img style="width:40px; height:40px; border-radius:50%;" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($product['profile_pic']); ?>" alt="seller">
            <div>
                <span style="font-size:12px; color:var(--text-secondary); display:block;">Seller info</span>
                <strong style="font-size:14px;"><?php echo clean_output($product['first_name'] . ' ' . $product['last_name']); ?></strong>
            </div>
        </div>

        <!-- বিক্রেতার সাথে চ্যাট শুরু করার বাটন (সরাসরি চ্যাট মডিউলে রিডাইরেক্ট করবে) -->
        <?php if ($product['user_id'] !== $_SESSION['user_id']): ?>
            <a href="<?php echo SITE_URL; ?>/chat/index.php" class="btn-fb-primary btn-custom" style="width:100%; height:45px; gap:8px;"><i class="fa-solid fa-comment-dots"></i> Message Seller</a>
        <?php else: ?>
            <button class="btn-fb-secondary btn-custom" style="width:100%; height:45px;" disabled>Your Listing</button>
        <?php endif; ?>
    </div>

</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>