<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized access.');
}

if (!isset($_POST['csrf_token']) || !validate_csrf($_POST['csrf_token'])) {
    send_json_response('error', 'Security mismatched.');
}

$title = sanitize_input($_POST['title'] ?? '');
$price = floatval($_POST['price'] ?? 0.00);
$category = sanitize_input($_POST['category'] ?? 'Others');
$location = sanitize_input($_POST['location'] ?? '');
$description = sanitize_input($_POST['description'] ?? '');
$user_id = $_SESSION['user_id'];

$file = $_FILES['product_img'] ?? null;

if (empty($title) || $price <= 0 || empty($location) || empty($description) || !$file) {
    send_json_response('error', 'Please fill all fields and provide a photo.');
}

if ($file['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        $upload_dir = dirname(__DIR__, 2) . '/uploads/marketplace/';
        
        // ডিরেক্টরি না থাকলে তৈরি করা হবে
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $new_filename = 'prod_' . time() . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
        $destination = $upload_dir . $new_filename;

        if (move_uploaded_file($file['tmp_name'], $destination)) {
            $db = (new Database())->getConnection();
            $query = "INSERT INTO marketplace_products (user_id, title, price, category, location, description, image_path) 
                      VALUES (:uid, :title, :price, :category, :loc, :desc, :pic)";
            $stmt = $db->prepare($query);
            $result = $stmt->execute([
                ':uid' => $user_id,
                ':title' => $title,
                ':price' => $price,
                ':category' => $category,
                ':loc' => $location,
                ':desc' => $description,
                ':pic' => $new_filename
            ]);

            if ($result) {
                send_json_response('success', 'Listing published successfully!');
            } else {
                send_json_response('error', 'Failed to store listing.');
            }
        } else {
            send_json_response('error', 'Could not save the uploaded photo.');
        }
    } else {
        send_json_response('error', 'Invalid photo format. Only JPG, PNG, and GIF allowed.');
    }
} else {
    send_json_response('error', 'Error uploading photo.');
}