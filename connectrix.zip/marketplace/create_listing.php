<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
?>

<div class="main-layout-container" style="max-width: 600px; display:block; padding: 16px;">
    <div style="background:var(--card-background); border-radius:8px; padding:24px; box-shadow:var(--shadow-sm);">
        <h2 style="margin-top:0; border-bottom:1px solid var(--divider-color); padding-bottom:12px;">Create New Listing</h2>
        
        <div id="listingAlert" style="display:none; padding:12px; border-radius:6px; margin-bottom:15px; font-size:14px;"></div>

        <form id="listingForm" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div style="margin-bottom:12px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Title</label>
                <input type="text" name="title" required placeholder="What are you selling?" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color); box-sizing:border-box;">
            </div>

            <div style="display:flex; gap:12px; margin-bottom:12px;">
                <div style="flex:1;">
                    <label style="font-weight:600; display:block; margin-bottom:6px;">Price ($)</label>
                    <input type="number" step="0.01" name="price" required placeholder="0.00" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color); box-sizing:border-box;">
                </div>
                <div style="flex:1;">
                    <label style="font-weight:600; display:block; margin-bottom:6px;">Category</label>
                    <select name="category" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color);">
                        <option value="Electronics">Electronics</option>
                        <option value="Vehicles">Vehicles</option>
                        <option value="Apparel">Apparel</option>
                        <option value="Home Goods">Home Goods</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Location</label>
                <input type="text" name="location" required placeholder="City, Country" style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color); box-sizing:border-box;">
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Description</label>
                <textarea name="description" required style="width:100%; height:100px; padding:10px; border-radius:6px; border:1px solid var(--border-color); resize:none; font-family:var(--font-stack); box-sizing:border-box;" placeholder="Describe the condition and details of your item..."></textarea>
            </div>

            <div style="margin-bottom:20px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Product Photo</label>
                <input type="file" name="product_img" accept="image/*" required style="font-size:14px;">
            </div>

            <button type="submit" class="btn-fb-primary btn-custom" style="width:100%; height:45px;">Publish Listing</button>
        </form>
    </div>
</div>

<script>
document.getElementById('listingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const alertBox = document.getElementById('listingAlert');
    const formData = new FormData(this);

    fetch('ajax/upload_product.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        alertBox.style.display = 'block';
        if (data.status === 'success') {
            alertBox.style.backgroundColor = '#d4edda';
            alertBox.style.color = '#155724';
            alertBox.textContent = data.message;
            setTimeout(() => window.location.href = 'index.php', 1500);
        } else {
            alertBox.style.backgroundColor = '#ffebe9';
            alertBox.style.color = 'var(--danger-color)';
            alertBox.textContent = data.message;
        }
    });
});
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>