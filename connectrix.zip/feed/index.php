<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

// ফেসবুক-স্টাইল সব CSS মডিউল এখানে লোড করা হলো
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/post-create-box.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/post-card.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/comment-section.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/reaction-popup.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/story/story-row.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/story/story-viewer.css">';

// ডাটাবেজ কানেকশন
$db = (new Database())->getConnection();

// ডাটাবেজ থেকে পোস্টগুলো তুলে আনা (লেটেস্ট পোস্ট উপরে দেখাবে)
$posts_query = "SELECT p.id as post_id, p.content, p.created_at, p.user_id, u.first_name, u.last_name, u.profile_pic 
                FROM posts p 
                JOIN users u ON p.user_id = u.id 
                ORDER BY p.created_at DESC";
$posts_stmt = $db->query($posts_query);
$all_posts = $posts_stmt->fetchAll();
?>

<div class="main-layout-container">
    <!-- Left Sidebar Column -->
    <?php require_once dirname(__DIR__) . '/includes/sidebar_left.php'; ?>
    
    <!-- Middle Feed Column -->
    <main class="middle-feed-column">
        
        <!-- Story Slider Bar (নতুন স্টোরি সেকশন) -->
        <?php require_once __DIR__ . '/partials/story_bar.php'; ?>
        
        <!-- Post Box Partial -->
        <?php require_once __DIR__ . '/partials/create_post_box.php'; ?>
        
        <!-- Posts Feed List -->
        <div class="posts-feed-container">
            <?php 
            if (count($all_posts) > 0) {
                foreach ($all_posts as $post) {
                    // প্রতিটি সিঙ্গেল পোস্টের জন্য কার্ড রেন্ডার করা হচ্ছে
                    require __DIR__ . '/partials/post_card_partial.php';
                }
            } else {
                // নো পোস্ট ফাউন্ড কার্ড
                echo '<div style="background: var(--card-background); padding: 30px; text-align:center; border-radius:8px; box-shadow:var(--shadow-sm); color: var(--text-secondary); margin-top:15px;">';
                echo '<i class="fa-solid fa-photo-film" style="font-size: 40px; margin-bottom: 10px;"></i>';
                echo '<p>No posts available. Be the first to share something!</p>';
                echo '</div>';
            }
            ?>
        </div>
        
    </main>
    
    <!-- Right Sidebar Column -->
    <?php require_once dirname(__DIR__) . '/includes/sidebar_right.php'; ?>
</div>

<!-- গ্লোবাল স্ক্রিপ্টস এবং ইভেন্ট হ্যান্ডলার্স (সবগুলো স্ক্রিপ্ট এখানে সুবিন্যস্ত আছে) -->
<script src="<?php echo SITE_URL; ?>/assets/js/post/reaction-handler.js" defer></script>
<script src="<?php echo SITE_URL; ?>/assets/js/post/comment-handler.js" defer></script>
<script src="<?php echo SITE_URL; ?>/assets/js/post/create-post.js" defer></script>
<script src="<?php echo SITE_URL; ?>/assets/js/story/story-viewer.js" defer></script>
<script src="<?php echo SITE_URL; ?>/assets/js/post/report-post.js" defer></script>

<?php
require_once dirname(__DIR__) . '/includes/footer.php';
?>