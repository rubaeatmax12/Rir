<div class="create-post-card">
    <div class="create-post-input-row">
        <img class="create-post-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($current_user['profile_pic']); ?>" alt="User Avatar">
        <div class="trigger-post-input" onclick="openPostModal()">
            What's on your mind, <?php echo clean_output($current_user['first_name']); ?>?
        </div>
    </div>
    <div class="create-post-actions">
        <div class="post-action-btn" onclick="openPostModal()">
            <i class="fa-solid fa-image-portrait photo-video"></i>
            <span>Photo/video</span>
        </div>
        <div class="post-action-btn" onclick="openPostModal()">
            <i class="fa-regular fa-face-laugh feeling-activity"></i>
            <span>Feeling/activity</span>
        </div>
    </div>
</div>

<!-- পোস্ট ক্রিয়েট করার মডাল উইন্ডো -->
<div id="postModal" class="modal-overlay" style="display:none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1050; align-items: center; justify-content: center;">
    <div style="background: var(--card-background); width: 100%; max-width: 500px; border-radius: 8px; box-shadow: var(--shadow-lg); overflow: hidden; position: relative; margin: 15px;">
        <!-- Modal Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 16px; border-bottom: 1px solid var(--divider-color);">
            <h3 style="margin:0; font-size:20px; font-weight:700; text-align: center; width: 100%;">Create post</h3>
            <span onclick="closePostModal()" style="cursor:pointer; font-size: 20px; color: var(--text-secondary);"><i class="fa-solid fa-xmark"></i></span>
        </div>
        
        <!-- Modal Body -->
        <form id="ajaxCreatePostForm" style="padding: 16px;">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                <img style="width:40px; height:40px; border-radius:50%;" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($current_user['profile_pic']); ?>">
                <div>
                    <strong style="font-size: 15px;"><?php echo clean_output($current_user['first_name'] . ' ' . $current_user['last_name']); ?></strong>
                    <div style="background: var(--divider-color); font-size: 12px; padding: 2px 6px; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px; margin-top:2px;">
                        <i class="fa-solid fa-earth-americas"></i> Public
                    </div>
                </div>
            </div>

            <textarea name="content" placeholder="What's on your mind, <?php echo clean_output($current_user['first_name']); ?>?" style="width:100%; height: 150px; border:none; resize:none; outline:none; font-size:18px; font-family: var(--font-stack); background: transparent; color: var(--text-primary);" required></textarea>

            <button type="submit" class="btn-fb-primary btn-custom" style="width:100%; height:40px; font-size:15px; margin-top:15px;">Post</button>
        </form>
    </div>
</div>

<script>
    function openPostModal() {
        document.getElementById('postModal').style.display = 'flex';
    }
    function closePostModal() {
        document.getElementById('postModal').style.display = 'none';
        document.getElementById('ajaxCreatePostForm').reset();
    }
</script>