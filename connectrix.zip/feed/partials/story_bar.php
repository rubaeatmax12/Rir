<div class="story-container">
    
    <!-- নিজের স্টোরি তৈরির কার্ড -->
    <div class="story-card create-story-card" onclick="window.location.href='../stories/create_story.php'">
        <img class="create-story-thumb" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($current_user['profile_pic']); ?>" alt="Me">
        <div class="create-story-btn-area">
            <div class="story-add-icon">
                <i class="fa-solid fa-plus"></i>
            </div>
            <div class="create-story-text">Create story</div>
        </div>
    </div>

    <!-- ডাটাবেজ থেকে একটিভ ২৪ ঘণ্টার ভেতরের স্টোরিগুলো তুলে আনা -->
    <?php
    try {
        $stories_query = "SELECT s.id as story_id, s.media_path, s.created_at, u.id as user_id, u.first_name, u.last_name, u.profile_pic 
                          FROM stories s 
                          JOIN users u ON s.user_id = u.id 
                          WHERE s.expires_at > NOW() 
                          ORDER BY s.created_at DESC";
        $stories_stmt = $db->query($stories_query);
        $active_stories = $stories_stmt->fetchAll();
    } catch (PDOException $e) {
        $active_stories = [];
    }

    if (count($active_stories) > 0) {
        foreach ($active_stories as $story) {
            ?>
            <div class="story-card" onclick="openStoryViewer('<?php echo SITE_URL; ?>/uploads/stories/<?php echo $story['media_path']; ?>', '<?php echo clean_output($story['first_name'] . ' ' . $story['last_name']); ?>', '<?php echo SITE_URL; ?>/uploads/profile/<?php echo $story['profile_pic']; ?>')">
                <img class="story-user-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($story['profile_pic']); ?>" alt="User">
                <img class="user-story-bg" src="<?php echo SITE_URL; ?>/uploads/stories/<?php echo clean_output($story['media_path']); ?>" alt="Story BG">
                <div class="story-username"><?php echo clean_output($story['first_name'] . ' ' . $story['last_name']); ?></div>
            </div>
            <?php
        }
    }
    ?>
</div>

<!-- Story Full-screen Modal Viewer -->
<div id="storyViewerOverlay" class="story-overlay">
    <div class="story-viewer-container">
        <!-- Progress Bar Indicator -->
        <div class="story-progress-bar-wrap">
            <div class="story-progress-segment">
                <div id="storyProgressBarFill" class="story-progress-fill"></div>
            </div>
        </div>
        <!-- Header Info -->
        <div class="viewer-story-header">
            <div class="viewer-user-info">
                <img id="viewerUserAvatar" class="viewer-user-avatar" src="" alt="user">
                <span id="viewerUserName" class="viewer-user-name">Username</span>
            </div>
            <button class="viewer-close-btn" onclick="closeStoryViewer()">&times;</button>
        </div>
        <!-- Content Media -->
        <img id="viewerStoryMedia" class="viewer-story-media" src="" alt="Story Media">
    </div>
</div>