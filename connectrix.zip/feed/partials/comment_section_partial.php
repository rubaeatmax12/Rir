<div class="post-comments-area" id="comments-area-<?php echo $post['post_id']; ?>">
    
    <!-- কমেন্ট ইনপুট ফর্ম -->
    <div class="comment-input-wrapper">
        <img class="comment-input-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($current_user['profile_pic']); ?>" alt="User">
        <form class="comment-form" onsubmit="submitComment(event, <?php echo $post['post_id']; ?>)">
            <input type="text" name="content" placeholder="Write a comment..." autocomplete="off" required>
        </form>
    </div>

    <!-- ডাটাবেজ থেকে এই পোস্টের কমেন্টগুলো লোড করা -->
    <?php
    $comments_query = "SELECT c.content, c.created_at, u.first_name, u.last_name, u.profile_pic 
                       FROM comments c 
                       JOIN users u ON c.user_id = u.id 
                       WHERE c.post_id = :post_id 
                       ORDER BY c.created_at ASC";
    $comments_stmt = $db->prepare($comments_query);
    $comments_stmt->execute([':post_id' => $post['post_id']]);
    $comments = $comments_stmt->fetchAll();
    ?>

    <ul class="comments-list" id="comments-list-<?php echo $post['post_id']; ?>">
        <?php foreach ($comments as $comment): ?>
            <li class="comment-item">
                <img class="comment-input-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($comment['profile_pic']); ?>" alt="user">
                <div>
                    <div class="comment-bubble-wrapper">
                        <a href="#" class="commenter-name"><?php echo clean_output($comment['first_name'] . ' ' . $comment['last_name']); ?></a>
                        <div class="comment-text"><?php echo clean_output($comment['content']); ?></div>
                    </div>
                    <div class="comment-actions">
                        <span class="comment-action-link">Like</span>
                        <span class="comment-action-link">Reply</span>
                        <span><?php echo get_time_ago($comment['created_at']); ?></span>
                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
</div>