<?php
require_once dirname(__DIR__, 2) . '/includes/functions/date_functions.php';

// লাইক ও কমেন্ট কাউন্ট ডাটাবেজ থেকে নিয়ে আসা
$p_id = $post['post_id'];
$u_id = $_SESSION['user_id'];

// লাইক কাউন্ট
$likes_count_stmt = $db->prepare("SELECT COUNT(id) as count FROM post_reactions WHERE post_id = :post_id");
$likes_count_stmt->execute([':post_id' => $p_id]);
$total_likes = $likes_count_stmt->fetch()['count'];

// ইউজার নিজে লাইক করেছে কিনা
$user_liked_stmt = $db->prepare("SELECT id FROM post_reactions WHERE post_id = :post_id AND user_id = :user_id");
$user_liked_stmt->execute([':post_id' => $p_id, ':user_id' => $u_id]);
$is_liked = $user_liked_stmt->rowCount() > 0;

// কমেন্ট কাউন্ট
$comments_count_stmt = $db->prepare("SELECT COUNT(id) as count FROM comments WHERE post_id = :post_id");
$comments_count_stmt->execute([':post_id' => $p_id]);
$total_comments = $comments_count_stmt->fetch()['count'];
?>
<div class="post-card" id="post-<?php echo $p_id; ?>">
    <!-- Post Header -->
    <div class="post-header">
        <div class="post-author-info">
            <img class="post-author-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($post['profile_pic']); ?>" alt="Author">
            <div>
                <a href="<?php echo SITE_URL; ?>/profile/view.php?id=<?php echo $post['user_id']; ?>" class="post-author-name">
                    <?php echo clean_output($post['first_name'] . ' ' . $post['last_name']); ?>
                </a>
                <div class="post-meta">
                    <span><?php echo get_time_ago($post['created_at']); ?></span>
                    <span>•</span>
                    <i class="fa-solid fa-earth-americas" title="Public"></i>
                </div>
            </div>
        </div>
        <div class="post-options-btn">
            <i class="fa-solid fa-ellipsis"></i>
        </div>
    </div>

    <!-- Post Content -->
    <div class="post-content">
        <?php echo nl2br(clean_output($post['content'])); ?>
    </div>

    <!-- Post Stats (Likes, Comments Count) -->
    <div class="post-stats">
        <div class="reaction-count-display">
            <span style="background-color: var(--primary-color); color:white; width:18px; height:18px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-size:10px;"><i class="fa-solid fa-thumbs-up"></i></span>
            <span class="like-count-text"><?php echo $total_likes; ?> Likes</span>
        </div>
        <div class="comment-count-display" onclick="toggleCommentSection(<?php echo $p_id; ?>)" style="cursor: pointer;">
            <span class="comment-count-text"><?php echo $total_comments; ?> Comments</span>
        </div>
    </div>

    <!-- Post Actions Buttons -->
    <div class="post-actions-row">
        <!-- Like Toggle -->
        <div class="feed-action-button like-btn <?php echo $is_liked ? 'active-like' : ''; ?>" onclick="toggleLike(<?php echo $p_id; ?>)">
            <i class="<?php echo $is_liked ? 'fa-solid' : 'fa-regular'; ?> fa-thumbs-up"></i>
            <span>Like</span>
        </div>
        <!-- Comment Toggle -->
        <div class="feed-action-button" onclick="toggleCommentSection(<?php echo $p_id; ?>)">
            <i class="fa-regular fa-comment"></i>
            <span>Comment</span>
        </div>
        <div class="feed-action-button">
            <i class="fa-regular fa-share-from-square"></i>
            <span>Share</span>
        </div>
    </div>

    <!-- Comment Section Container Partial -->
    <?php require __DIR__ . '/comment_section_partial.php'; ?>
</div>