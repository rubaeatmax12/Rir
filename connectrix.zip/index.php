<?php
// গ্লোবাল কনফিগারেশন এবং সেশন চালু করা
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions/auth_functions.php';

// ব্যবহারকারী ইতিমধ্যে লগইন করা আছে কিনা চেক করা
if (is_logged_in()) {
    // লগইন করা থাকলে সরাসরি নিউজফিড পেজে পাঠিয়ে দিন
    header("Location: " . SITE_URL . "/feed/index.php");
    exit();
} else {
    // লগইন করা না থাকলে সাইনের ইন বা লগইন পেজে পাঠিয়ে দিন
    header("Location: " . SITE_URL . "/auth/login.php");
    exit();
}