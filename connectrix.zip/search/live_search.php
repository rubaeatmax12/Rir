<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__) . '/includes/functions/sanitize_functions.php';

if (!is_logged_in()) {
    send_json_response('error', 'Unauthorized.');
}

$query_string = sanitize_input($_GET['q'] ?? '');

if (empty($query_string)) {
    send_json_response('success', 'No query.', ['results' => []]);
}

$db = (new Database())->getConnection();

try {
    // ইউজারের প্রথম নাম বা শেষ নামের সাথে মিল থাকলে ডেটা নিয়ে আসা
    $search_query = "SELECT id, first_name, last_name, profile_pic FROM users 
                     WHERE (first_name LIKE :q OR last_name LIKE :q) 
                     LIMIT 5";
    $stmt = $db->prepare($search_query);
    $search_term = "%" . $query_string . "%";
    $stmt->execute([':q' => $search_term]);
    $results = $stmt->fetchAll();

    send_json_response('success', 'Results loaded.', ['results' => $results]);

} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}