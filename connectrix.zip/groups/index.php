<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/group/group-card.css">';

$my_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

// ১. আমার জয়েন করা গ্রুপগুলোর তালিকা
$my_groups_query = "SELECT g.id, g.name, g.bio, g.cover_pic 
                    FROM groups g 
                    JOIN group_members m ON g.id = m.group_id 
                    WHERE m.user_id = :my_id";
$my_groups_stmt = $db->prepare($my_groups_query);
$my_groups_stmt->execute([':my_id' => $my_id]);
$my_groups = $my_groups_stmt->fetchAll();

// ২. অন্যান্য সাজেস্টেড গ্রুপ যা আমি এখনো জয়েন করিনি
$suggest_query = "SELECT id, name, bio, cover_pic 
                  FROM groups 
                  WHERE id NOT IN (
                      SELECT group_id FROM group_members WHERE user_id = :my_id
                  ) LIMIT 10";
$suggest_stmt = $db->prepare($suggest_query);
$suggest_stmt->execute([':my_id' => $my_id]);
$suggest_groups = $suggest_stmt->fetchAll();
?>

<div class="main-layout-container" style="max-width: 1100px; display: block; padding: 16px;">
    
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h2 style="margin:0;">Groups</h2>
        <a href="create_group.php" class="btn-fb-primary btn-custom"><i class="fa-solid fa-plus"></i> Create New Group</a>
    </div>

    <!-- আমার গ্রুপসমূহ -->
    <div style="margin-bottom: 32px;">
        <h3>My Groups (<?php echo count($my_groups); ?>)</h3>
        <?php if (count($my_groups) > 0): ?>
            <div class="group-grid">
                <?php foreach ($my_groups as $group): ?>
                    <div class="group-card">
                        <img class="group-cover-thumb" src="<?php echo SITE_URL; ?>/uploads/profile/default-cover.png" alt="cover">
                        <div class="group-card-body">
                            <a href="view_group.php?id=<?php echo $group['id']; ?>" class="group-card-title"><?php echo clean_output($group['name']); ?></a>
                            <p class="group-card-meta"><?php echo clean_output($group['bio']); ?></p>
                            <a href="view_group.php?id=<?php echo $group['id']; ?>" class="btn-fb-secondary btn-custom" style="width:100%; margin-top:auto;">View Group</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="color: var(--text-secondary);">You haven't joined any groups yet.</p>
        <?php endif; ?>
    </div>

    <hr style="border:0; border-top:1px solid var(--divider-color); margin: 24px 0;">

    <!-- সাজেস্টেড বা ডিসকভার গ্রুপসমূহ -->
    <div>
        <h3>Suggested Groups</h3>
        <?php if (count($suggest_groups) > 0): ?>
            <div class="group-grid">
                <?php foreach ($suggest_groups as $group): ?>
                    <div class="group-card" id="suggest-group-<?php echo $group['id']; ?>">
                        <img class="group-cover-thumb" src="<?php echo SITE_URL; ?>/uploads/profile/default-cover.png" alt="cover">
                        <div class="group-card-body">
                            <a href="view_group.php?id=<?php echo $group['id']; ?>" class="group-card-title"><?php echo clean_output($group['name']); ?></a>
                            <p class="group-card-meta"><?php echo clean_output($group['bio']); ?></p>
                            <button onclick="joinGroup(<?php echo $group['id']; ?>, this)" class="btn-fb-primary btn-custom" style="width:100%; margin-top:auto;">Join Group</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="color: var(--text-secondary);">No new suggested groups available.</p>
        <?php endif; ?>
    </div>

</div>

<script>
function joinGroup(groupId, btn) {
    const formData = new FormData();
    formData.append('group_id', groupId);
    
    btn.disabled = true;
    btn.textContent = 'Joining...';

    fetch('ajax/join_group.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            btn.className = 'btn-fb-secondary btn-custom';
            btn.textContent = 'Joined';
            setTimeout(() => window.location.reload(), 1000);
        } else {
            alert(data.message);
            btn.disabled = false;
            btn.textContent = 'Join Group';
        }
    });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>