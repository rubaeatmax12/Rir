<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize_input($_POST['name'] ?? '');
    $bio = sanitize_input($_POST['bio'] ?? '');
    $my_id = $_SESSION['user_id'];

    if (empty($name)) {
        $error = "Group name cannot be empty.";
    } else {
        $db = (new Database())->getConnection();
        try {
            $db->beginTransaction();

            // ১. গ্রুপ তৈরি করা
            $stmt = $db->prepare("INSERT INTO groups (name, bio, created_by) VALUES (:name, :bio, :my_id)");
            $stmt->execute([':name' => $name, ':bio' => $bio, ':my_id' => $my_id]);
            $group_id = $db->lastInsertId();

            // ২. মেকারকে এডমিন হিসেবে এড করা
            $stmt_mem = $db->prepare("INSERT INTO group_members (group_id, user_id, role) VALUES (:group_id, :my_id, 'Admin')");
            $stmt_mem->execute([':group_id' => $group_id, ':my_id' => $my_id]);

            $db->commit();
            $success = "Group created successfully!";
            header("Refresh: 1.5; url=view_group.php?id=" . $group_id);
        } catch (PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            $error = "DB Error: " . $e->getMessage();
        }
    }
}
?>

<div class="main-layout-container" style="max-width: 600px; display:block; padding: 16px;">
    <div style="background:var(--card-background); border-radius:8px; padding:24px; box-shadow:var(--shadow-sm);">
        <h2 style="margin-top:0; border-bottom:1px solid var(--divider-color); padding-bottom:12px;">Create New Group</h2>
        
        <?php if(!empty($error)): ?>
            <div class="error-alert" style="display:block;"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if(!empty($success)): ?>
            <div style="background-color:#d4edda; color:#155724; border:1px solid #c3e6cb; padding:12px; border-radius:6px; font-size:14px; margin-bottom:15px;"><?php echo $success; ?></div>
        <?php endif; ?>

        <form action="create_group.php" method="POST">
            <div style="margin-bottom:16px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Group Name</label>
                <input type="text" name="name" required style="width:100%; padding:10px; border-radius:6px; border:1px solid var(--border-color); box-sizing:border-box;">
            </div>

            <div style="margin-bottom:20px;">
                <label style="font-weight:600; display:block; margin-bottom:6px;">Group Description (Bio)</label>
                <textarea name="bio" style="width:100%; height:100px; padding:10px; border-radius:6px; border:1px solid var(--border-color); resize:none; font-family:var(--font-stack);" placeholder="What is this group about?"></textarea>
            </div>

            <button type="submit" class="btn-fb-primary btn-custom" style="width:100%; height:45px;">Create Group</button>
        </form>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>