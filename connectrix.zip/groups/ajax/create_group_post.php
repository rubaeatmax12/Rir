<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized.');
}

$group_id = intval($_POST['group_id'] ?? 0);
$content = sanitize_input($_POST['content'] ?? '');
$user_id = $_SESSION['user_id'];

if ($group_id === 0 || empty($content)) {
    send_json_response('error', 'Post content cannot be empty.');
}

$db = (new Database())->getConnection();

try {
    // ইউজার গ্রুপের সদস্য কিনা রি-ভেরিফাই করা
    $stmt = $db->prepare("SELECT user_id FROM group_members WHERE group_id = :g_id AND user_id = :u_id LIMIT 1");
    $stmt->execute([':g_id' => $group_id, ':u_id' => $user_id]);

    if ($stmt->rowCount() === 0) {
        send_json_response('error', 'You must be a member of this group to post.');
    }

    $insert_stmt = $db->prepare("INSERT INTO group_posts (group_id, user_id, content) VALUES (:g_id, :u_id, :content)");
    $result = $insert_stmt->execute([':g_id' => $group_id, ':u_id' => $user_id, ':content' => $content]);

    if ($result) {
        send_json_response('success', 'Group post published.');
    } else {
        send_json_response('error', 'Failed to publish post.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}