<?php
require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/database.php';
require_once dirname(__DIR__, 2) . '/includes/functions/auth_functions.php';
require_once dirname(__DIR__, 2) . '/includes/functions/sanitize_functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_logged_in()) {
    send_json_response('error', 'Unauthorized.');
}

$group_id = intval($_POST['group_id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($group_id === 0) {
    send_json_response('error', 'Invalid group.');
}

$db = (new Database())->getConnection();

try {
    // ইতিমধ্যে মেম্বার কিনা চেক করা
    $stmt = $db->prepare("SELECT user_id FROM group_members WHERE group_id = :g_id AND user_id = :u_id LIMIT 1");
    $stmt->execute([':g_id' => $group_id, ':u_id' => $user_id]);

    if ($stmt->rowCount() > 0) {
        send_json_response('error', 'Already joined in this group.');
    }

    $insert_stmt = $db->prepare("INSERT INTO group_members (group_id, user_id, role) VALUES (:g_id, :u_id, 'Member')");
    $result = $insert_stmt->execute([':g_id' => $group_id, ':u_id' => $user_id]);

    if ($result) {
        send_json_response('success', 'Joined successfully!');
    } else {
        send_json_response('error', 'Failed to join group.');
    }
} catch (PDOException $e) {
    send_json_response('error', 'DB error: ' . $e->getMessage());
}