<?php
require_once dirname(__DIR__) . '/includes/header.php';
require_once dirname(__DIR__) . '/includes/navbar.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions/date_functions.php';

echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/group/group-card.css">';
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/post/post-card.css">';

$group_id = intval($_GET['id'] ?? 0);
$my_id = $_SESSION['user_id'];
$db = (new Database())->getConnection();

// ১. গ্রুপের তথ্য তুলে আনা
$group_stmt = $db->prepare("SELECT * FROM groups WHERE id = :id LIMIT 1");
$group_stmt->execute([':id' => $group_id]);
$group = $group_stmt->fetch();

if (!$group) {
    echo '<div style="text-align:center; padding:50px;"><h2>Group not found.</h2><a href="index.php">Back to Groups</a></div>';
    require_once dirname(__DIR__) . '/includes/footer.php';
    exit();
}

// ২. আমি এই গ্রুপের মেম্বার কিনা তা চেক করা
$mem_stmt = $db->prepare("SELECT role FROM group_members WHERE group_id = :g_id AND user_id = :u_id LIMIT 1");
$mem_stmt->execute([':g_id' => $group_id, ':u_id' => $my_id]);
$is_member = $mem_stmt->rowCount() > 0;
$member_data = $mem_stmt->fetch();

// ৩. গ্রুপের টোটাল মেম্বার সংখ্যা কাউন্ট
$count_stmt = $db->prepare("SELECT COUNT(user_id) as total FROM group_members WHERE group_id = :g_id");
$count_stmt->execute([':g_id' => $group_id]);
$total_members = $count_stmt->fetch()['total'];

// ৪. শুধুমাত্র এই গ্রুপের পোস্টগুলো তুলে আনা
$posts_stmt = $db->prepare("SELECT gp.content, gp.created_at, u.first_name, u.last_name, u.profile_pic 
                            FROM group_posts gp 
                            JOIN users u ON gp.user_id = u.id 
                            WHERE gp.group_id = :g_id 
                            ORDER BY gp.created_at DESC");
$posts_stmt->execute([':g_id' => $group_id]);
$group_posts = $posts_stmt->fetchAll();
?>

<!-- Group Top Header Cover -->
<div class="group-header-container" style="max-width: 900px; margin: 0 auto;">
    <img class="group-big-cover" src="<?php echo SITE_URL; ?>/uploads/profile/default-cover.png" alt="Group Cover">
    <div class="group-header-details">
        <div>
            <h1 style="margin:0; font-size:28px;"><?php echo clean_output($group['name']); ?></h1>
            <p style="color:var(--text-secondary); margin:4px 0 0 0;"><i class="fa-solid fa-users"></i> <?php echo $total_members; ?> members</p>
        </div>
        <div>
            <?php if ($is_member): ?>
                <button class="btn-fb-secondary btn-custom"><i class="fa-solid fa-check"></i> Joined (<?php echo $member_data['role']; ?>)</button>
            <?php else: ?>
                <button onclick="joinGroupInView(<?php echo $group['id']; ?>, this)" class="btn-fb-primary btn-custom"><i class="fa-solid fa-user-plus"></i> Join Group</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Group Content Layout -->
<div class="main-layout-container" style="max-width: 900px; padding:0; display:grid; grid-template-columns: 1fr; gap: 16px;">
    
    <!-- যদি মেম্বার হয়, তবেই পোস্ট করার বক্স এবং পোস্টসমূহ দেখতে পাবে -->
    <?php if ($is_member): ?>
        <div style="background-color:var(--card-background); padding:16px; border-radius:8px; box-shadow:var(--shadow-sm);">
            <form id="groupPostForm">
                <input type="hidden" name="group_id" value="<?php echo $group_id; ?>">
                <textarea name="content" placeholder="Write something in this group..." required style="width:100%; height:70px; border:1px solid var(--border-color); border-radius:6px; padding:10px; resize:none; outline:none; font-family:var(--font-stack); box-sizing:border-box;"></textarea>
                <button type="submit" class="btn-fb-primary btn-custom" style="width:100%; margin-top:8px;">Post to Group</button>
            </form>
        </div>

        <!-- গ্রুপের ভেতরের পোস্ট ফিড -->
        <div class="group-feed-container">
            <?php if (count($group_posts) > 0): ?>
                <?php foreach ($group_posts as $post): ?>
                    <div class="post-card" style="margin-bottom:12px;">
                        <div class="post-header">
                            <div class="post-author-info">
                                <img class="post-author-avatar" src="<?php echo SITE_URL; ?>/uploads/profile/<?php echo clean_output($post['profile_pic']); ?>" alt="user">
                                <div>
                                    <span style="font-weight:600; font-size:14px;"><?php echo clean_output($post['first_name'] . ' ' . $post['last_name']); ?></span>
                                    <div class="post-meta">
                                        <span><?php echo get_time_ago($post['created_at']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="post-content" style="font-size:15px; line-height:1.4;">
                            <?php echo nl2br(clean_output($post['content'])); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="background:var(--card-background); padding:30px; border-radius:8px; text-align:center; color:var(--text-secondary);"><p>No posts in this group yet.</p></div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div style="background:var(--card-background); padding:40px; border-radius:8px; text-align:center; color:var(--text-secondary); box-shadow:var(--shadow-sm);">
            <i class="fa-solid fa-lock" style="font-size:48px; margin-bottom:12px;"></i>
            <h3>Private Group</h3>
            <p>Join this group to post and see group activities.</p>
        </div>
    <?php endif; ?>

</div>

<script>
// গ্রুপের মধ্যে পোস্ট সাবমিট করা
if (document.getElementById('groupPostForm')) {
    document.getElementById('groupPostForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        fetch('ajax/create_group_post.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message);
            }
        });
    });
}

function joinGroupInView(groupId, btn) {
    const formData = new FormData();
    formData.append('group_id', groupId);
    
    fetch('ajax/join_group.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            window.location.reload();
        } else {
            alert(data.message);
        }
    });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>