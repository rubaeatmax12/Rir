<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';

$step = 1; // ধাপ ১: যাচাই, ধাপ ২: পাসওয়ার্ড পরিবর্তন

// ১. তথ্য যাচাই লজিক
if (isset($_POST['verify_user'])) {
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND phone = ?");
    $stmt->execute([$email, $phone]);
    $user = $stmt->fetch();

    if ($user) {
        $step = 2; // তথ্য মিলেছে, এখন পাসওয়ার্ড বদলানো যাবে
        $user_id = $user['id'];
    } else {
        $error = "Email or Phone Number did not match!";
    }
}

// ২. পাসওয়ার্ড পরিবর্তন লজিক
if (isset($_POST['reset_password'])) {
    $new_pass = $_POST['new_pass'];
    $uid = $_POST['uid'];
    
    $hash_pass = password_hash($new_pass, PASSWORD_DEFAULT);
    
    $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash_pass, $uid]);
    
    echo "<script>alert('Password Changed Successfully! Login now.'); window.location='login.php';</script>";
}

require 'common/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-danger text-white text-center">
                <h4><i class="fas fa-lock-open"></i> Reset Password</h4>
            </div>
            <div class="card-body p-4">
                
                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <!-- ধাপ ১: পরিচয় যাচাই -->
                <?php if($step == 1): ?>
                    <p class="text-muted text-center">Enter your registered Email & Phone to reset password.</p>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="fw-bold">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold">Phone Number</label>
                            <input type="text" name="phone" class="form-control" placeholder="Enter your phone number" required>
                        </div>
                        <button type="submit" name="verify_user" class="btn btn-danger w-100">Verify User</button>
                    </form>
                
                <!-- ধাপ ২: নতুন পাসওয়ার্ড সেট -->
                <?php elseif($step == 2): ?>
                    <div class="alert alert-success text-center">Identity Verified! Set a new password.</div>
                    <form method="POST">
                        <input type="hidden" name="uid" value="<?php echo $user_id; ?>">
                        <div class="mb-3">
                            <label class="fw-bold">New Password</label>
                            <input type="password" name="new_pass" class="form-control" placeholder="Enter new password" required>
                        </div>
                        <button type="submit" name="reset_password" class="btn btn-success w-100">Change Password</button>
                    </form>
                <?php endif; ?>

            </div>
            <div class="card-footer text-center">
                <a href="login.php" class="text-decoration-none">Back to Login</a>
            </div>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>