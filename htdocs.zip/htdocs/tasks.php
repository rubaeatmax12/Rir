<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// 🔥 জাদুকরী কুয়েরি (SQL Query) 🔥
// এর মানে: "সেই টাস্কগুলোই দেখাও যা Active আছে, কিন্তু ইউজার এখনো সাবমিট করেনি।"
$sql = "SELECT * FROM tasks 
        WHERE status = 'active' 
        AND id NOT IN (
            SELECT task_id FROM task_submissions WHERE user_id = ?
        ) 
        ORDER BY id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$tasks = $stmt->fetchAll();

require 'common/header.php';
?>

<div class="d-flex align-items-center mb-3">
    <a href="dashboard.php" class="text-dark me-3"><i class="fas fa-arrow-left fa-lg"></i></a>
    <h4 class="m-0 fw-bold text-primary">Daily Tasks</h4>
</div>

<div class="row g-3">
    <?php if(count($tasks) == 0): ?>
        <div class="col-12 text-center py-5">
            <img src="https://cdn-icons-png.flaticon.com/512/7486/7486744.png" width="80" class="mb-3">
            <h5 class="text-muted">No tasks available right now!</h5>
            <p class="small text-secondary">Please wait for admin to add new tasks.</p>
        </div>
    <?php endif; ?>

    <?php foreach($tasks as $task): ?>
    <div class="col-md-4 col-sm-6">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="badge bg-primary"><?php echo ucfirst($task['type']); ?></span>
                    <span class="fw-bold text-success fs-5"><?php echo CURRENCY . $task['reward']; ?></span>
                </div>
                
                <h5 class="card-title fw-bold text-dark"><?php echo htmlspecialchars($task['title']); ?></h5>
                <p class="card-text text-muted small" style="height: 40px; overflow: hidden;">
                    <?php echo substr(htmlspecialchars($task['description']), 0, 60) . '...'; ?>
                </p>

                <div class="d-grid gap-2">
                    <!-- লিংক ওপেন করার বাটন -->
                    <a href="<?php echo $task['link']; ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-external-link-alt"></i> Open Link
                    </a>
                    
                    <!-- প্রুফ জমা দেওয়ার বাটন -->
                    <a href="submission_upload.php?task_id=<?php echo $task['id']; ?>" class="btn btn-success btn-sm">
                        <i class="fas fa-check-circle"></i> Submit Proof
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require 'common/footer.php'; ?>