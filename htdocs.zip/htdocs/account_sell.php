<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

// ফর্ম সাবমিট হলে ডাটাবেসে সেভ হবে
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type = $_POST['type'];
    $email = trim($_POST['email']);
    $pass = trim($_POST['password']);
    $price = $_POST['price']; 

    // ডাটাবেসে ইনসার্ট করা
    $sql = "INSERT INTO account_sales (user_id, type, email_or_phone, password, price, status) VALUES (?, ?, ?, ?, ?, 'pending')";
    $stmt = $pdo->prepare($sql);
    
    try {
        $stmt->execute([$_SESSION['user_id'], $type, $email, $pass, $price]);
        $msg = "Account submitted successfully! Wait for admin approval.";
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

require 'common/header.php';

// URL থেকে টাইপ ধরা (যেমন: sell_gmail.php থেকে আসলে অটো সিলেক্ট হবে)
$pre_select = $_GET['type'] ?? ''; 
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-warning text-dark">
                <i class="fas fa-store"></i> Sell Your Accounts
            </div>
            <div class="card-body">
                
                <!-- সফল বা এরর মেসেজ দেখানোর জায়গা -->
                <?php if(isset($msg)) showAlert($msg, 'success'); ?>
                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Select Account Type</label>
                        <!-- অটো সিলেক্ট লজিক এখানে যুক্ত করা হয়েছে -->
                        <select name="type" class="form-control form-select">
                            <option value="gmail" <?php if($pre_select=='gmail') echo 'selected'; ?>>Gmail Account</option>
                            <option value="facebook" <?php if($pre_select=='facebook') echo 'selected'; ?>>Facebook Account</option>
                            <option value="instagram" <?php if($pre_select=='instagram') echo 'selected'; ?>>Instagram Account</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email or Phone Number</label>
                        <input type="text" name="email" class="form-control" placeholder="Ex: myemail@gmail.com" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="text" name="password" class="form-control" placeholder="Account Password" required>
                        <small class="text-muted">We need password to verify the account ownership.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Asking Price (<?php echo CURRENCY; ?>)</label>
                        <input type="number" name="price" class="form-control" placeholder="Ex: 50" required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Submit for Sale</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>