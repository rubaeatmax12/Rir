<?php
require 'common/config.php';
// যদি ইউজার লগইন করা থাকে, তাকে ড্যাশবোর্ডে পাঠাবে
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .feature-icon {
            font-size: 3rem;
            color: #764ba2;
            margin-bottom: 20px;
        }
    </style>
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold text-primary" href="#"><?php echo SITE_NAME; ?></a>
    <div>
        <a href="login.php" class="btn btn-outline-primary me-2">Login</a>
        <a href="register.php" class="btn btn-primary">Register</a>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <h1 class="display-4 fw-bold mb-4">Earn Money From Home Easily</h1>
        <p class="lead mb-4">Complete simple tasks, watch videos, and sell social accounts to earn real cash.</p>
        <a href="register.php" class="btn btn-light btn-lg text-primary fw-bold px-5">Start Earning Now</a>
    </div>
</section>

<!-- Features -->
<section class="py-5">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4 mb-4">
                <i class="fas fa-tasks feature-icon"></i>
                <h3>Daily Tasks</h3>
                <p>Complete simple website visits and social media tasks to earn daily rewards.</p>
            </div>
            <div class="col-md-4 mb-4">
                <i class="fas fa-store feature-icon"></i>
                <h3>Sell Accounts</h3>
                <p>Sell your unused Gmail, Facebook, or Instagram accounts for a good price.</p>
            </div>
            <div class="col-md-4 mb-4">
                <i class="fas fa-users feature-icon"></i>
                <h3>Refer & Earn</h3>
                <p>Invite your friends and earn commission from their earnings lifetime.</p>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-4">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
        <div class="mt-2">
            <a href="support.php" class="text-white text-decoration-none mx-2">Contact Support</a>
            <a href="login.php" class="text-white text-decoration-none mx-2">Login</a>
        </div>
    </div>
</footer>

</body>
</html>
<div class="col-4">
    <a href="affiliate_admin.php" class="app-btn">
        <i class="fas fa-bullhorn text-danger"></i>
        <h6>Affiliate</h6>
    </a>
</div>