<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$user = $pdo->query("SELECT balance, security_pin FROM users WHERE id = $user_id")->fetch();
$balance = $user['balance'];

// ১. ইউজারের সেভ করা কার্ডগুলো আনা
$card_stmt = $pdo->prepare("SELECT * FROM user_cards WHERE user_id = ?");
$card_stmt->execute([$user_id]);
$saved_cards = $card_stmt->fetchAll();

// যদি কার্ড না থাকে, তবে কার্ড এড করতে পাঠাবে
if (count($saved_cards) == 0) {
    echo "<script>alert('Please add a withdrawal method first!'); window.location='user/add_card.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $card_id = $_POST['card_id']; // কোন কার্ড সিলেক্ট করেছে
    $amount = $_POST['amount'];
    $pin = $_POST['pin'];

    // সিলেক্ট করা কার্ডের ডিটেইলস আনা
    $sel_card = $pdo->prepare("SELECT * FROM user_cards WHERE id = ? AND user_id = ?");
    $sel_card->execute([$card_id, $user_id]);
    $card_info = $sel_card->fetch();

    if (!$card_info) {
        $error = "Invalid Card Selected!";
    } elseif ($pin !== $user['security_pin']) {
        $error = "Wrong Security PIN!";
    } elseif ($amount > $balance) {
        $error = "Insufficient Balance!";
    } elseif ($amount < 50) {
        $error = "Minimum withdrawal is 50 Tk.";
    } else {
        // উইথড্র প্রসেস
        $pdo->beginTransaction();
        try {
            $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user_id]);
            
            // কার্ড থেকে নম্বর নিয়ে সেভ করা হচ্ছে
            $stmt = $pdo->prepare("INSERT INTO withdrawals (user_id, amount, method, account_number, status) VALUES (?, ?, ?, ?, 'pending')");
            $stmt->execute([$user_id, $amount, $card_info['method_name'], $card_info['account_number']]);
            
            $pdo->commit();
            $success = "Withdrawal request sent successfully!";
            $balance -= $amount; 
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Something went wrong!";
        }
    }
}
require 'common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
                <span>Withdraw Money</span>
                <a href="user/add_card.php" class="btn btn-light btn-sm text-dark fw-bold">+ Add Card</a>
            </div>
            <div class="card-body">
                <div class="alert alert-info text-center">
                    Balance: <strong class="fs-4"><?php echo CURRENCY . number_format($balance, 2); ?></strong>
                </div>
                
                <?php if(isset($error)) showAlert($error, 'danger'); ?>
                <?php if(isset($success)) showAlert($success, 'success'); ?>

                <form method="POST">
                    <!-- কার্ড সিলেক্ট অপশন -->
                    <div class="mb-3">
                        <label class="form-label">Select Wallet</label>
                        <select name="card_id" class="form-control form-select" required>
                            <option value="">-- Choose Account --</option>
                            <?php foreach($saved_cards as $c): ?>
                                <option value="<?php echo $c['id']; ?>">
                                    <?php echo $c['method_name']; ?> - <?php echo $c['account_number']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Amount</label>
                        <input type="number" name="amount" class="form-control" placeholder="Min: 50" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold text-danger">Security PIN</label>
                        <input type="password" name="pin" class="form-control text-center" placeholder="XXXX" maxlength="4" required>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-danger">Confirm & Withdraw</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="text-center mt-3">
            <a href="user/withdraw_history.php" class="btn btn-outline-secondary btn-sm">View History</a>
        </div>
    </div>
</div>
<?php require 'common/footer.php'; ?>