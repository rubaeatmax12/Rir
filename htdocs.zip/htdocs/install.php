<?php
// ডাটাবেস কানেকশন ফাইল লোড করা
require 'common/db.php';

// সম্পূর্ণ ডাটাবেস স্কিমা (সব টেবিল একসাথে)
$sql = "
-- ১. ইউজার টেবিল (সব ফিচার সহ)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) UNIQUE,
    password VARCHAR(255) NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00,
    usdt_balance DECIMAL(10,4) DEFAULT 0.0000,
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive', 'ban') DEFAULT 'inactive',
    ref_code VARCHAR(20) UNIQUE,
    referrer_id INT DEFAULT NULL,
    profile_pic VARCHAR(255) DEFAULT NULL,
    vip_level VARCHAR(20) DEFAULT 'Free',
    last_daily_bonus DATE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ২. সেটিংস টেবিল (সব কন্ট্রোল এখানে)
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    site_name VARCHAR(100) DEFAULT 'AlphaEarner',
    currency VARCHAR(10) DEFAULT 'BDT',
    notice TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    whatsapp VARCHAR(20),
    telegram VARCHAR(100),
    whatsapp_group VARCHAR(255),
    fb_page VARCHAR(255),
    fb_group VARCHAR(255),
    app_status ENUM('on', 'off') DEFAULT 'on',
    activation_fee DECIMAL(10,2) DEFAULT 100.00,
    ref_bonus DECIMAL(10,2) DEFAULT 5.00,
    aviator_limit DECIMAL(10,2) DEFAULT 2.00,
    rate_gmail DECIMAL(10,2) DEFAULT 5.00,
    pass_gmail VARCHAR(100) DEFAULT 'Gmail123',
    rate_facebook DECIMAL(10,2) DEFAULT 10.00,
    pass_facebook VARCHAR(100) DEFAULT 'Fb123',
    rate_instagram DECIMAL(10,2) DEFAULT 12.00,
    pass_instagram VARCHAR(100) DEFAULT 'Insta123'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ডিফল্ট সেটিংস ইনসার্ট (যদি না থাকে)
INSERT INTO settings (id, site_name, notice) 
SELECT 1, 'AlphaEarner', 'Welcome to our App!' 
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE id = 1);

-- ৩. ডিপোজিট এবং উইথড্র টেবিল
CREATE TABLE IF NOT EXISTS deposits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    method VARCHAR(50),
    sender_number VARCHAR(20),
    trx_id VARCHAR(50),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    method VARCHAR(50),
    account_number VARCHAR(50),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS deposit_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(50),
    number VARCHAR(20),
    type ENUM('personal', 'agent'),
    is_active TINYINT DEFAULT 1
);

-- ৪. টাস্ক এবং জব টেবিল
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    link VARCHAR(255),
    reward DECIMAL(10,2) NOT NULL,
    type ENUM('video', 'social', 'website') DEFAULT 'website',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS task_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    task_id INT NOT NULL,
    proof_img VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    description TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    link TEXT,
    quantity INT NOT NULL,
    rate DECIMAL(10,2) NOT NULL,
    total_cost DECIMAL(10,2) NOT NULL,
    status ENUM('active', 'finished') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS job_proofs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    worker_id INT NOT NULL,
    proof_text TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ৫. অ্যাকাউন্ট সেলিং টেবিল
CREATE TABLE IF NOT EXISTS account_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    email_or_phone VARCHAR(100),
    password VARCHAR(100),
    price DECIMAL(10,2),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ৬. সোশ্যাল মিডিয়া এবং চ্যাট
CREATE TABLE IF NOT EXISTS social_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS social_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    post_id INT NOT NULL
);

CREATE TABLE IF NOT EXISTS social_comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    post_id INT NOT NULL,
    comment TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS social_follows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    follower_id INT NOT NULL,
    following_id INT NOT NULL
);

CREATE TABLE IF NOT EXISTS public_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS private_chats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    is_read TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ৭. ভিডিও জোন
CREATE TABLE IF NOT EXISTS app_videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    video_file VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS video_likes (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, video_id INT);
CREATE TABLE IF NOT EXISTS video_comments (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, video_id INT, comment TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci);

-- ৮. শপ এবং অ্যাফিলিয়েট
CREATE TABLE IF NOT EXISTS digital_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT 0,
    title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    description TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    price DECIMAL(10,2),
    image VARCHAR(255),
    file_path VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS product_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    price DECIMAL(10,2),
    delivery_name VARCHAR(100),
    delivery_phone VARCHAR(20),
    delivery_address TEXT,
    status ENUM('pending', 'delivered') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS affiliate_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    product_link TEXT,
    image VARCHAR(255),
    commission DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS affiliate_clicks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ৯. গেম, লোন, গিফট এবং অন্যান্য
CREATE TABLE IF NOT EXISTS vip_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    price DECIMAL(10,2),
    daily_limit INT,
    validity_days INT
);

INSERT INTO vip_plans (name, price, daily_limit, validity_days) VALUES 
('Silver', 500, 10, 30), ('Gold', 1000, 25, 30), ('Diamond', 2000, 50, 60);

CREATE TABLE IF NOT EXISTS gift_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(10,2),
    message VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    message TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    is_read TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS loan_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(10,2),
    reason VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    status ENUM('pending', 'approved', 'rejected', 'repaid') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transfer_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT,
    receiver_id INT,
    amount DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS recharge_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    phone VARCHAR(20),
    operator VARCHAR(20),
    amount DECIMAL(10,2),
    status ENUM('pending', 'success', 'failed'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS p2p_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT,
    amount_usdt DECIMAL(10,2),
    price_per_usdt DECIMAL(10,2),
    total_bdt DECIMAL(10,2),
    status ENUM('active', 'sold', 'cancelled') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS game_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    game_name VARCHAR(50) DEFAULT 'Aviator/Ludo',
    entry_fee DECIMAL(10,2),
    winning_amount DECIMAL(10,2),
    result VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS aviator_games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    bet_amount DECIMAL(10,2),
    crash_point DECIMAL(10,2),
    cash_out_point DECIMAL(10,2),
    win_amount DECIMAL(10,2),
    status ENUM('running', 'crashed', 'cashed_out'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tv_channels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    logo VARCHAR(255),
    stream_url TEXT,
    category VARCHAR(50),
    status ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS support_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    sender ENUM('user', 'admin'),
    message TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS banners (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_path VARCHAR(255),
    link VARCHAR(255),
    is_active TINYINT DEFAULT 1
);

CREATE TABLE IF NOT EXISTS promo_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE,
    amount DECIMAL(10,2),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS promo_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    promo_id INT,
    claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
";

try {
    // মাল্টিপল কুয়েরি চালানোর জন্য
    $pdo->exec($sql);
    echo "<h1 style='color:green; text-align:center; margin-top:50px;'>🎉 Congratulations! All Tables Created Successfully! 🎉</h1>";
    echo "<h3 style='text-align:center;'>Now DELETE this install.php file and start your app.</h3>";
    echo "<center><a href='index.php' style='padding:10px 20px; background:blue; color:white; text-decoration:none; border-radius:5px;'>Go to Home</a></center>";
} catch (PDOException $e) {
    echo "<h1 style='color:red; text-align:center;'>Error: " . $e->getMessage() . "</h1>";
}
?>