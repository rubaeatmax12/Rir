<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$user_info = $pdo->prepare("SELECT username, ref_code FROM users WHERE id = ?");
$user_info->execute([$user_id]);
$me = $user_info->fetch();

// রিকার্সিভ ফাংশন রেফারেল ট্রি জেনারেট করার জন্য
function getReferrals($pdo, $referrer_id) {
    $stmt = $pdo->prepare("SELECT id, username FROM users WHERE referrer_id = ?");
    $stmt->execute([$referrer_id]);
    $users = $stmt->fetchAll();

    if (count($users) > 0) {
        echo "<ul>";
        foreach ($users as $u) {
            echo "<li>";
            echo "<span class='tf-nc'>" . htmlspecialchars($u['username']) . "</span>";
            getReferrals($pdo, $u['id']); // নিজে নিজেই কল হবে (Recursive)
            echo "</li>";
        }
        echo "</ul>";
    }
}

require 'common/header.php';
?>

<!-- Tree CSS (Inline for simplicity) -->
<style>
.tf-tree { text-align: center; overflow: auto; }
.tf-tree ul { display: inline-flex; margin: 0; padding: 0; }
.tf-tree li { align-items: center; display: flex; flex-direction: column; flex-wrap: wrap; padding: 0 1em; position: relative; }
.tf-tree li ul { margin: 2em 0; }
.tf-tree li li:before { border-top: .0625em solid #000; content: ""; display: block; height: .0625em; left: -.5em; position: absolute; top: -1.03125em; width: 100%; }
.tf-tree li li:first-child:before { left: 50%; max-width: 50%; }
.tf-tree li li:last-child:before { left: auto; max-width: 50%; right: 50%; }
.tf-tree li li:only-child:before { display: none; }
.tf-tree li li:only-child > .tf-nc:before, .tf-tree li li:only-child > .tf-node-content:before { height: 1.0625em; top: -1.0625em; }
.tf-tree .tf-nc, .tf-tree .tf-node-content { border: .0625em solid #000; display: inline-block; padding: .5em 1em; position: relative; border-radius: 5px; background: white; }
.tf-tree .tf-nc:before, .tf-tree .tf-node-content:before { border-left: .0625em solid #000; content: ""; display: block; height: 1em; left: 50%; position: absolute; top: -1em; width: .0625em; }
.tf-tree .tf-nc:after, .tf-tree .tf-node-content:after { border-left: .0625em solid #000; content: ""; display: block; height: 1em; left: 50%; position: absolute; top: 100%; width: .0625em; }
.tf-tree .tf-nc:only-child:after, .tf-tree .tf-node-content:only-child:after, .tf-tree > ul > li > .tf-nc:before, .tf-tree > ul > li > .tf-node-content:before { display: none; }
</style>

<div class="card">
    <div class="card-header">My Referral Tree</div>
    <div class="card-body">
        <div class="tf-tree tf-gap-sm">
            <ul>
                <li>
                    <span class="tf-nc bg-primary text-white fw-bold"><?php echo $me['username']; ?> (Me)</span>
                    <?php getReferrals($pdo, $user_id); ?>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>