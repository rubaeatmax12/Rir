<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// বর্তমান প্ল্যান চেক করা
$stmt = $pdo->prepare("SELECT balance, vip_level FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// প্ল্যান কেনার লজিক
if (isset($_GET['buy'])) {
    $plan_id = $_GET['buy'];
    
    // প্ল্যানের দাম জানা
    $p_stmt = $pdo->prepare("SELECT * FROM vip_plans WHERE id = ?");
    $p_stmt->execute([$plan_id]);
    $plan = $p_stmt->fetch();

    if ($plan) {
        if ($user['balance'] >= $plan['price']) {
            // টাকা কাটা এবং প্ল্যান সেট করা
            $pdo->prepare("UPDATE users SET balance = balance - ?, vip_level = ? WHERE id = ?")
                ->execute([$plan['price'], $plan['name'], $user_id]);
            
            echo "<script>alert('VIP Plan Purchased Successfully!'); window.location='vip_plans.php';</script>";
        } else {
            $error = "Insufficient Balance! Please Recharge.";
        }
    }
}

// সব প্ল্যান আনা
$plans = $pdo->query("SELECT * FROM vip_plans")->fetchAll();

require 'common/header.php';
?>

<div class="text-center mb-4">
    <h2><i class="fas fa-crown text-warning"></i> VIP Membership</h2>
    <p>Current Plan: <span class="badge bg-success"><?php echo $user['vip_level']; ?></span> | Balance: <?php echo CURRENCY . $user['balance']; ?></p>
    <?php if(isset($error)) showAlert($error, 'danger'); ?>
</div>

<div class="row">
    <?php foreach($plans as $p): ?>
    <div class="col-md-4 mb-4">
        <div class="card shadow h-100 border-primary">
            <div class="card-header bg-primary text-white text-center">
                <h4><?php echo $p['name']; ?></h4>
            </div>
            <div class="card-body text-center">
                <h1 class="card-title text-primary"><?php echo CURRENCY . $p['price']; ?></h1>
                <ul class="list-group list-group-flush mb-3">
                    <li class="list-group-item">Daily Task Limit: <strong><?php echo $p['daily_limit']; ?></strong></li>
                    <li class="list-group-item">Validity: <strong><?php echo $p['validity_days']; ?> Days</strong></li>
                    <li class="list-group-item">Premium Support</li>
                </ul>
                <?php if($user['vip_level'] == $p['name']): ?>
                    <button class="btn btn-secondary disabled w-100">Current Plan</button>
                <?php else: ?>
                    <a href="?buy=<?php echo $p['id']; ?>" class="btn btn-outline-primary w-100" onclick="return confirm('Confirm buy <?php echo $p['name']; ?> plan?')">Buy Now</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require 'common/footer.php'; ?>