<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM account_sales WHERE user_id = ? ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$accounts = $stmt->fetchAll();

require 'common/header.php';
?>

<div class="card">
    <div class="card-header"><i class="fas fa-list"></i> My Sold Accounts History</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Account Info</th>
                        <th>Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($accounts) > 0): ?>
                        <?php foreach($accounts as $acc): ?>
                        <tr>
                            <td><?php echo date('d M Y', strtotime($acc['created_at'])); ?></td>
                            <td><?php echo ucfirst($acc['type']); ?></td>
                            <td><?php echo htmlspecialchars($acc['email_or_phone']); ?></td>
                            <td><?php echo CURRENCY . $acc['price']; ?></td>
                            <td>
                                <?php 
                                    if($acc['status'] == 'approved') echo '<span class="badge bg-success">Sold & Paid</span>';
                                    elseif($acc['status'] == 'rejected') echo '<span class="badge bg-danger">Rejected</span>';
                                    else echo '<span class="badge bg-warning text-dark">Pending Review</span>';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center">No accounts submitted yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>