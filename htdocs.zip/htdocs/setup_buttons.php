<?php
require 'common/db.php';

// ১. টেবিল তৈরি
$sql = "CREATE TABLE IF NOT EXISTS app_buttons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    link VARCHAR(100),
    icon VARCHAR(255),
    section VARCHAR(50), -- earning, finance, games, others
    status ENUM('active', 'inactive') DEFAULT 'active'
)";
$pdo->exec($sql);

// ২. বাটনগুলোর লিস্ট (সব বাটন এখানে আছে)
$buttons = [
    // Earning Section
    ['Daily Work', 'tasks.php', 'https://cdn-icons-png.flaticon.com/512/2098/2098276.png', 'earning'],
    ['Micro Jobs', 'user/micro_jobs.php', 'https://cdn-icons-png.flaticon.com/512/2910/2910791.png', 'earning'],
    ['Post Job', 'user/post_job.php', 'https://cdn-icons-png.flaticon.com/512/1995/1995515.png', 'earning'],
    ['Manage Jobs', 'user/manage_jobs.php', 'https://cdn-icons-png.flaticon.com/512/1570/1570917.png', 'earning'],
    
    // Selling Section
    ['Sell Gmail', 'sell_specific.php?type=gmail', 'https://cdn-icons-png.flaticon.com/512/732/732200.png', 'selling'],
    ['Sell FB', 'sell_specific.php?type=facebook', 'https://cdn-icons-png.flaticon.com/512/5968/5968764.png', 'selling'],
    ['Sell Insta', 'sell_specific.php?type=instagram', 'https://cdn-icons-png.flaticon.com/512/2111/2111463.png', 'selling'],
    ['Resell', 'user/sell_item.php', 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png', 'selling'],

    // Finance Section
    ['Deposit', 'user/recharge.php', 'https://cdn-icons-png.flaticon.com/512/2331/2331941.png', 'finance'],
    ['Withdraw', 'withdraw.php', 'https://cdn-icons-png.flaticon.com/512/950/950237.png', 'finance'],
    ['Transfer', 'user/transfer.php', 'https://cdn-icons-png.flaticon.com/512/2534/2534204.png', 'finance'],
    ['Get Loan', 'user/loan.php', 'https://cdn-icons-png.flaticon.com/512/2454/2454269.png', 'finance'],
    ['Crypto', 'user/crypto_wallet.php', 'https://cdn-icons-png.flaticon.com/512/2152/2152349.png', 'finance'],
    ['P2P Trade', 'user/p2p.php', 'https://cdn-icons-png.flaticon.com/512/2620/2620601.png', 'finance'],
    ['Recharge', 'user/mobile_recharge.php', 'https://cdn-icons-png.flaticon.com/512/2333/2333346.png', 'finance'],

    // Games & Media (এগুলো আপনি কন্ট্রোল করতে চান)
    ['Aviator', 'user/aviator.php', 'https://cdn-icons-png.flaticon.com/512/7893/7893979.png', 'games'],
    ['Ludo Game', 'user/ludo.php', 'https://cdn-icons-png.flaticon.com/512/802/802183.png', 'games'],
    ['Video Zone', 'user/video_feed.php', 'https://cdn-icons-png.flaticon.com/512/3670/3670147.png', 'games'],
    ['Live TV', 'user/live_tv.php', 'https://cdn-icons-png.flaticon.com/512/3163/3163478.png', 'games'],

    // Others
    ['VIP Plans', 'vip_plans.php', 'https://cdn-icons-png.flaticon.com/512/6941/6941697.png', 'others'],
    ['My Gift', 'user/my_gifts.php', 'https://cdn-icons-png.flaticon.com/512/4213/4213958.png', 'others'],
    ['Support', 'user/support.php', 'https://cdn-icons-png.flaticon.com/512/4233/4233839.png', 'others'],
    ['My Team', 'referrals.php', 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png', 'others'],
    ['Coupon', 'user/promo.php', 'https://cdn-icons-png.flaticon.com/512/726/726476.png', 'others'],
    ['Live Proof', 'user/live_payments.php', 'https://cdn-icons-png.flaticon.com/512/2454/2454282.png', 'others'],
    ['Public Chat', 'user/public_chat.php', 'https://cdn-icons-png.flaticon.com/512/1041/1041916.png', 'others'],
    ['Inbox', 'user/chat.php', 'https://cdn-icons-png.flaticon.com/512/1041/1041916.png', 'others'],
    ['Shop', 'user/shop.php', 'https://cdn-icons-png.flaticon.com/512/3081/3081559.png', 'others'],
    ['Affiliate', 'user/affiliate.php', 'https://cdn-icons-png.flaticon.com/512/1992/1992516.png', 'others'],
    ['Call', 'user/contacts.php', 'https://cdn-icons-png.flaticon.com/512/3059/3059502.png', 'others'],
    ['Downloader', 'user/downloader.php', 'https://cdn-icons-png.flaticon.com/512/724/724933.png', 'others'],
    ['Orders', 'user/my_orders.php', 'https://cdn-icons-png.flaticon.com/512/3500/3500833.png', 'others'],
    ['Reviews', 'user/reviews.php', 'https://cdn-icons-png.flaticon.com/512/1484/1484560.png', 'others']
];

$stmt = $pdo->prepare("INSERT INTO app_buttons (name, link, icon, section) VALUES (?, ?, ?, ?)");

// চেক করা যাতে ডুপ্লিকেট না হয়
$check = $pdo->prepare("SELECT count(*) FROM app_buttons");
$check->execute();
if ($check->fetchColumn() == 0) {
    foreach ($buttons as $btn) {
        $stmt->execute($btn);
    }
    echo "<h1>All Buttons Setup Successfully! ✅</h1>";
    echo "<p>Now go to Admin Panel > Button Control.</p>";
} else {
    echo "<h1>Buttons already setup!</h1>";
}
?>