<?php
require '../common/config.php';
require '../common/db.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(['status'=>'error']); exit; }

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

// ১. গেম শুরু করা (BET)
if ($action == 'bet') {
    $amount = $_POST['amount'];
    
    // ব্যালেন্স চেক
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetchColumn();

    if ($balance < $amount) {
        echo json_encode(['status' => 'error', 'message' => 'Insufficient Balance!']);
        exit;
    }

    // 🔥 অ্যাডমিনের সেট করা লিমিট আনা 🔥
    $set_stmt = $pdo->query("SELECT aviator_limit FROM settings LIMIT 1");
    $admin_limit = $set_stmt->fetchColumn(); 
    
    // যদি অ্যাডমিন কিছু সেট না করে থাকে তবে ডিফল্ট ২.০০ ধরবে
    if(!$admin_limit || $admin_limit < 1.1) { $admin_limit = 2.00; }

    // 🔥 নতুন অ্যালগরিদম: ১.০০ থেকে অ্যাডমিনের লিমিট পর্যন্ত র‍্যান্ডম সংখ্যা 🔥
    // উদাহরণ: অ্যাডমিন ২.০০ দিলে, সংখ্যা হতে পারে ১.১২, ১.৮৯, ১.৯৯ কিন্তু ২.০১ হবে না।
    
    $crash_point = rand(100, ($admin_limit * 100)) / 100;

    // মাঝে মাঝে ১.০০ তেই ক্র্যাশ করবে (হাউজ প্রফিট ১০% চান্স)
    if(rand(1, 10) == 1) { $crash_point = 1.00; }

    // টাকা কাটা
    $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user_id]);

    // গেম সেভ করা
    $sql = "INSERT INTO aviator_games (user_id, bet_amount, crash_point, status) VALUES (?, ?, ?, 'running')";
    $pdo->prepare($sql)->execute([$user_id, $amount, $crash_point]);
    $game_id = $pdo->lastInsertId();

    echo json_encode([
        'status' => 'success',
        'game_id' => $game_id,
        'crash_point' => $crash_point, 
        'new_balance' => $balance - $amount
    ]);
}

// ২. টাকা তোলা (CASH OUT) - আগের মতোই থাকবে
if ($action == 'cashout') {
    $game_id = $_POST['game_id'];
    $current_mult = $_POST['multiplier'];

    $stmt = $pdo->prepare("SELECT * FROM aviator_games WHERE id = ? AND user_id = ?");
    $stmt->execute([$game_id, $user_id]);
    $game = $stmt->fetch();

    if ($game && $game['status'] == 'running') {
        if ($current_mult < $game['crash_point']) {
            $win_amount = $game['bet_amount'] * $current_mult;
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$win_amount, $user_id]);
            $pdo->prepare("UPDATE aviator_games SET status = 'cashed_out', cash_out_point = ?, win_amount = ? WHERE id = ?")->execute([$current_mult, $win_amount, $game_id]);
            echo json_encode(['status' => 'success', 'win_amount' => $win_amount]);
        } else {
            $pdo->prepare("UPDATE aviator_games SET status = 'crashed' WHERE id = ?")->execute([$game_id]);
            echo json_encode(['status' => 'crashed']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Game ended']);
    }
}
?>