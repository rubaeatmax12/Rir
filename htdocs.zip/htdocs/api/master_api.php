<?php
// ফাইল: api/master_api.php

// সিকিউরিটি হেডার (যাতে ব্লক না খায়)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Content-Type: application/json');

require '../common/config.php';
require '../common/db.php';

// ১. তোমার গোপন পাসওয়ার্ড
$secret_key = "MySuperSecretKey2025"; 

$pass = $_POST['key'] ?? '';
$action = $_POST['action'] ?? '';

// পাসওয়ার্ড ভুল হলে এক্সেস নেই
if ($pass !== $secret_key) {
    echo json_encode(['status' => 'error', 'message' => 'Wrong Key! Access Denied.']);
    exit;
}

try {
    // ২. সব অ্যাডমিন দেখার লিস্ট
    if ($action == 'get_admins') {
        $stmt = $pdo->query("SELECT id, username, email FROM users WHERE role = 'admin'");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // ৩. কাউকে নতুন অ্যাডমিন বানানো
    elseif ($action == 'make_admin') {
        $email = $_POST['email'];
        // চেক করা ইউজার আছে কিনা
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if($check->rowCount() > 0) {
            $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE email = ?");
            $stmt->execute([$email]);
            echo json_encode(['status' => 'success', 'message' => "$email is now Admin!"]);
        } else {
            echo json_encode(['status' => 'error', 'message' => "User not found!"]);
        }
    }

    // ৪. অ্যাডমিন রিমুভ করা
    elseif ($action == 'remove_admin') {
        $email = $_POST['email'];
        $stmt = $pdo->prepare("UPDATE users SET role = 'user' WHERE email = ?");
        $stmt->execute([$email]);
        echo json_encode(['status' => 'success', 'message' => "$email removed from Admin!"]);
    }

    // ৫. ইউজারদের ব্যালেন্স দেখা
    elseif ($action == 'get_users') {
        $stmt = $pdo->query("SELECT username, email, balance, role FROM users ORDER BY id DESC LIMIT 50");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Action']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>