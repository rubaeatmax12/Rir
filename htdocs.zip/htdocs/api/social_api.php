<?php
require '../common/config.php';
require '../common/db.php';

if (!isset($_SESSION['user_id'])) { exit; }
$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

// ১. লাইক দেওয়া/নেওয়া
if ($action == 'like') {
    $pid = $_POST['post_id'];
    
    $check = $pdo->prepare("SELECT id FROM social_likes WHERE user_id = ? AND post_id = ?");
    $check->execute([$user_id, $pid]);
    
    if ($check->rowCount() > 0) {
        // আনলাইক
        $pdo->prepare("DELETE FROM social_likes WHERE user_id = ? AND post_id = ?")->execute([$user_id, $pid]);
        echo json_encode(['status' => 'unliked']);
    } else {
        // লাইক
        $pdo->prepare("INSERT INTO social_likes (user_id, post_id) VALUES (?, ?)")->execute([$user_id, $pid]);
        echo json_encode(['status' => 'liked']);
    }
}

// ২. ফলো করা/আনফলো করা
if ($action == 'follow') {
    $fid = $_POST['follow_id'];
    
    $check = $pdo->prepare("SELECT id FROM social_follows WHERE follower_id = ? AND following_id = ?");
    $check->execute([$user_id, $fid]);
    
    if ($check->rowCount() > 0) {
        $pdo->prepare("DELETE FROM social_follows WHERE follower_id = ? AND following_id = ?")->execute([$user_id, $fid]);
        echo json_encode(['status' => 'unfollowed', 'msg' => 'Unfollowed successfully']);
    } else {
        $pdo->prepare("INSERT INTO social_follows (follower_id, following_id) VALUES (?, ?)")->execute([$user_id, $fid]);
        echo json_encode(['status' => 'followed', 'msg' => 'Followed successfully']);
    }
}
?>