<?php
require '../common/config.php';
require '../common/db.php';

if (!isset($_SESSION['user_id'])) { exit; }

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if ($action == 'send') {
    $message = trim($_POST['message']);
    $role = ($_SESSION['role'] == 'admin') ? 'admin' : 'user';
    
    if (!empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO public_chat (user_id, message, role) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $message, $role]);
    }
}

if ($action == 'fetch') {
    $stmt = $pdo->query("SELECT c.*, u.username FROM public_chat c JOIN users u ON c.user_id = u.id ORDER BY c.id DESC LIMIT 50");
    $chats = $stmt->fetchAll();
    
    // উল্টো করে লুপ চালানো (যাতে নতুন মেসেজ নিচে থাকে)
    for($i=count($chats)-1; $i>=0; $i--) {
        $c = $chats[$i];
        $is_me = ($c['user_id'] == $user_id) ? 'me' : 'other';
        $admin_badge = ($c['role'] == 'admin') ? ' <span class="badge bg-danger" style="font-size:8px;">Admin</span>' : '';
        
        echo '<div class="chat-message '.$is_me.'">
                <div>
                    <small style="font-size:10px; font-weight:bold;">'.htmlspecialchars($c['username']).$admin_badge.'</small>
                    <div class="msg-box">'.htmlspecialchars($c['message']).'</div>
                </div>
              </div>';
    }
}
?>