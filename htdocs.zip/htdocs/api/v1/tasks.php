<?php
header('Content-Type: application/json');
require '../../common/config.php';
require '../../common/db.php';

// অথেন্টিকেশন চেক (Token বা User ID দিয়ে করা উচিত, এখানে সরলতার জন্য শুধু GET প্যারামিটার দেখা হচ্ছে)
$user_id = $_GET['user_id'] ?? null;

if (!$user_id) {
    echo json_encode(['status' => 'error', 'message' => 'User ID required']);
    exit;
}

// টাস্ক ফেচ লজিক
$sql = "SELECT * FROM tasks WHERE id NOT IN (SELECT task_id FROM task_submissions WHERE user_id = ?) AND status = 'active'";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'status' => 'success',
    'count' => count($tasks),
    'tasks' => $tasks
]);
?>