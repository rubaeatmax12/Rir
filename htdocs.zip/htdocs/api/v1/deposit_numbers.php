<?php
header('Content-Type: application/json');
require '../../common/config.php';
require '../../common/db.php';

// সব অ্যাকটিভ পেমেন্ট মেথড রিটার্ন করবে
try {
    $stmt = $pdo->query("SELECT method_name, number, type FROM deposit_methods WHERE is_active = 1");
    $methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'status' => 'success',
        'data' => $methods
    ]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>