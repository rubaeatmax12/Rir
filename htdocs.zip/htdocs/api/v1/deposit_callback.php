<?php
// এটি ব্রাউজারে খোলার জন্য নয়, এটি ব্যাকগ্রাউন্ডে কল হবে (IPN)
require '../../common/config.php';
require '../../common/db.php';

// লগ সেভ করা (ডিবাগিং এর জন্য)
file_put_contents('ipn_log.txt', file_get_contents('php://input') . PHP_EOL, FILE_APPEND);

// ইনকামিং ডাটা ধরা
$data = json_decode(file_get_contents('php://input'), true);

// উদাহরণ: bKash বা অন্য গেটওয়ে থেকে ডাটা আসলে
if (isset($data['trxID']) && isset($data['paymentID'])) {
    $trxID = $data['trxID'];
    $status = $data['transactionStatus']; // 'Completed'
    $amount = $data['amount'];

    if ($status == 'Completed') {
        // ট্রানজেকশন আইডি চেক করা
        $stmt = $pdo->prepare("SELECT * FROM deposits WHERE trx_id = ? AND status = 'pending'");
        $stmt->execute([$trxID]);
        $deposit = $stmt->fetch();

        if ($deposit) {
            // ব্যালেন্স আপডেট
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount, $deposit['user_id']]);
            // ডিপোজিট স্ট্যাটাস আপডেট
            $pdo->prepare("UPDATE deposits SET status = 'approved' WHERE id = ?")->execute([$deposit['id']]);
            
            echo json_encode(['status' => 'success', 'message' => 'Deposit Updated']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid TrxID or Already Paid']);
        }
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Data']);
}
?>