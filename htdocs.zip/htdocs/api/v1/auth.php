<?php
header('Content-Type: application/json');
require '../../common/config.php';
require '../../common/db.php';

// Allow POST only
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Method']);
    exit;
}

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Login Successful',
        'user_id' => $user['id'],
        'username' => $user['username'],
        'balance' => $user['balance']
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Credentials']);
}
?>