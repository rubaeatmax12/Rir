<?php
require '../common/config.php';
require '../common/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $amount = $_POST['amount'];
    $win_amount = $amount * 1.8;

    // ১. ব্যালেন্স চেক
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetchColumn();

    if ($balance < $amount) {
        echo json_encode(['status' => 'error', 'msg' => 'Insufficient Balance']);
        exit;
    }

    // ২. খেলার রেজাল্ট (লজিক: ৪০% জেতার চান্স)
    // ইউজার জিতবে যদি র‍্যান্ডম সংখ্যা ৬০ এর বেশি হয় (তুমি চাইলে এটা বাড়াতে/কমাতে পারো)
    $chance = rand(1, 100);
    
    if ($chance > 60) {
        // ইউজার জিতবে
        $user_score = rand(4, 6); // ৪, ৫ অথবা ৬
        $comp_score = rand(1, 3); // ১, ২ অথবা ৩
        $status = 'win';
        $msg = "You Won " . CURRENCY . $win_amount . "!";
        
        // টাকা আপডেট (লাভ যোগ হবে)
        $profit = $win_amount - $amount; // শুধু লাভটুকু যোগ হবে কারণ এন্ট্রি ফি কাটা হয়নি
        $new_bal = $amount + $profit; // না, আসলে আগে কাটতে হবে তারপর দিতে হবে।
        
        // লজিক: ব্যালেন্স থেকে এন্ট্রি ফি কাটা হবে, তারপর উইনিং এমাউন্ট দেওয়া হবে
        $pdo->prepare("UPDATE users SET balance = balance - ? + ? WHERE id = ?")->execute([$amount, $win_amount, $user_id]);
        
    } else {
        // ইউজার হারবে
        $user_score = rand(1, 3);
        $comp_score = rand(4, 6);
        $status = 'lose';
        $msg = "You Lost " . CURRENCY . $amount . "!";
        
        // শুধু টাকা কাটা যাবে
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user_id]);
        $win_amount = 0;
    }

    // ৩. হিস্ট্রি সেভ
    $sql = "INSERT INTO game_history (user_id, entry_fee, winning_amount, result) VALUES (?, ?, ?, ?)";
    $pdo->prepare($sql)->execute([$user_id, $amount, $win_amount, $status]);

    echo json_encode([
        'status' => $status,
        'user_score' => $user_score,
        'comp_score' => $comp_score,
        'msg' => $msg
    ]);
}
?>