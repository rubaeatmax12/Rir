<?php
require '../common/config.php';
require '../common/db.php';

if (!isset($_SESSION['user_id'])) { exit; }
$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

// ১. লাইক দেওয়া
if ($action == 'like') {
    $vid = $_POST['video_id'];
    $check = $pdo->prepare("SELECT id FROM video_likes WHERE user_id = ? AND video_id = ?");
    $check->execute([$user_id, $vid]);
    
    if ($check->rowCount() > 0) {
        $pdo->prepare("DELETE FROM video_likes WHERE user_id = ? AND video_id = ?")->execute([$user_id, $vid]);
        echo json_encode(['status' => 'unliked']);
    } else {
        $pdo->prepare("INSERT INTO video_likes (user_id, video_id) VALUES (?, ?)")->execute([$user_id, $vid]);
        echo json_encode(['status' => 'liked']);
    }
}

// ২. কমেন্ট করা
if ($action == 'comment') {
    $vid = $_POST['video_id'];
    $comment = $_POST['comment'];
    
    if (!empty($comment)) {
        $pdo->prepare("INSERT INTO video_comments (user_id, video_id, comment) VALUES (?, ?, ?)")->execute([$user_id, $vid, $comment]);
        echo json_encode(['status' => 'success']);
    }
}
?>