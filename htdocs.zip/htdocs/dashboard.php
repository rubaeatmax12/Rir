<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$balance = getUserBalance($pdo, $user_id);
$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();

// ইউজার স্ট্যাটাস এবং রোল চেক
$user_info = $pdo->prepare("SELECT status, role FROM users WHERE id = ?");
$user_info->execute([$user_id]);
$u_data = $user_info->fetch();

$is_active = ($u_data['status'] == 'active');
$is_admin = ($u_data['role'] == 'admin');

// আনরিড মেসেজ
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$user_id]);
$unread_msg = $stmt->fetchColumn();

// ডাটাবেস থেকে বাটন আনা (Dynamic Buttons)
$buttons = $pdo->query("SELECT * FROM app_buttons WHERE status = 'active'")->fetchAll();

require 'common/header.php';
?>

<style>
    /* গোল বাটন স্টাইল */
    .icon-box {
        width: 60px; height: 60px; background: white; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1); margin: 0 auto 8px auto;
        transition: transform 0.2s; border: 2px solid #f8f9fa;
    }
    .icon-box:active { transform: scale(0.9); background: #eef2f5; }
    .icon-box img { width: 30px; height: 30px; object-fit: contain; }
    
    .menu-item-text { font-size: 11px; font-weight: 600; color: #444; display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    
    /* সোশ্যাল বাটন (৩টা এক লাইনে) */
    .social-btn { border-radius: 10px; padding: 10px 5px; color: white; text-decoration: none; display: flex; flex-direction: column; align-items: center; justify-content: center; font-size: 11px; box-shadow: 0 3px 6px rgba(0,0,0,0.15); height: 60px; }
    .social-btn i { font-size: 20px; margin-bottom: 5px; }
</style>

<div>

    
    <!-- Mobile Friendly Animated Banner -->

<div class="banner-card">

  <div class="banner-text">

    <h2>WELCOME TO AL-HUDA TASK</h2>

    <p>Your Trusted Partner for Online Earnings</p>

  </div>

</div>

<style>

.banner-card{

width:100%;

max-width:600px;

height:200px;

margin:auto;

border-radius:15px;

display:flex;

align-items:center;

justify-content:center;

text-align:center;

color:white;

overflow:hidden;

/* moving gradient */

background: linear-gradient(270deg,#ff0000,#ff7b00,#ffd000,#00ff95,#0099ff,#7a00ff);

background-size:1200% 1200%;

animation:colorMove 12s ease infinite;

box-shadow:0 6px 15px rgba(0,0,0,0.25);

}

@keyframes colorMove{

0%{background-position:0% 50%;}

50%{background-position:100% 50%;}

100%{background-position:0% 50%;}

}

.banner-text h2{

font-size:24px;

font-weight:bold;

letter-spacing:2px;

margin:0;

}

.banner-text p{

font-size:14px;

margin-top:6px;

}

</style>

<style>
/* কন্টেইনার */

.app-btn-container{

    display:flex;

    justify-content:space-between;

    gap:10px;

    margin-top:15px;

    margin-bottom:15px;

}

/* বাটন ডিজাইন */

.app-btn{

    flex:1;

    display:flex;

    flex-direction:column;

    align-items:center;

    justify-content:center;

    padding:10px 4px;

    border-radius:14px;

    text-decoration:none;

    color:#ffffff !important;

    box-shadow:0 3px 8px rgba(0,0,0,0.15);

    transition:0.2s;

}

.app-btn:hover{

    transform:translateY(-3px);

}

/* আইকন সাইজ ছোট */

.app-icon{

    width:26px;

    height:26px;

    margin-bottom:4px;

}

/* লেখা */

.app-btn span{

    font-size:12px;

    font-weight:600;

    font-family:Arial,sans-serif;

}

/* কালার */

.btn-telegram-app{background:#2AABEE;}

.btn-youtube-app{background:#FF0000;}

.btn-facebook-app{background:#1877F2;}

</style>

<!-- Social Media Buttons -->

<div class="app-btn-container">

<!-- Telegram -->

<a href="<?php echo $settings['telegram']; ?>" class="app-btn btn-telegram-app">

<svg class="app-icon" viewBox="0 0 496 512">

<path fill="#fff" d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm115 169c-4 39-20 134-28 178-3 19-10 25-17 25-14 1-25-9-39-18-22-14-34-23-55-37-25-16-9-25 5-39 4-4 67-61 68-67 0-1 0-3-1-4s-4-1-5 0c-2 1-38 24-106 70-10 7-19 10-27 10-9 0-26-5-39-9-16-5-28-8-27-17 1-5 7-9 18-14 72-31 121-52 145-62 69-29 83-34 93-34 2 0 7 0 10 3 2 2 3 5 3 7v1z"/>

</svg>

<span>Telegram</span>

</a>

<!-- YouTube -->

<a href="<?php echo $settings['youtube_link']; ?>" class="app-btn btn-youtube-app">

<svg class="app-icon" viewBox="0 0 576 512">

<path fill="#fff" d="M549 124c-6-24-25-42-48-49C459 64 288 64 288 64S117 64 75 75c-23 7-42 25-49 49C15 167 15 256 15 256s0 89 11 132c7 24 26 42 49 48C117 448 288 448 288 448s171 0 213-12c23-6 42-24 48-48 11-43 11-132 11-132s0-89-11-132zM232 338V175l143 81-143 82z"/>

</svg>

<span>YouTube</span>

</a>

<!-- Facebook -->

<a href="<?php echo $settings['fb_group']; ?>" class="app-btn btn-facebook-app">

<svg class="app-icon" viewBox="0 0 320 512">

<path fill="#fff" d="M279 288l14-93h-89v-60c0-25 12-50 52-50h41V6s-37-6-72-6c-73 0-121 44-121 125v70H23v93h81v224h100V288z"/>

</svg>

<span>Facebook</span>

</a>

</div>

<!-- নোটিফিকেশন -->
<div class="d-flex justify-content-between align-items-center mb-2 px-2">
    <h6 class="fw-bold m-0 text-primary">All Services</h6>
    <a href="notifications.php" class="position-relative text-dark">
        <i class="fas fa-bell fa-lg"></i>
        <?php if($unread_msg > 0): ?>
            <span class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle"></span>
        <?php endif; ?>
    </a>
</div>
<div class="col-3">
    <a href="user/tutorials.php" class="text-decoration-none">
        <div class="icon-box">
            <img src="https://cdn-icons-png.flaticon.com/512/3074/3074765.png" alt="Tutorial">
        </div>
        <span class="menu-item-text">Tutorial</span>
    </a>
</div>

<!-- ৩. ডাইনামিক বাটন গ্রিড -->
<div class="row text-center gy-3">
    <?php
    function getLink($url) {
        global $is_active, $is_admin;
        
        // অ্যাডমিন হলে কোনো বাধা নেই, সব বাটন কাজ করবে
        if ($is_admin) {
            return $url;
        }

        // সাধারণ ইউজার যদি Inactive হয়
        if (!$is_active) {
            // শুধু এই পেজগুলোতে ঢুকতে পারবে
            $allowed = ['user/recharge.php', 'user/support.php', 'profile.php', 'user/contact.php'];
            
            if (!in_array($url, $allowed)) {
                return "javascript:alert('⚠️ Please Activate your Account first!'); window.location='user/activate.php';";
            }
        }
        return $url; 
    }

    // ডাটাবেস থেকে বাটনগুলো লুপ হচ্ছে
    foreach ($buttons as $btn) {
        echo '
        <div class="col-3">
            <a href="'.getLink($btn['link']).'" class="text-decoration-none">
                <div class="icon-box"><img src="'.$btn['icon'].'"></div>
                <span class="menu-item-text">'.$btn['name'].'</span>
            </a>
        </div>';
    }
    ?>
</div>

<!-- ডেইলি বোনাস -->
<div class="col-12 mt-4 mb-5">
    <a href="<?php echo getLink('daily_bonus.php'); ?>" class="text-decoration-none">
        <div class="card border-0 shadow-sm" style="background: linear-gradient(45deg, #FFD700, #FFC107);">
            <div class="card-body d-flex justify-content-between align-items-center text-dark py-2">
                <div><h6 class="fw-bold mb-0">Daily Bonus</h6><small>Click to collect</small></div><i class="fas fa-gift fa-lg"></i>
    <?php
// এই কোডটুকু ফাইলের উপরে PHP ব্লকের মধ্যে থাকতে হবে (settings লোড করার পরে)
// $settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch(); 
// (তোমার dashboard.php তে এটা অলরেডি আছে)
?>

<!-- ডাউনলোড বাটন -->
<div class="col-3" onclick="window.open('<?php echo $settings['app_link']; ?>', '_blank')">
    <div class="icon-box"><img src="https://cdn-icons-png.flaticon.com/512/732/732205.png"></div>
    <span class="menu-item-text">Download App</span>
</div>
            </div>
        </div>
    </a>
</div>

<br><br>

<div class="bottom-nav">
    <a href="dashboard.php" class="nav-icon active"><i class="fas fa-home"></i> Home</a>
    <a href="<?php echo getLink('tasks.php'); ?>" class="nav-icon"><i class="fas fa-tasks"></i> Work</a>
    <a href="user/recharge.php" class="nav-icon"><i class="fas fa-wallet"></i> Wallet</a>
    <a href="profile.php" class="nav-icon"><i class="fas fa-user"></i> Profile</a>
    <?php
// এই কোডটুকু ফাইলের উপরে PHP ব্লকের মধ্যে থাকতে হবে (settings লোড করার পরে)
// $settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch(); 
// (তোমার dashboard.php তে এটা অলরেডি আছে)
?>

</div>
</div>
<div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>