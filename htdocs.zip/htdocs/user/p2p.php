<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ১. ডলার সেল পোস্ট করা
if (isset($_POST['sell_usdt'])) {
    $amount = $_POST['usdt_amount'];
    $price = $_POST['price_rate'];
    $total = $amount * $price;

    $u = $pdo->query("SELECT usdt_balance FROM users WHERE id = $user_id")->fetch();

    if ($u['usdt_balance'] >= $amount) {
        $pdo->beginTransaction();
        // সেলারের ডলার কেটে হোল্ডে রাখা (এখানে জাস্ট কেটে নিচ্ছি)
        $pdo->prepare("UPDATE users SET usdt_balance = usdt_balance - ? WHERE id = ?")->execute([$amount, $user_id]);
        // অর্ডার পোস্ট
        $pdo->prepare("INSERT INTO p2p_orders (seller_id, amount_usdt, price_per_usdt, total_bdt) VALUES (?, ?, ?, ?)")
            ->execute([$user_id, $amount, $price, $total]);
        $pdo->commit();
        $msg = "Sell Order Placed!";
    } else {
        $err = "Insufficient USDT!";
    }
}

// ২. ডলার কেনা (অন্য ইউজারের কাছ থেকে)
if (isset($_GET['buy_id'])) {
    $oid = $_GET['buy_id'];
    $order = $pdo->query("SELECT * FROM p2p_orders WHERE id = $oid AND status = 'active'")->fetch();
    
    $buyer = $pdo->query("SELECT balance FROM users WHERE id = $user_id")->fetch();

    if ($order && $buyer['balance'] >= $order['total_bdt']) {
        $pdo->beginTransaction();
        try {
            // বায়ারের টাকা কাটা
            $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$order['total_bdt'], $user_id]);
            // বায়ারকে ডলার দেওয়া
            $pdo->prepare("UPDATE users SET usdt_balance = usdt_balance + ? WHERE id = ?")->execute([$order['amount_usdt'], $user_id]);
            
            // সেলারকে টাকা দেওয়া
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$order['total_bdt'], $order['seller_id']]);
            
            // অর্ডার কমপ্লিট
            $pdo->prepare("UPDATE p2p_orders SET status = 'sold' WHERE id = ?")->execute([$oid]);
            
            $pdo->commit();
            $msg = "Purchase Successful! You got {$order['amount_usdt']} USDT.";
        } catch(Exception $e) {
            $pdo->rollBack();
            $err = "Trade Failed!";
        }
    } else {
        $err = "Insufficient BDT Balance or Order sold!";
    }
}

// সব অর্ডার আনা
$orders = $pdo->query("SELECT p.*, u.username FROM p2p_orders p JOIN users u ON p.seller_id = u.id WHERE p.status = 'active' AND p.seller_id != $user_id")->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-handshake"></i> P2P Trading</h3>

<?php if(isset($msg)) showAlert($msg, 'success'); ?>
<?php if(isset($err)) showAlert($err, 'danger'); ?>

<!-- সেল বাটন -->
<button class="btn btn-dark w-100 mb-4" type="button" data-bs-toggle="collapse" data-bs-target="#sellForm">
    <i class="fas fa-plus"></i> Post Sell Ad
</button>

<div class="collapse mb-4" id="sellForm">
    <div class="card p-3 shadow-sm border-danger">
        <form method="POST">
            <div class="row">
                <div class="col-6">
                    <input type="number" step="0.01" name="usdt_amount" class="form-control" placeholder="USDT Amount" required>
                </div>
                <div class="col-6">
                    <input type="number" step="0.01" name="price_rate" class="form-control" placeholder="Rate (Ex: 122)" required>
                </div>
            </div>
            <button type="submit" name="sell_usdt" class="btn btn-danger w-100 mt-2">Sell Now</button>
        </form>
    </div>
</div>

<!-- মার্কেট লিস্ট -->
<div class="list-group">
    <?php foreach($orders as $o): ?>
    <div class="list-group-item d-flex justify-content-between align-items-center">
        <div>
            <h6 class="mb-0 fw-bold text-primary"><?php echo $o['username']; ?></h6>
            <small>Selling: <strong>$<?php echo $o['amount_usdt']; ?></strong></small><br>
            <small>Rate: <?php echo $o['price_per_usdt']; ?> Tk</small>
        </div>
        <div class="text-end">
            <h5 class="fw-bold mb-1"><?php echo CURRENCY . $o['total_bdt']; ?></h5>
            <a href="?buy_id=<?php echo $o['id']; ?>" class="btn btn-success btn-sm" onclick="return confirm('Buy this?')">Buy</a>
        </div>
    </div>
    <?php endforeach; ?>
    <?php if(empty($orders)) echo "<p class='text-center text-muted'>No ads available.</p>"; ?>
</div>

<?php require '../common/footer.php'; ?>