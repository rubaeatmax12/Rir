<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// গত ২০টি লগইন রেকর্ড আনা
$sql = "SELECT * FROM login_logs WHERE user_id = ? ORDER BY id DESC LIMIT 20";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$logs = $stmt->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center text-dark mb-4"><i class="fas fa-history"></i> Login History</h3>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <ul class="list-group list-group-flush">
            <?php if(count($logs) > 0): ?>
                <?php foreach($logs as $log): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <!-- তারিখ ও সময় -->
                        <strong class="text-primary d-block">
                            <i class="far fa-clock"></i> <?php echo date('d M, h:i A', strtotime($log['login_time'])); ?>
                        </strong>
                        
                        <!-- ডিভাইস ইনফো (ছোট করে) -->
                        <small class="text-muted" style="font-size: 11px;">
                            <i class="fas fa-mobile-alt"></i> 
                            <?php 
                                // ডিভাইস নাম ছোট করা
                                if (strpos($log['device_info'], 'Android') !== false) echo "Android Device";
                                elseif (strpos($log['device_info'], 'Windows') !== false) echo "Windows PC";
                                elseif (strpos($log['device_info'], 'iPhone') !== false) echo "iPhone";
                                else echo "Unknown Device";
                            ?>
                        </small>
                    </div>
                    
                    <!-- আইপি এড্রেস -->
                    <span class="badge bg-light text-dark border">
                        IP: <?php echo $log['ip_address']; ?>
                    </span>
                </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="list-group-item text-center py-5 text-muted">
                    No login history found.
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<div class="text-center mt-3">
    <a href="../dashboard.php" class="btn btn-outline-dark rounded-pill">Back to Dashboard</a>
</div>

<?php require '../common/footer.php'; ?>