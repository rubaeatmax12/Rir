<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$job_id = $_GET['id'];
$worker_id = $_SESSION['user_id'];

// জব ইনফো
$job = $pdo->query("SELECT * FROM user_jobs WHERE id = $job_id")->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $proof = $_POST['proof'];
    
    // চেক করা আগে করেছে কিনা
    $check = $pdo->prepare("SELECT id FROM job_proofs WHERE job_id = ? AND worker_id = ?");
    $check->execute([$job_id, $worker_id]);
    
    if ($check->rowCount() > 0) {
        $error = "You already submitted this job!";
    } else {
        $pdo->prepare("INSERT INTO job_proofs (job_id, worker_id, proof_text) VALUES (?, ?, ?)")->execute([$job_id, $worker_id, $proof]);
        $success = "Proof Submitted! Waiting for approval.";
    }
}

require '../common/header.php';
?>

<div class="card shadow-sm">
    <div class="card-body">
        <h4><?php echo htmlspecialchars($job['title']); ?></h4>
        <div class="alert alert-info">
            <strong>Instructions:</strong><br>
            <?php echo nl2br(htmlspecialchars($job['description'])); ?><br>
            <a href="<?php echo $job['link']; ?>" target="_blank" class="btn btn-sm btn-dark mt-2">Open Link</a>
        </div>
        
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <form method="POST">
            <div class="mb-3">
                <label>Submit Proof (Username/Screenshot Link/Text)</label>
                <textarea name="proof" class="form-control" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-success w-100">Submit Task</button>
        </form>
    </div>
</div>
<?php require '../common/footer.php'; ?>