<?php
require '../common/config.php';
require '../common/functions.php';
checkLogin();
require '../common/header.php';
?>

<!-- Jitsi Meet Integration -->
<div class="card shadow-sm h-100">
    <div class="card-header bg-dark text-white">
        <h5 class="m-0"><i class="fas fa-microphone-alt"></i> Live Audio Room</h5>
    </div>
    <div class="card-body p-0" style="height: 500px;">
        <iframe src="https://meet.jit.si/AlphaEarnerLiveRoom_<?php echo date('Y'); ?>#config.startWithVideoMuted=true" 
                allow="camera; microphone; fullscreen; display-capture" 
                style="width: 100%; height: 100%; border: none;">
        </iframe>
    </div>
</div>
<div class="text-center mt-2">
    <a href="../dashboard.php" class="btn btn-danger">Leave Room</a>
</div>
<?php require '../common/footer.php'; ?>