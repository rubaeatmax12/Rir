<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$balance = getUserBalance($pdo, $user_id);
require '../common/header.php';
?>

<!-- ফন্ট এবং আইকন -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
    body { background-color: #0f0f0f; font-family: 'Roboto', sans-serif; padding-bottom: 0; }
    
    /* টপ বার */
    .game-header {
        background: #1b1b1b;
        padding: 10px 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #2c2c2c;
    }
    .logo { color: #e90909; font-weight: bold; font-style: italic; font-size: 22px; letter-spacing: 1px; }
    .wallet-box { background: #000; padding: 5px 15px; border-radius: 20px; border: 1px solid #333; color: #28a909; font-weight: bold; font-size: 14px; }

    /* গেম এরিয়া (ক্যানভাস) */
    .game-stage {
        height: 280px;
        background: #000;
        position: relative;
        margin: 10px;
        border-radius: 15px;
        border: 1px solid #2c2c2c;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    /* মাল্টিপ্লায়ার টেক্সট */
    .multiplier-big {
        font-size: 60px;
        font-weight: 900;
        color: white;
        z-index: 10;
        text-shadow: 0 0 10px rgba(255,255,255,0.2);
    }
    .text-crashed { color: #e90909 !important; text-shadow: none; font-size: 40px; }
    
    /* প্লেন */
    .plane-img {
        width: 100px;
        position: absolute;
        bottom: 10px;
        left: 10px;
        transition: transform 0.1s linear;
        z-index: 5;
    }
    
    /* বেটিং প্যানেল (কালো বক্স) */
    .bet-control-panel {
        background: #1b1b1b;
        border-radius: 20px 20px 0 0;
        padding: 20px;
        position: fixed;
        bottom: 0;
        width: 100%;
        border-top: 2px solid #2c2c2c;
        z-index: 100;
    }
    
    /* ইনপুট গ্রুপ */
    .bet-input-group {
        display: flex;
        background: #000;
        border-radius: 30px;
        padding: 5px;
        border: 1px solid #333;
        align-items: center;
        margin-bottom: 15px;
    }
    .bet-btn-round {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        border: 1px solid #555;
        background: #2c2c2c;
        color: white;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }
    .bet-input {
        flex: 1;
        background: transparent;
        border: none;
        color: white;
        text-align: center;
        font-weight: bold;
        font-size: 18px;
    }
    .bet-input:focus { outline: none; }

    /* কুইক বাটন (100, 200, 500) */
    .quick-chips { display: flex; gap: 5px; justify-content: center; margin-bottom: 15px; }
    .chip {
        background: #2c2c2c;
        color: #aaa;
        padding: 5px 12px;
        border-radius: 15px;
        font-size: 12px;
        border: 1px solid #333;
        cursor: pointer;
    }
    .chip:active { background: #444; }

    /* মেইন বাটন (BET / CASHOUT) */
    #mainActionBtn {
        width: 100%;
        padding: 15px;
        border-radius: 15px;
        font-size: 20px;
        font-weight: bold;
        text-transform: uppercase;
        border: none;
        box-shadow: 0 4px 15px rgba(0,255,0,0.3);
        transition: 0.2s;
    }
    .btn-bet { background: #28a909; color: white; } /* সবুজ */
    .btn-cashout { background: #ff9800; color: black; box-shadow: 0 4px 15px rgba(255, 152, 0, 0.3) !important; } /* হলুদ */
    .btn-wait { background: #d0021b; color: white; opacity: 0.8; } /* লাল */

    /* গ্রাফ লাইন */
    .graph-canvas { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }

    /* হিস্ট্রি বার */
    .history-bar {
        display: flex;
        gap: 5px;
        padding: 5px 10px;
        overflow-x: auto;
        white-space: nowrap;
        background: #141414;
    }
    .hist-pill {
        background: #000;
        border: 1px solid #333;
        color: #fff;
        padding: 2px 8px;
        border-radius: 10px;
        font-size: 11px;
    }
    .hist-win { color: #28a909; border-color: #28a909; }
    .hist-loss { color: #d0021b; border-color: #d0021b; }
</style>

<!-- হেডার -->
<div class="game-header">
    <div class="logo">Aviator</div>
    <div class="wallet-box">
        <?php echo CURRENCY; ?> <span id="liveBalance"><?php echo number_format($balance, 2); ?></span>
    </div>
    <a href="../dashboard.php" class="text-white"><i class="fas fa-times"></i></a>
</div>

<!-- হিস্ট্রি -->
<div class="history-bar" id="historyLog">
    <!-- এখানে জাভাস্ক্রিপ্ট দিয়ে হিস্ট্রি আসবে -->
    <span class="hist-pill hist-win">2.50x</span>
    <span class="hist-pill hist-loss">1.10x</span>
    <span class="hist-pill hist-win">5.34x</span>
</div>

<!-- গেম স্টেজ -->
<div class="game-stage" id="gameScreen">
    <!-- ব্যাকগ্রাউন্ড গ্রিড -->
    <div style="position: absolute; width: 100%; height: 100%; background-image: radial-gradient(#333 1px, transparent 1px); background-size: 20px 20px; opacity: 0.2;"></div>
    
    <!-- বড় মাল্টিপ্লায়ার -->
    <div class="multiplier-big" id="counter">1.00x</div>
    
    <!-- লাল প্লেন -->
    <img src="https://cdn-icons-png.flaticon.com/512/7893/7893979.png" class="plane-img" id="plane">
    
    <!-- লোডিং মেসেজ -->
    <div id="loadingMsg" style="display:none; position:absolute; color: white;">WAITING FOR NEXT ROUND...</div>
</div>

<!-- নিচের কন্ট্রোল প্যানেল -->
<div class="bet-control-panel">
    
    <!-- কুইক চিপস -->
    <div class="quick-chips">
        <div class="chip" onclick="setBet(100)">100</div>
        <div class="chip" onclick="setBet(200)">200</div>
        <div class="chip" onclick="setBet(500)">500</div>
        <div class="chip" onclick="setBet(1000)">1000</div>
    </div>

    <!-- ইনপুট -->
    <div class="bet-input-group">
        <div class="bet-btn-round" onclick="adjustBet(-10)">-</div>
        <input type="number" id="betAmount" class="bet-input" value="10">
        <div class="bet-btn-round" onclick="adjustBet(10)">+</div>
    </div>

    <!-- বিশাল বাটন -->
    <button id="mainActionBtn" class="btn-bet">
        BET <br> <span style="font-size: 12px; font-weight: normal;">NEXT ROUND</span>
    </button>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    let timer;
    let currentMult = 1.00;
    let crashPoint = 0;
    let gameId = 0;
    let isRunning = false;
    let myBet = 0;

    // ১. টাকা সেট করা
    window.setBet = function(amount) { $('#betAmount').val(amount); }
    window.adjustBet = function(val) {
        let current = parseInt($('#betAmount').val());
        if(current + val >= 10) $('#betAmount').val(current + val);
    }

    // ২. বাটনে ক্লিক
    $('#mainActionBtn').click(function(){
        if($(this).hasClass('btn-bet')) {
            // বেট করা
            placeBet();
        } else if($(this).hasClass('btn-cashout')) {
            // ক্যাশআউট করা
            cashOut();
        }
    });

    function placeBet() {
        let amount = $('#betAmount').val();
        if(amount < 10) { alert("Min 10 Tk"); return; }

        $('#mainActionBtn').removeClass('btn-bet').addClass('btn-wait').html('WAITING...');
        
        $.post('../api/aviator_api.php', { action: 'bet', amount: amount }, function(res){
            let data = JSON.parse(res);
            if(data.status == 'error') {
                alert(data.message);
                resetBtn();
            } else {
                crashPoint = parseFloat(data.crash_point);
                gameId = data.game_id;
                myBet = amount;
                $('#liveBalance').text(data.new_balance); // ব্যালেন্স আপডেট
                startGame();
            }
        });
    }

    function startGame() {
        isRunning = true;
        currentMult = 1.00;
        
        // বাটন পরিবর্তন (হলুদ Cash Out)
        $('#mainActionBtn').removeClass('btn-wait').addClass('btn-cashout').html('CASHOUT <br> <span id="winShow">0.00 Tk</span>');
        
        $('#counter').removeClass('text-crashed').text('1.00x').css('color', 'white');
        $('#plane').css({ bottom: '20px', left: '20px', transform: 'rotate(0deg)', opacity: 1 });

        // এনিমেশন লুপ
        timer = setInterval(function(){
            if(currentMult >= crashPoint) {
                crashGame();
            } else {
                currentMult += 0.01;
                $('#counter').text(currentMult.toFixed(2) + 'x');
                
                // লাইভ লাভ দেখানো
                let currentWin = (myBet * currentMult).toFixed(2);
                $('#winShow').text(currentWin + ' Tk');

                // প্লেন মুভমেন্ট (Curve Effect)
                let percent = (currentMult - 1) * 20; 
                if(percent > 220) percent = 220; 
                $('#plane').css({ bottom: (20 + percent) + 'px', left: (20 + percent) + 'px' });
            }
        }, 60); // স্পিড
    }

    function cashOut() {
        if(!isRunning) return;
        isRunning = false;
        clearInterval(timer);
        
        $.post('../api/aviator_api.php', { action: 'cashout', game_id: gameId, multiplier: currentMult }, function(res){
            let data = JSON.parse(res);
            if(data.status == 'success') {
                // জেতার এনিমেশন
                $('#counter').css('color', '#28a909'); // সবুজ
                $('#mainActionBtn').html('WON '+data.win_amount).prop('disabled', true);
                addToHistory(currentMult, 'win');
                setTimeout(resetBtn, 2000);
            }
        });
    }

    function crashGame() {
        clearInterval(timer);
        isRunning = false;
        
        $('#counter').addClass('text-crashed').text('FLEW AWAY!');
        $('#plane').css({ transform: 'translate(300px, -200px) rotate(-20deg)', opacity: 0, transition: '0.8s' });
        
        $('#mainActionBtn').removeClass('btn-cashout').addClass('btn-wait').html('CRASHED').prop('disabled', true);
        addToHistory(crashPoint, 'loss');
        
        setTimeout(resetBtn, 2500); // ২.৫ সেকেন্ড পর আবার বেট করা যাবে
    }

    function resetBtn() {
        $('#mainActionBtn').removeClass('btn-wait btn-cashout').addClass('btn-bet').prop('disabled', false).html('BET <br> <span style="font-size: 12px; font-weight: normal;">NEXT ROUND</span>');
        $('#counter').removeClass('text-crashed').text('1.00x').css('color', 'white');
        $('#plane').css({ bottom: '20px', left: '20px', opacity: 1, transform: 'none', transition: 'none' });
    }

    function addToHistory(point, type) {
        let colorClass = (type == 'win') ? 'hist-win' : 'hist-loss';
        $('#historyLog').prepend('<span class="hist-pill '+colorClass+'">'+point.toFixed(2)+'x</span>');
    }
});
</script>

<!-- ফুটার হাইড (যাতে অ্যাপের মতো লাগে) -->
<div style="display:none">
<?php require '../common/footer.php'; ?>
</div>