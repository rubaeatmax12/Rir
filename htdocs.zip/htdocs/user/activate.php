<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$user = $pdo->query("SELECT * FROM users WHERE id = $user_id")->fetch();

// সেটিংস থেকে ফি এবং বোনাস জানা
$settings = $pdo->query("SELECT activation_fee, ref_bonus FROM settings LIMIT 1")->fetch();
$fee = $settings['activation_fee'];
$bonus = $settings['ref_bonus'];

// যদি ইতিমধ্যে অ্যাক্টিভ থাকে
if ($user['status'] == 'active') {
    header("Location: ../dashboard.php");
    exit;
}

// অ্যাক্টিভ করার লজিক
if (isset($_POST['activate_now'])) {
    if ($user['balance'] >= $fee) {
        
        // ১. ইউজারের ব্যালেন্স থেকে ফি কাটা
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$fee, $user_id]);
        
        // ২. ইউজারের স্ট্যাটাস Active করা
        $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?")->execute([$user_id]);
        
        // ৩. 🔥 রেফার বোনাস দেওয়া (এটাই নতুন সিস্টেম) 🔥
        if ($user['referrer_id']) {
            if ($bonus > 0) {
                // রেফারকারীকে টাকা দেওয়া
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$bonus, $user['referrer_id']]);
                
                // রেফারকারীকে খুশির মেসেজ পাঠানো
                $msg = "Congratulations! Your referred user ({$user['username']}) activated their account. You got " . CURRENCY . $bonus . " bonus!";
                $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Referral Bonus 🎉', ?)")->execute([$user['referrer_id'], $msg]);
            }
        }

        echo "<script>alert('Account Activated Successfully! 🎉'); window.location='../dashboard.php';</script>";
    } else {
        $error = "Insufficient Balance! Please deposit money.";
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6 text-center">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-danger text-white">
                <h4><i class="fas fa-lock"></i> Account Locked</h4>
            </div>
            <div class="card-body py-5">
                <i class="fas fa-user-lock fa-5x text-secondary mb-3"></i>
                <h3 class="fw-bold">Activate Your Account</h3>
                <p class="text-muted">You need to pay a one-time fee to unlock tasks, games & withdrawals.</p>
                
                <div class="alert alert-warning border-warning">
                    <h4 class="mb-0">Activation Fee: <strong><?php echo CURRENCY . $fee; ?></strong></h4>
                </div>

                <p>Your Balance: <strong class="<?php echo $user['balance'] >= $fee ? 'text-success' : 'text-danger'; ?>"><?php echo CURRENCY . $user['balance']; ?></strong></p>

                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <?php if($user['balance'] >= $fee): ?>
                    <form method="POST">
                        <button type="submit" name="activate_now" class="btn btn-success btn-lg w-100 rounded-pill">
                            <i class="fas fa-check-circle"></i> Activate Now
                        </button>
                    </form>
                <?php else: ?>
                    <a href="recharge.php" class="btn btn-primary btn-lg w-100 rounded-pill">
                        <i class="fas fa-wallet"></i> Deposit Money
                    </a>
                    <p class="small text-muted mt-2">Deposit at least <?php echo CURRENCY . ($fee - $user['balance']); ?> more.</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="mt-3">
            <a href="../logout.php" class="text-danger">Logout</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>