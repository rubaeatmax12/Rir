<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// কার্ড অ্যাড করার লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $method = $_POST['method'];
    $number = trim($_POST['number']);
    $pin = $_POST['pin']; // পিন চেক করা হবে নিরাপত্তার জন্য

    // ১. পিন চেক
    $user = $pdo->query("SELECT security_pin FROM users WHERE id = $user_id")->fetch();
    if ($user['security_pin'] !== $pin) {
        $error = "Wrong Security PIN!";
    } else {
        // ২. চেক করা এই নম্বর অন্য কেউ ব্যবহার করেছে কিনা
        $chk_num = $pdo->prepare("SELECT id FROM user_cards WHERE account_number = ?");
        $chk_num->execute([$number]);

        if ($chk_num->rowCount() > 0) {
            $error = "This wallet number is already linked to another account!";
        } else {
            // ৩. সব ঠিক থাকলে কার্ড সেভ
            // চেক করা ইউজার ইতিমধ্যে এই মেথডে কার্ড এড করেছে কিনা (অপশনাল)
            $sql = "INSERT INTO user_cards (user_id, method_name, account_number) VALUES (?, ?, ?)";
            try {
                $pdo->prepare($sql)->execute([$user_id, $method, $number]);
                $success = "Payment Card Added Successfully!";
            } catch (Exception $e) {
                $error = "Error adding card!";
            }
        }
    }
}

// সেভ করা কার্ড দেখা
$cards = $pdo->prepare("SELECT * FROM user_cards WHERE user_id = ?");
$cards->execute([$user_id]);
$my_cards = $cards->fetchAll();

require '../common/header.php';
?>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0"><i class="fas fa-credit-card"></i> Bind Wallet</h5>
    </div>
    <div class="card-body">
        <div class="alert alert-warning small">
            <i class="fas fa-exclamation-triangle"></i> Warning: Once you add a number, you <b>CANNOT</b> delete or change it. This number cannot be used in other accounts.
        </div>

        <?php if(isset($error)) showAlert($error, 'danger'); ?>
        <?php if(isset($success)) showAlert($success, 'success'); ?>

        <form method="POST">
            <div class="mb-3">
                <label>Select Method</label>
                <select name="method" class="form-control">
                    <option>bKash</option>
                    <option>Nagad</option>
                    <option>Rocket</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Wallet Number</label>
                <input type="number" name="number" class="form-control" placeholder="017xxxxxxxx" required>
            </div>
            <div class="mb-3">
                <label>Security PIN</label>
                <input type="password" name="pin" class="form-control" placeholder="****" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Bind Now</button>
        </form>
    </div>
</div>

<h5 class="text-secondary">My Linked Cards</h5>
<ul class="list-group shadow-sm">
    <?php if(count($my_cards) > 0): ?>
        <?php foreach($my_cards as $c): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <span>
                <strong><?php echo $c['method_name']; ?>:</strong> 
                <?php echo $c['account_number']; ?>
            </span>
            <span class="badge bg-success"><i class="fas fa-lock"></i> Linked</span>
        </li>
        <?php endforeach; ?>
    <?php else: ?>
        <li class="list-group-item text-center text-muted">No card added yet.</li>
    <?php endif; ?>
</ul>

<?php require '../common/footer.php'; ?>