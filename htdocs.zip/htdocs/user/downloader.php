<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
require '../common/header.php';
?>

<div class="card shadow-sm text-center border-0">
    <div class="card-header bg-success text-white">
        <h4><i class="fas fa-download"></i> Video Downloader</h4>
    </div>
    <div class="card-body">
        <img src="https://cdn-icons-png.flaticon.com/512/2926/2926214.png" width="80" class="mb-3">
        <p>Download Videos from FB, TikTok, Insta without watermark!</p>
        
        <form id="dlForm">
            <div class="mb-3">
                <input type="url" id="videoUrl" class="form-control form-control-lg" placeholder="Paste Video Link Here..." required>
            </div>
            <button type="submit" class="btn btn-success w-100 btn-lg">Download <i class="fas fa-arrow-down"></i></button>
        </form>
        
        <div id="result" class="mt-4" style="display:none;">
            <div class="alert alert-info">Processing... Please wait.</div>
        </div>
    </div>
</div>

<script>
document.getElementById('dlForm').addEventListener('submit', function(e){
    e.preventDefault();
    var url = document.getElementById('videoUrl').value;
    var resDiv = document.getElementById('result');
    
    // ফ্রি API ব্যবহার করে ডাউনলোড (উদাহরণ)
    // নোট: প্রোডাকশনে পেইড API ব্যবহার করা ভালো। এখানে ইউজারকে অন্য ট্যাবে পাঠানো হচ্ছে।
    
    resDiv.style.display = 'block';
    resDiv.innerHTML = '<div class="alert alert-success">Redirecting to download server...</div>';
    
    setTimeout(function(){
        // ফ্রি সেভফ্রম বা অন্য সার্ভিস ব্যবহার করা হচ্ছে
        window.open('https://savefrom.net/'+url, '_blank');
        resDiv.innerHTML = '<div class="alert alert-primary">Download started in new tab!</div>';
    }, 1500);
});
</script>

<?php require '../common/footer.php'; ?>