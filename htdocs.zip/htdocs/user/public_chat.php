<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
require '../common/header.php';
?>

<style>
    body { overflow: hidden; }
    .chat-container { 
        height: calc(100vh - 180px); 
        overflow-y: scroll; 
        padding: 15px; 
        background: #e5ddd5; 
        margin-bottom: 60px;
        border-radius: 10px;
    }
    .chat-message { display: flex; margin-bottom: 15px; align-items: end; }
    .chat-message.me { justify-content: flex-end; }
    .chat-message.other { justify-content: flex-start; }
    .avatar { width: 35px; height: 35px; border-radius: 50%; margin-right: 10px; border: 2px solid white; }
    .msg-box { padding: 8px 12px; border-radius: 15px; max-width: 75vw; font-size: 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .me .msg-box { border-bottom-right-radius: 2px; background: #dcf8c6; }
    .other .msg-box { border-bottom-left-radius: 2px; background: white; }
    .chat-input-area { position: fixed; bottom: 0; left: 0; width: 100%; background: white; padding: 10px; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); z-index: 1000; }
</style>

<h4 class="text-center text-primary fw-bold mt-2"><i class="fas fa-users"></i> Public Chat Room</h4>

<div class="chat-container" id="chatBox">
    <div class="text-center text-muted mt-5"><i class="fas fa-spinner fa-spin"></i> Loading Chats...</div>
</div>

<div class="chat-input-area">
    <form id="chatForm" class="d-flex gap-2 align-items-center">
        <input type="text" id="msgInput" class="form-control rounded-pill" placeholder="Type a message..." autocomplete="off">
        <button type="submit" class="btn btn-primary rounded-circle" style="width: 45px; height: 45px;">
            <i class="fas fa-paper-plane"></i>
        </button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    var chatBox = $('#chatBox');

    function loadChat() {
        $.ajax({
            url: '../api/chat_api.php',
            type: 'POST',
            data: { action: 'fetch' },
            success: function(data) {
                chatBox.html(data);
            }
        });
    }

    loadChat();
    setInterval(loadChat, 2000); // ২ সেকেন্ড পর পর রিফ্রেশ

    $('#chatForm').submit(function(e){
        e.preventDefault();
        var msg = $('#msgInput').val();
        if(msg.trim() != '') {
            $.post('../api/chat_api.php', { action: 'send', message: msg }, function(){
                $('#msgInput').val('');
                loadChat();
            });
        }
    });
});
</script>

<div style="height: 50px;"></div> 
<?php require '../common/footer.php'; ?>