<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$rate = 120; // ১ ডলার = ১২০ টাকা (ফিক্সড রেট)

// টাকা দিয়ে ডলার কেনা (Convert)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_usdt'])) {
    $bdt_amount = $_POST['amount'];
    $usdt_amount = $bdt_amount / $rate;

    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetchColumn();

    if ($balance >= $bdt_amount) {
        $pdo->beginTransaction();
        try {
            // টাকা কাটা
            $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$bdt_amount, $user_id]);
            // ডলার যোগ করা
            $pdo->prepare("UPDATE users SET usdt_balance = usdt_balance + ? WHERE id = ?")->execute([$usdt_amount, $user_id]);
            
            $pdo->commit();
            $success = "Exchange Successful! Received $" . number_format($usdt_amount, 2);
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "System Error!";
        }
    } else {
        $error = "Insufficient BDT Balance!";
    }
}

// ইউজার ডাটা
$u = $pdo->query("SELECT balance, usdt_balance FROM users WHERE id = $user_id")->fetch();

require '../common/header.php';
?>

<div class="row">
    <!-- ব্যালেন্স কার্ড -->
    <div class="col-6">
        <div class="card bg-primary text-white text-center p-3 mb-3">
            <h5>BDT Balance</h5>
            <h3><?php echo CURRENCY . number_format($u['balance'], 2); ?></h3>
        </div>
    </div>
    <div class="col-6">
        <div class="card bg-success text-white text-center p-3 mb-3">
            <h5>USDT Wallet</h5>
            <h3>$ <?php echo number_format($u['usdt_balance'], 4); ?></h3>
        </div>
    </div>
</div>

<!-- কনভার্ট ফরম -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-dark text-white">
        <i class="fas fa-exchange-alt"></i> Exchange BDT to USDT
    </div>
    <div class="card-body">
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <form method="POST">
            <div class="mb-3">
                <label>Amount in BDT</label>
                <input type="number" name="amount" class="form-control" placeholder="Ex: 1200" required>
                <small class="text-muted">Rate: 1 USDT = <?php echo $rate; ?> BDT</small>
            </div>
            <button type="submit" name="buy_usdt" class="btn btn-warning w-100 fw-bold">Convert Now</button>
        </form>
    </div>
</div>

<div class="text-center">
    <a href="p2p.php" class="btn btn-outline-primary w-100">Go to P2P Market <i class="fas fa-arrow-right"></i></a>
</div>

<?php require '../common/footer.php'; ?>