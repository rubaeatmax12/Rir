<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$balance = getUserBalance($pdo, $user_id);

require '../common/header.php';
?>

<div class="text-center mb-4">
    <img src="https://cdn-icons-png.flaticon.com/512/802/802183.png" width="80">
    <h2 class="fw-bold mt-2">Ludo Dice Tournament</h2>
    <p class="text-muted">Roll the dice & Win Real Money!</p>
    <div class="alert alert-info">
        Your Balance: <strong><?php echo CURRENCY . $balance; ?></strong>
    </div>
</div>

<div class="row g-3">
    <!-- ২০ টাকার ম্যাচ -->
    <div class="col-6">
        <div class="card shadow-sm border-primary text-center">
            <div class="card-header bg-primary text-white">Starter</div>
            <div class="card-body">
                <h3><?php echo CURRENCY; ?> 20</h3>
                <p class="small">Win: <?php echo CURRENCY; ?> 35</p>
                <a href="play_ludo.php?amount=20" class="btn btn-outline-primary w-100" onclick="return confirm('Pay 20 Tk to play?')">Play Now</a>
            </div>
        </div>
    </div>

    <!-- ৫০ টাকার ম্যাচ -->
    <div class="col-6">
        <div class="card shadow-sm border-danger text-center">
            <div class="card-header bg-danger text-white">Pro</div>
            <div class="card-body">
                <h3><?php echo CURRENCY; ?> 50</h3>
                <p class="small">Win: <?php echo CURRENCY; ?> 90</p>
                <a href="play_ludo.php?amount=50" class="btn btn-outline-danger w-100" onclick="return confirm('Pay 50 Tk to play?')">Play Now</a>
            </div>
        </div>
    </div>

    <!-- ১০০ টাকার ম্যাচ -->
    <div class="col-6">
        <div class="card shadow-sm border-warning text-center">
            <div class="card-header bg-warning text-dark">Master</div>
            <div class="card-body">
                <h3><?php echo CURRENCY; ?> 100</h3>
                <p class="small">Win: <?php echo CURRENCY; ?> 180</p>
                <a href="play_ludo.php?amount=100" class="btn btn-outline-warning w-100" onclick="return confirm('Pay 100 Tk to play?')">Play Now</a>
            </div>
        </div>
    </div>

    <!-- ৫০০ টাকার ম্যাচ -->
    <div class="col-6">
        <div class="card shadow-sm border-success text-center">
            <div class="card-header bg-success text-white">Legend</div>
            <div class="card-body">
                <h3><?php echo CURRENCY; ?> 500</h3>
                <p class="small">Win: <?php echo CURRENCY; ?> 900</p>
                <a href="play_ludo.php?amount=500" class="btn btn-outline-success w-100" onclick="return confirm('Pay 500 Tk to play?')">Play Now</a>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>