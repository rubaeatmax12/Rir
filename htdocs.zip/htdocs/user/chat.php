<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$sender_id = $_SESSION['user_id'];
$receiver_id = $_GET['uid'] ?? 0;

// ইউজার লিস্ট (যাদের সাথে চ্যাট করবে)
if ($receiver_id == 0) {
    $users = $pdo->query("SELECT id, username, profile_pic FROM users WHERE id != $sender_id ORDER BY id DESC LIMIT 50")->fetchAll();
    require '../common/header.php';
    echo '<h4 class="mb-3 text-center">Select a User to Chat</h4><div class="list-group">';
    foreach ($users as $u) {
        $pic = !empty($u['profile_pic']) ? "../assets/images/users/".$u['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png";
        echo '<a href="?uid='.$u['id'].'" class="list-group-item d-flex align-items-center">
                <img src="'.$pic.'" width="40" height="40" class="rounded-circle me-3">
                <h6 class="mb-0">'.$u['username'].'</h6>
              </a>';
    }
    echo '</div>';
    require '../common/footer.php';
    exit;
}

// মেসেজ পাঠানো
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['message'])) {
    $msg = $_POST['message'];
    $sql = "INSERT INTO private_chats (sender_id, receiver_id, message) VALUES (?, ?, ?)";
    $pdo->prepare($sql)->execute([$sender_id, $receiver_id, $msg]);
}

// মেসেজ লোড করা
$sql = "SELECT * FROM private_chats WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY id ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$sender_id, $receiver_id, $receiver_id, $sender_id]);
$chats = $stmt->fetchAll();

// রিসিভার ইনফো
$r_user = $pdo->query("SELECT username FROM users WHERE id = $receiver_id")->fetch();

require '../common/header.php';
?>

<div class="card shadow-sm h-100">
    <div class="card-header bg-primary text-white d-flex align-items-center">
        <a href="chat.php" class="text-white me-3"><i class="fas fa-arrow-left"></i></a>
        <h6 class="mb-0">Chat with <?php echo $r_user['username']; ?></h6>
    </div>
    <div class="card-body p-2" id="chatBox" style="height: 400px; overflow-y: auto; background: #e5ddd5;">
        <?php foreach($chats as $c): ?>
            <div class="d-flex <?php echo $c['sender_id'] == $sender_id ? 'justify-content-end' : ''; ?> mb-2">
                <div class="p-2 rounded <?php echo $c['sender_id'] == $sender_id ? 'bg-success text-white' : 'bg-white text-dark'; ?>" style="max-width: 75%;">
                    <?php echo htmlspecialchars($c['message']); ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="card-footer">
        <form method="POST" class="d-flex gap-2">
            <input type="text" name="message" class="form-control" placeholder="Type..." required autocomplete="off">
            <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
        </form>
    </div>
</div>

<script>
    var objDiv = document.getElementById("chatBox");
    objDiv.scrollTop = objDiv.scrollHeight;
</script>

<?php require '../common/footer.php'; ?>