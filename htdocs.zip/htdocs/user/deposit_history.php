<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM deposits WHERE user_id = ? ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$deposits = $stmt->fetchAll();

require '../common/header.php';
?>

<div class="card">
    <div class="card-header"><i class="fas fa-history"></i> Deposit History</div>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Method</th>
                    <th>Amount</th>
                    <th>Trx ID</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($deposits as $d): ?>
                <tr>
                    <td><?php echo date('d M, h:i A', strtotime($d['created_at'])); ?></td>
                    <td><?php echo ucfirst($d['method']); ?></td>
                    <td><?php echo CURRENCY . $d['amount']; ?></td>
                    <td><?php echo $d['trx_id']; ?></td>
                    <td>
                        <?php 
                            if($d['status'] == 'approved') echo '<span class="badge bg-success">Approved</span>';
                            elseif($d['status'] == 'rejected') echo '<span class="badge bg-danger">Rejected</span>';
                            else echo '<span class="badge bg-warning text-dark">Pending</span>';
                        ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../common/footer.php'; ?>