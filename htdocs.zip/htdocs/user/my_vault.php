<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ১. ফাইল বা নোট আপলোড লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $note = $_POST['note'];
    $type = 'note';
    $file_name = NULL;

    // যদি ফাইল থাকে
    if (!empty($_FILES['vault_file']['name'])) {
        $file = $_FILES['vault_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $valid_ext = ['jpg', 'jpeg', 'png', 'mp4', 'pdf', 'txt'];

        if (in_array($ext, $valid_ext)) {
            $file_name = time() . "_" . rand(1000,9999) . "." . $ext;
            $target = "../assets/vault/" . $file_name;
            
            // ফোল্ডার না থাকলে তৈরি করা
            if (!is_dir('../assets/vault')) mkdir('../assets/vault', 0777, true);

            if (move_uploaded_file($file['tmp_name'], $target)) {
                if(in_array($ext, ['jpg', 'jpeg', 'png'])) $type = 'image';
                elseif($ext == 'mp4') $type = 'video';
                else $type = 'file';
            }
        } else {
            $error = "Invalid file type!";
        }
    }

    if (!isset($error)) {
        $stmt = $pdo->prepare("INSERT INTO personal_vault (user_id, file_type, file_path, note_text) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $type, $file_name, $note]);
        $success = "Saved to Vault!";
    }
}

// ২. ডিলিট লজিক (গোপন ফাইল ডিলিট)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // চেক করা এই ফাইলটা কি সত্যিই এই ইউজারের? (সিকিউরিটি)
    $stmt = $pdo->prepare("SELECT * FROM personal_vault WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $user_id]);
    $item = $stmt->fetch();

    if ($item) {
        if ($item['file_path']) {
            unlink("../assets/vault/" . $item['file_path']); // ফাইল ডিলিট
        }
        $pdo->prepare("DELETE FROM personal_vault WHERE id = ?")->execute([$id]);
        header("Location: my_vault.php");
    }
}

// ৩. শুধু নিজের ফাইলগুলো আনা (অন্য কারোটা আসবে না)
$stmt = $pdo->prepare("SELECT * FROM personal_vault WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$items = $stmt->fetchAll();

require '../common/header.php';
?>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-dark text-white text-center">
        <h4><i class="fas fa-lock"></i> My Personal Vault</h4>
        <small>Private Storage (Safe & Secure)</small>
    </div>
    <div class="card-body">
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Write a Note</label>
                <textarea name="note" class="form-control" rows="2" placeholder="My secret note..." required></textarea>
            </div>
            <div class="mb-3">
                <label>Attach File (Photo/Video/PDF) - Optional</label>
                <input type="file" name="vault_file" class="form-control">
                <small class="text-muted">Max 5MB. Formats: jpg, png, mp4, pdf</small>
            </div>
            <button type="submit" class="btn btn-primary w-100"><i class="fas fa-save"></i> Save to Vault</button>
        </form>
    </div>
</div>

<h5 class="mb-3"><i class="fas fa-folder-open"></i> Saved Items</h5>

<div class="row g-3">
    <?php foreach($items as $item): ?>
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center" style="max-width: 80%;">
                    <!-- আইকন বা প্রিভিউ -->
                    <div class="me-3">
                        <?php if($item['file_type'] == 'image'): ?>
                            <img src="../assets/vault/<?php echo $item['file_path']; ?>" width="50" height="50" class="rounded" style="object-fit: cover;">
                        <?php elseif($item['file_type'] == 'video'): ?>
                            <i class="fas fa-video fa-2x text-danger"></i>
                        <?php elseif($item['file_type'] == 'file'): ?>
                            <i class="fas fa-file-alt fa-2x text-primary"></i>
                        <?php else: ?>
                            <i class="fas fa-sticky-note fa-2x text-warning"></i>
                        <?php endif; ?>
                    </div>
                    
                    <!-- টেক্সট -->
                    <div>
                        <p class="mb-0 fw-bold text-dark"><?php echo htmlspecialchars($item['note_text']); ?></p>
                        <small class="text-muted"><?php echo date('d M, Y', strtotime($item['created_at'])); ?></small>
                        
                        <!-- ভিউ লিংক -->
                        <?php if($item['file_path']): ?>
                            <br><a href="../assets/vault/<?php echo $item['file_path']; ?>" target="_blank" class="text-primary small text-decoration-none">View File</a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ডিলিট বাটন -->
                <a href="?delete=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this item permanently?')">
                    <i class="fas fa-trash-alt"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if(count($items) == 0): ?>
        <div class="col-12 text-center text-muted py-4">No items in your vault.</div>
    <?php endif; ?>
</div>

<?php require '../common/footer.php'; ?>