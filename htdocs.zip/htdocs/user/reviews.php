<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// রিভিউ সাবমিট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = $_POST['rating'];
    $text = trim($_POST['review_text']);

    if ($rating > 0 && !empty($text)) {
        // আগের রিভিউ আছে কিনা চেক (একজন একবারই দিবে)
        $check = $pdo->prepare("SELECT id FROM app_reviews WHERE user_id = ?");
        $check->execute([$user_id]);

        if ($check->rowCount() > 0) {
            // আপডেট করা
            $pdo->prepare("UPDATE app_reviews SET rating = ?, review_text = ?, created_at = NOW() WHERE user_id = ?")->execute([$rating, $text, $user_id]);
            $success = "Review Updated Successfully!";
        } else {
            // নতুন ইনসার্ট
            $pdo->prepare("INSERT INTO app_reviews (user_id, rating, review_text) VALUES (?, ?, ?)")->execute([$user_id, $rating, $text]);
            $success = "Thanks for your feedback!";
        }
    } else {
        $error = "Please select a rating and write something.";
    }
}

// সব রিভিউ আনা
$sql = "SELECT r.*, u.username, u.profile_pic 
        FROM app_reviews r 
        JOIN users u ON r.user_id = u.id 
        ORDER BY r.id DESC";
$reviews = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<style>
    .star-rating { direction: rtl; display: inline-flex; }
    .star-rating input { display: none; }
    .star-rating label { font-size: 30px; color: #ddd; cursor: pointer; transition: 0.2s; }
    .star-rating input:checked ~ label, .star-rating label:hover, .star-rating label:hover ~ label { color: #ffc107; }
    
    .review-card { background: white; border-radius: 10px; padding: 15px; margin-bottom: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    .user-img { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
</style>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-primary text-white text-center">
        <h5 class="mb-0"><i class="fas fa-star"></i> Rate Our Website</h5>
    </div>
    <div class="card-body text-center">
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <form method="POST">
            <div class="mb-2">
                <div class="star-rating">
                    <input type="radio" id="s5" name="rating" value="5"><label for="s5">★</label>
                    <input type="radio" id="s4" name="rating" value="4"><label for="s4">★</label>
                    <input type="radio" id="s3" name="rating" value="3"><label for="s3">★</label>
                    <input type="radio" id="s2" name="rating" value="2"><label for="s2">★</label>
                    <input type="radio" id="s1" name="rating" value="1"><label for="s1">★</label>
                </div>
            </div>
            <textarea name="review_text" class="form-control mb-3" rows="3" placeholder="Write your experience..." required></textarea>
            <button type="submit" class="btn btn-dark w-100 rounded-pill">Submit Review</button>
        </form>
    </div>
</div>

<h5 class="text-secondary mb-3">User Reviews (<?php echo count($reviews); ?>)</h5>

<?php foreach($reviews as $r): ?>
    <?php $pic = !empty($r['profile_pic']) ? "../assets/images/users/".$r['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png"; ?>
    <div class="review-card d-flex">
        <img src="<?php echo $pic; ?>" class="user-img me-3">
        <div>
            <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($r['username']); ?></h6>
            <div class="text-warning small mb-1">
                <?php for($i=0; $i<$r['rating']; $i++) echo "★"; ?>
            </div>
            <p class="mb-0 text-muted small"><?php echo nl2br(htmlspecialchars($r['review_text'])); ?></p>
            <small class="text-black-50" style="font-size: 10px;"><?php echo date('d M, h:i A', strtotime($r['created_at'])); ?></small>
        </div>
    </div>
<?php endforeach; ?>

<?php require '../common/footer.php'; ?>