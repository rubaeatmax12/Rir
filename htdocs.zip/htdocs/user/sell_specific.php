<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

// URL থেকে টাইপ ধরা
$type = $_GET['type'] ?? 'gmail';
$user_id = $_SESSION['user_id'];

$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();

$rate = 0;
$req_pass = "";

if ($type == 'gmail') { $rate = $settings['rate_gmail']; $req_pass = $settings['pass_gmail']; }
elseif ($type == 'facebook') { $rate = $settings['rate_facebook']; $req_pass = $settings['pass_facebook']; }
elseif ($type == 'instagram') { $rate = $settings['rate_instagram']; $req_pass = $settings['pass_instagram']; }

// ফর্ম সাবমিট
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $user_pass = trim($_POST['password']);
    $two_fa = $_POST['two_fa_key'] ?? NULL; // 2FA Key রিসিভ করা
    
    // ডুপ্লিকেট চেক
    $chk_dup = $pdo->prepare("SELECT id FROM account_sales WHERE email_or_phone = ?");
    $chk_dup->execute([$email]);

    if ($chk_dup->rowCount() > 0) {
        $error = "⚠️ This account has already been submitted!";
    } else {
        // ডাটাবেসে সেভ (2FA সহ)
        $sql = "INSERT INTO account_sales (user_id, type, email_or_phone, password, two_fa_key, price, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')";
        $stmt = $pdo->prepare($sql);
        
        try {
            $stmt->execute([$user_id, $type, $email, $user_pass, $two_fa, $rate]);
            $msg = "Account submitted successfully! Wait for approval.";
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// লিস্ট আনা
$stmt = $pdo->prepare("SELECT * FROM account_sales WHERE user_id = ? AND type = ? AND status IN ('pending', 'checking') ORDER BY id DESC");
$stmt->execute([$user_id, $type]);
$checking_list = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM account_sales WHERE user_id = ? AND type = ? AND status = 'approved' ORDER BY id DESC");
$stmt->execute([$user_id, $type]);
$approved_list = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM account_sales WHERE user_id = ? AND type = ? AND status = 'rejected' ORDER BY id DESC");
$stmt->execute([$user_id, $type]);
$rejected_list = $stmt->fetchAll();

require '../common/header.php';
?>

<style>
    .rate-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 15px; padding: 20px; text-align: center; margin-bottom: 20px; }
    .form-box { background: white; padding: 20px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #f0f0f0; }
    .nav-pills .nav-link { border-radius: 50px; color: #555; font-weight: bold; font-size: 13px; padding: 8px 15px; margin: 0 2px; }
    .nav-pills .nav-link.active { background-color: #0d6efd; color: white; }
    .history-item { background: white; padding: 12px; border-radius: 12px; margin-bottom: 10px; border-left: 5px solid #ccc; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
</style>

<div class="rate-card shadow-sm">
    <i class="fab fa-<?php echo ($type=='facebook'?'facebook':($type=='instagram'?'instagram':'google')); ?> fa-3x mb-2"></i>
    <h3 class="fw-bold m-0">Sell <?php echo ucfirst($type); ?></h3>
    <p class="mb-0 opacity-75">Rate: <strong><?php echo CURRENCY . $rate; ?></strong> / Account</p>
</div>

<div class="form-box mb-4">
    <?php if(isset($msg)) showAlert($msg, 'success'); ?>
    <?php if(isset($error)) showAlert($error, 'danger'); ?>

    <form method="POST">
        <div class="input-group mb-3">
            <span class="input-group-text bg-light text-muted">Req. Pass</span>
            <input type="text" value="<?php echo $req_pass; ?>" id="copyPass" class="form-control bg-white text-danger fw-bold" readonly>
            <button type="button" class="btn btn-outline-dark" onclick="copyPassword()"><i class="fas fa-copy"></i></button>
        </div>

        <div class="form-floating mb-2">
            <input type="text" name="email" class="form-control" id="floatEmail" placeholder="Email/Phone" required>
            <label for="floatEmail">Email / Phone / User ID</label>
        </div>
        
        <div class="form-floating mb-3">
            <input type="text" name="password" class="form-control" id="floatPass" placeholder="Password" required>
            <label for="floatPass">Account Password</label>
        </div>

        <!-- 🔥 2FA Key অপশন (শুধুমাত্র FB এবং Insta এর জন্য) 🔥 -->
        <?php if($type != 'gmail'): ?>
        <div class="form-floating mb-3 border border-success rounded">
            <input type="text" name="two_fa_key" class="form-control text-success fw-bold" id="float2FA" placeholder="2FA Code" required>
            <label for="float2FA">🔑 2FA Security Key (Required)</label>
        </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 shadow-sm">
            Submit for <?php echo CURRENCY . $rate; ?> <i class="fas fa-paper-plane"></i>
        </button>
    </form>
</div>

<ul class="nav nav-pills nav-fill mb-3" id="pills-tab" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#pills-checking">Checking</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-approved">Approved</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-rejected">Rejected</button></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade show active" id="pills-checking">
        <?php foreach($checking_list as $item): ?>
            <div class="history-item" style="border-left-color: #17a2b8;">
                <div class="d-flex justify-content-between">
                    <div>
                        <span class="fw-bold"><?php echo $item['email_or_phone']; ?></span><br>
                        <small class="text-muted">Pass: <?php echo $item['password']; ?></small>
                    </div>
                    <span class="badge bg-info"><?php echo $item['status'] == 'checking' ? 'Checking...' : 'Pending'; ?></span>
                </div>
            </div>
        <?php endforeach; if(empty($checking_list)) echo "<div class='text-center py-3 text-muted'>No pending accounts.</div>"; ?>
    </div>

    <!-- Approved List -->
    <div class="tab-pane fade" id="pills-approved">
        <?php foreach($approved_list as $item): ?>
            <div class="history-item" style="border-left-color: #28a745;">
                <div class="d-flex justify-content-between">
                    <span class="fw-bold"><?php echo $item['email_or_phone']; ?></span>
                    <span class="badge bg-success">Sold (+<?php echo $item['price']; ?>)</span>
                </div>
            </div>
        <?php endforeach; if(empty($approved_list)) echo "<div class='text-center py-3 text-muted'>No sold accounts.</div>"; ?>
    </div>

    <!-- Rejected List -->
    <div class="tab-pane fade" id="pills-rejected">
        <?php foreach($rejected_list as $item): ?>
            <div class="history-item" style="border-left-color: #dc3545;">
                <div class="d-flex justify-content-between">
                    <span class="fw-bold"><?php echo $item['email_or_phone']; ?></span>
                    <span class="badge bg-danger">Rejected</span>
                </div>
            </div>
        <?php endforeach; if(empty($rejected_list)) echo "<div class='text-center py-3 text-muted'>No rejected accounts.</div>"; ?>
    </div>
</div>

<script>
function copyPassword() {
    var copyText = document.getElementById("copyPass");
    copyText.select(); document.execCommand("copy"); alert("Password Copied!");
}
</script>
<?php require '../common/footer.php'; ?>