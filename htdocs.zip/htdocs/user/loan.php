<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// লোন রিকোয়েস্ট সাবমিট
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = $_POST['amount'];
    $reason = $_POST['reason'];
    $name = $_POST['full_name'];
    $address = $_POST['address'];

    // ১. চেক করা আগের কোনো লোন পেন্ডিং আছে কিনা
    $stmt = $pdo->prepare("SELECT id FROM loan_requests WHERE user_id = ? AND status = 'pending'");
    $stmt->execute([$user_id]);
    
    if ($stmt->rowCount() > 0) {
        $error = "You already have a pending loan request!";
    } elseif ($amount < 50 || $amount > 5000) {
        $error = "Loan amount must be between 50 to 5000 Tk.";
    } else {
        // ২. ছবি আপলোড
        $front_img = time() . "_nid_f_" . $_FILES['nid_front']['name'];
        $back_img = time() . "_nid_b_" . $_FILES['nid_back']['name'];
        
        $target_dir = "../assets/images/loans/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

        if (move_uploaded_file($_FILES['nid_front']['tmp_name'], $target_dir . $front_img) && 
            move_uploaded_file($_FILES['nid_back']['tmp_name'], $target_dir . $back_img)) {

            // ৩. ডাটাবেসে সেভ করা
            $sql = "INSERT INTO loan_requests (user_id, amount, reason, full_name, address, nid_front, nid_back) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $pdo->prepare($sql)->execute([$user_id, $amount, $reason, $name, $address, $front_img, $back_img]);
            
            $success = "Loan request submitted with documents! Wait for approval.";
        } else {
            $error = "Image upload failed! Please try again.";
        }
    }
}

// লোন হিস্ট্রি
$stmt = $pdo->prepare("SELECT * FROM loan_requests WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$loans = $stmt->fetchAll();

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <!-- লোন ফর্ম -->
        <div class="card shadow-sm mb-4 border-primary">
            <div class="card-header bg-primary text-white text-center">
                <h4><i class="fas fa-hand-holding-usd"></i> Request Loan</h4>
            </div>
            <div class="card-body">
                <?php if(isset($error)) showAlert($error, 'danger'); ?>
                <?php if(isset($success)) showAlert($success, 'success'); ?>

                <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Amount (50 - 5000 Tk)</label>
                            <input type="number" name="amount" class="form-control" placeholder="Ex: 500" min="50" max="5000" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Reason</label>
                            <input type="text" name="reason" class="form-control" placeholder="Ex: Medical/Emergency" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Full Name (NID অনুযায়ী)</label>
                        <input type="text" name="full_name" class="form-control" placeholder="Your Full Name" required>
                    </div>

                    <div class="mb-3">
                        <label>Full Address</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="Village, Thana, District..." required></textarea>
                    </div>

                    <div class="row">
                        <div class="col-6 mb-3">
                            <label>NID Front Photo</label>
                            <input type="file" name="nid_front" class="form-control" required>
                        </div>
                        <div class="col-6 mb-3">
                            <label>NID Back Photo</label>
                            <input type="file" name="nid_back" class="form-control" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Submit Request</button>
                </form>
                <small class="text-muted mt-2 d-block text-center">Admin will verify your documents before approving.</small>
            </div>
        </div>

        <!-- লোন হিস্ট্রি -->
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">Loan History</div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($loans as $l): ?>
                        <tr>
                            <td><?php echo date('d M, Y', strtotime($l['created_at'])); ?></td>
                            <td class="fw-bold"><?php echo CURRENCY . $l['amount']; ?></td>
                            <td>
                                <?php 
                                    if($l['status'] == 'approved') echo '<span class="badge bg-success">Approved</span>';
                                    elseif($l['status'] == 'rejected') echo '<span class="badge bg-danger">Rejected</span>';
                                    else echo '<span class="badge bg-warning text-dark">Pending</span>';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($loans)) echo "<tr><td colspan='3' class='text-center p-3'>No loan history.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>