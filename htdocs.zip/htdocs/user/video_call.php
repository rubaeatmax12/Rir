<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// রুম আইডি তৈরি (যাতে দুজন একই রুমে জয়েন করে)
// ধরুন: call_user1_user2
$roomID = $_GET['roomID'] ?? 'room_'.$user_id;
$is_video = $_GET['video'] ?? 'true'; // ভিডিও অন/অফ

?>
<!DOCTYPE html>
<html>
<head>
    <style>
        #root { width: 100vw; height: 100vh; }
    </style>
</head>
<body>
    <div id="root"></div>

    <!-- ZegoCloud UI Kit -->
    <script src="https://unpkg.com/@zegocloud/zego-uikit-prebuilt/zego-uikit-prebuilt.js"></script>
    <script>
    window.onload = function () {
        // 🔥 অ্যাপ আইডি এবং সিক্রেট (ফ্রি একাউন্ট খুলে বসাতে হবে)
        // আপাতত টেস্টিং এর জন্য ডিফল্ট কিছু কাজ নাও করতে পারে।
        // তোমাকে ZegoCloud Console থেকে ID আনতে হবে।
        
        // এখানে আমি ডেমো লজিক দিচ্ছি:
        const appID = 1667024367; // এটা ডেমো, তোমার নিজেরটা বসাতে হবে
        const serverSecret = "d3062635955627702202633000676796"; // এটাও ডেমো

        const roomID = "<?php echo $roomID; ?>";
        const userID = "<?php echo $user_id; ?>";
        const userName = "<?php echo $username; ?>";

        const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
            appID, 
            serverSecret, 
            roomID, 
            userID, 
            userName
        );

        const zp = ZegoUIKitPrebuilt.create(kitToken);
        
        zp.joinRoom({
            container: document.querySelector("#root"),
            sharedLinks: [{
                name: 'Call Link',
                url: window.location.href
            }],
            scenario: {
                mode: ZegoUIKitPrebuilt.OneONoneCall, // 1-on-1 Call
            },
            showScreenSharingButton: false,
            turnOnCameraWhenJoining: <?php echo $is_video; ?>,
            turnOnMicrophoneWhenJoining: true,
            showMyCameraToggleButton: true,
            showMyMicrophoneToggleButton: true,
            showAudioVideoSettingsButton: true,
            onLeaveRoom: () => {
                window.location.href = "chat.php"; // কল কাটলে চ্যাটে ফেরত যাবে
            } 
        });
    };
    </script>
</body>
</html>