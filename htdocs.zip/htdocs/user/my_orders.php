<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ইউজারের সব অর্ডার আনা (প্রোডাক্টের নাম ও ছবি সহ)
$sql = "SELECT o.*, p.title, p.image 
        FROM product_orders o 
        JOIN digital_products p ON o.product_id = p.id 
        WHERE o.user_id = ? 
        ORDER BY o.id DESC";
$orders = $pdo->prepare($sql);
$orders->execute([$user_id]);
$my_orders = $orders->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center mb-4 text-primary"><i class="fas fa-shopping-bag"></i> My Order History</h3>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th width="60">Img</th>
                        <th>Product</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($my_orders) > 0): ?>
                        <?php foreach($my_orders as $order): ?>
                        <tr>
                            <!-- প্রোডাক্ট ছবি -->
                            <td>
                                <img src="../assets/images/products/<?php echo $order['image']; ?>" class="rounded" width="50" height="50" style="object-fit: cover;">
                            </td>
                            
                            <!-- নাম, দাম এবং তারিখ -->
                            <td>
                                <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($order['title']); ?></h6>
                                <small class="text-muted"><?php echo date('d M, h:i A', strtotime($order['created_at'])); ?></small>
                                <div class="text-danger fw-bold" style="font-size: 12px;"><?php echo CURRENCY . $order['price']; ?></div>
                            </td>
                            
                            <!-- স্ট্যাটাস (পেন্ডিং নাকি সাকসেস) -->
                            <td>
                                <?php if($order['status'] == 'pending'): ?>
                                    <span class="badge bg-warning text-dark">
                                        <i class="fas fa-clock"></i> Pending
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success">
                                        <i class="fas fa-check-circle"></i> Shipped
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center py-5 text-muted">
                                <i class="fas fa-box-open fa-3x mb-3"></i><br>
                                You haven't ordered anything yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="text-center mt-3">
    <a href="shop.php" class="btn btn-outline-dark">Continue Shopping</a>
</div>

<?php require '../common/footer.php'; ?>