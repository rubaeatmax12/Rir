<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ভিডিও আপলোড লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['video_file'])) {
    $title = $_POST['title'];
    $file = $_FILES['video_file'];
    
    // ভিডিও নাম এবং পাথ
    $vid_name = time() . "_" . $file['name'];
    $target = "../assets/videos/" . $vid_name;
    
    // ফোল্ডার না থাকলে তৈরি করা
    if (!is_dir('../assets/videos')) mkdir('../assets/videos', 0777, true);

    // শুধু mp4 এলাউড
    $ext = strtolower(pathinfo($vid_name, PATHINFO_EXTENSION));
    if ($ext == 'mp4' || $ext == 'mkv') {
        if (move_uploaded_file($file['tmp_name'], $target)) {
            $pdo->prepare("INSERT INTO app_videos (user_id, title, video_file) VALUES (?, ?, ?)")->execute([$user_id, $title, $vid_name]);
            $success = "Video uploaded successfully!";
        } else {
            $error = "Upload failed!";
        }
    } else {
        $error = "Only MP4 videos allowed!";
    }
}

// সব ভিডিও আনা
$sql = "SELECT v.*, u.username, u.profile_pic,
        (SELECT count(*) FROM video_likes WHERE video_id = v.id) as likes,
        (SELECT count(*) FROM video_likes WHERE video_id = v.id AND user_id = $user_id) as is_liked
        FROM app_videos v 
        JOIN users u ON v.user_id = u.id 
        ORDER BY v.id DESC";
$videos = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<style>
    .video-card { background: white; border-radius: 15px; overflow: hidden; margin-bottom: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    video { width: 100%; max-height: 400px; background: black; }
    .action-bar { padding: 10px; display: flex; justify-content: space-between; align-items: center; }
    .like-btn.active { color: red; }
</style>

<!-- আপলোড বাটন -->
<div class="text-center mb-4">
    <button class="btn btn-primary w-100 rounded-pill" type="button" data-bs-toggle="collapse" data-bs-target="#uploadBox">
        <i class="fas fa-video"></i> Upload New Video
    </button>
</div>

<!-- আপলোড ফর্ম (লুকানো থাকবে) -->
<div class="collapse mb-4" id="uploadBox">
    <div class="card card-body">
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="title" class="form-control mb-2" placeholder="Video Caption..." required>
            <input type="file" name="video_file" class="form-control mb-2" accept="video/mp4" required>
            <button class="btn btn-success w-100">Post Video</button>
        </form>
    </div>
</div>

<!-- ভিডিও লিস্ট -->
<?php foreach($videos as $v): ?>
    <?php $pic = !empty($v['profile_pic']) ? "../assets/images/users/".$v['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png"; ?>
    
    <div class="video-card">
        <!-- হেডার -->
        <div class="p-2 d-flex align-items-center">
            <img src="<?php echo $pic; ?>" width="40" height="40" class="rounded-circle border me-2">
            <div>
                <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($v['username']); ?></h6>
                <small class="text-muted"><?php echo date('d M, h:i A', strtotime($v['created_at'])); ?></small>
            </div>
        </div>

        <!-- ক্যাপশন -->
        <div class="px-2 pb-2 small"><?php echo htmlspecialchars($v['title']); ?></div>

        <!-- প্লেয়ার -->
        <video controls>
            <source src="../assets/videos/<?php echo $v['video_file']; ?>" type="video/mp4">
        </video>

        <!-- অ্যাকশন -->
        <div class="action-bar">
            <button class="btn btn-light btn-sm like-btn <?php echo $v['is_liked']?'active':''; ?>" data-id="<?php echo $v['id']; ?>">
                <i class="fas fa-heart"></i> <span id="count-<?php echo $v['id']; ?>"><?php echo $v['likes']; ?></span>
            </button>
            <button class="btn btn-light btn-sm" onclick="$('#cmt-<?php echo $v['id']; ?>').toggle()">
                <i class="fas fa-comment"></i> Comment
            </button>
        </div>

        <!-- কমেন্ট বক্স -->
        <div id="cmt-<?php echo $v['id']; ?>" style="display:none;" class="p-2 border-top">
            <form class="d-flex cmt-form" data-id="<?php echo $v['id']; ?>">
                <input type="text" class="form-control form-control-sm me-2" placeholder="Write a comment..." required>
                <button class="btn btn-primary btn-sm"><i class="fas fa-paper-plane"></i></button>
            </form>
            
            <!-- রিসেন্ট কমেন্ট দেখানো (সিম্পল ভিউ) -->
            <?php 
                $cmts = $pdo->query("SELECT * FROM video_comments WHERE video_id = ".$v['id']." ORDER BY id DESC LIMIT 5")->fetchAll();
                foreach($cmts as $c) {
                    echo "<div class='small bg-light p-1 mt-1 rounded'>".htmlspecialchars($c['comment'])."</div>";
                }
            ?>
        </div>
    </div>
<?php endforeach; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    // লাইক
    $('.like-btn').click(function(){
        let btn = $(this);
        let vid = btn.data('id');
        let counter = $('#count-'+vid);
        
        $.post('../api/video_api.php', { action: 'like', video_id: vid }, function(res){
            if(res.status == 'liked') {
                btn.addClass('active');
                counter.text(parseInt(counter.text()) + 1);
            } else {
                btn.removeClass('active');
                counter.text(parseInt(counter.text()) - 1);
            }
        }, 'json');
    });

    // কমেন্ট
    $('.cmt-form').submit(function(e){
        e.preventDefault();
        let form = $(this);
        let vid = form.data('id');
        let txt = form.find('input').val();
        
        $.post('../api/video_api.php', { action: 'comment', video_id: vid, comment: txt }, function(res){
            alert("Comment added!");
            location.reload(); // পেজ রিফ্রেশ করে কমেন্ট দেখাবে
        }, 'json');
    });
});
</script>

<!-- ফুটার স্পেস -->
<div style="height: 60px;"></div>
<?php require '../common/footer.php'; ?>