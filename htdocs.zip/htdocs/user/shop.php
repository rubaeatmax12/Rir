<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

// 🔥 আপডেট করা লাইন: শুধুমাত্র অ্যাপ্রুভ করা (Approved) প্রোডাক্ট দেখাবে
$products = $pdo->query("SELECT * FROM digital_products WHERE status = 'approved' ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3><i class="fas fa-store"></i> Shopping Mall</h3>
    <!-- অর্ডার হিস্ট্রি দেখার বাটন -->
    <a href="my_orders.php" class="btn btn-dark btn-sm">My Orders</a>
</div>

<div class="row g-3">
    <?php foreach($products as $p): ?>
    <div class="col-6 col-md-4">
        <div class="card h-100 shadow-sm border-0">
            <!-- প্রোডাক্টের ছবি -->
            <img src="../assets/images/products/<?php echo $p['image']; ?>" class="card-img-top rounded-top" style="height: 140px; object-fit: cover;">
            
            <div class="card-body p-2 text-center">
                <!-- প্রোডাক্টের নাম -->
                <h6 class="card-title text-truncate"><?php echo htmlspecialchars($p['title']); ?></h6>
                
                <!-- দাম -->
                <p class="card-text text-danger fw-bold mb-2"><?php echo CURRENCY . number_format($p['price'], 2); ?></p>
                
                <!-- সেলার ইনফো (কে আপলোড করেছে) -->
                <?php if($p['user_id'] > 0): ?>
                    <span class="badge bg-light text-dark border mb-2" style="font-size: 10px;">User Product</span>
                <?php else: ?>
                    <span class="badge bg-info text-white mb-2" style="font-size: 10px;">Official</span>
                <?php endif; ?>
                
                <!-- অর্ডার বাটন -->
                <a href="confirm_order.php?pid=<?php echo $p['id']; ?>" class="btn btn-primary btn-sm w-100">
                    Buy Now <i class="fas fa-shopping-bag"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if(count($products) == 0): ?>
        <div class="col-12 text-center py-5 text-muted">
            <i class="fas fa-box-open fa-3x mb-3"></i><br>
            No products available right now.
        </div>
    <?php endif; ?>
</div>

<?php require '../common/footer.php'; ?>