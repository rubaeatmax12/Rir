<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$products = $pdo->query("SELECT * FROM affiliate_products ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3 class="text-center text-primary"><i class="fas fa-bullhorn"></i> Affiliate Marketing</h3>
<p class="text-center text-muted">Share these products & earn per click!</p>

<div class="row g-3">
    <?php foreach($products as $p): ?>
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="row g-0 align-items-center">
                <div class="col-4">
                    <img src="../assets/images/products/<?php echo $p['image']; ?>" class="img-fluid rounded-start h-100" style="object-fit: cover;">
                </div>
                <div class="col-8">
                    <div class="card-body">
                        <h6 class="card-title mb-1"><?php echo $p['title']; ?></h6>
                        <span class="badge bg-success mb-2">Earn <?php echo CURRENCY . $p['commission']; ?> / Click</span>
                        
                        <!-- ট্র্যাকিং লিংক -->
                        <?php $share_link = SITE_URL . "/track.php?uid=" . $_SESSION['user_id'] . "&pid=" . $p['id']; ?>
                        
                        <div class="input-group input-group-sm">
                            <input type="text" value="<?php echo $share_link; ?>" class="form-control" readonly>
                            <button class="btn btn-dark" onclick="navigator.clipboard.writeText('<?php echo $share_link; ?>'); alert('Link Copied!');">Copy</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php require '../common/footer.php'; ?>