<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_code = strtoupper(trim($_POST['code']));

    // ১. কোডটি সঠিক কিনা চেক করা
    $stmt = $pdo->prepare("SELECT * FROM promo_codes WHERE code = ? AND status = 'active'");
    $stmt->execute([$input_code]);
    $promo = $stmt->fetch();

    if ($promo) {
        // ২. ইউজার আগে ব্যবহার করেছে কিনা চেক করা
        $usage_check = $pdo->prepare("SELECT id FROM promo_usage WHERE user_id = ? AND promo_id = ?");
        $usage_check->execute([$user_id, $promo['id']]);

        if ($usage_check->rowCount() > 0) {
            $error = "You have already used this code!";
        } else {
            // ৩. সব ঠিক থাকলে টাকা দেওয়া
            $pdo->beginTransaction();
            try {
                // ব্যালেন্স এড
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$promo['amount'], $user_id]);
                // ইউসেজ হিস্ট্রি সেভ
                $pdo->prepare("INSERT INTO promo_usage (user_id, promo_id) VALUES (?, ?)")->execute([$user_id, $promo['id']]);
                
                $pdo->commit();
                $success = "Congratulations! You received " . CURRENCY . $promo['amount'] . " Bonus! 🎉";
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Something went wrong!";
            }
        }
    } else {
        $error = "Invalid or Expired Promo Code!";
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow border-0 text-center">
            <div class="card-header bg-warning text-dark">
                <h4><i class="fas fa-gift"></i> Redeem Promo Code</h4>
            </div>
            <div class="card-body py-5">
                <?php if(isset($success)) showAlert($success, 'success'); ?>
                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <i class="fas fa-ticket-alt fa-4x text-warning mb-3"></i>
                <p class="lead">Have a special code? Enter it below!</p>

                <form method="POST">
                    <div class="input-group mb-3">
                        <input type="text" name="code" class="form-control form-control-lg text-center text-uppercase" placeholder="ENTER CODE HERE" required>
                        <button class="btn btn-dark" type="submit">Claim</button>
                    </div>
                </form>
                <small class="text-muted">Codes are available on our Telegram channel.</small>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>