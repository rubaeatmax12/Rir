<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ১. নতুন পোস্ট সাবমিট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_content'])) {
    $content = trim($_POST['post_content']);
    $image = "";

    // ছবি আপলোড
    if (!empty($_FILES['post_image']['name'])) {
        $img_name = time() . "_" . $_FILES['post_image']['name'];
        $target = "../assets/images/posts/" . $img_name;
        if (!is_dir('../assets/images/posts')) mkdir('../assets/images/posts', 0777, true);
        move_uploaded_file($_FILES['post_image']['tmp_name'], $target);
        $image = $img_name;
    }

    if ($content != "" || $image != "") {
        $pdo->prepare("INSERT INTO social_posts (user_id, content, image) VALUES (?, ?, ?)")->execute([$user_id, $content, $image]);
        header("Location: social_feed.php"); // রিফ্রেশ
        exit;
    }
}

// ২. স্ট্যাটস গণনা (পোস্ট, ফলোয়ার, ফলোইং)
$my_posts = $pdo->prepare("SELECT count(*) FROM social_posts WHERE user_id = ?");
$my_posts->execute([$user_id]);
$total_posts = $my_posts->fetchColumn();

$my_followers = $pdo->prepare("SELECT count(*) FROM social_follows WHERE following_id = ?");
$my_followers->execute([$user_id]);
$total_followers = $my_followers->fetchColumn();

$my_following = $pdo->prepare("SELECT count(*) FROM social_follows WHERE follower_id = ?");
$my_following->execute([$user_id]);
$total_following = $my_following->fetchColumn();

// ৩. সব পোস্ট নিয়ে আসা (অ্যাডমিন চেক সহ)
$sql = "SELECT p.*, u.username, u.profile_pic, u.role, 
        (SELECT count(*) FROM social_likes WHERE post_id = p.id) as like_count,
        (SELECT count(*) FROM social_likes WHERE post_id = p.id AND user_id = $user_id) as is_liked
        FROM social_posts p 
        JOIN users u ON p.user_id = u.id 
        ORDER BY p.id DESC";
$posts = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<style>
    .profile-stat-box { background: white; padding: 15px; border-radius: 15px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 20px; }
    .post-card { background: white; border-radius: 15px; padding: 15px; margin-bottom: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .admin-badge { background: #1877F2; color: white; padding: 2px 6px; border-radius: 5px; font-size: 10px; font-weight: bold; margin-left: 5px; }
    .action-btn { border: none; background: none; color: #65676b; font-weight: 600; font-size: 14px; }
    .action-btn.liked { color: #1877F2; }
    .user-pic { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
</style>

<!-- ১. প্রোফাইল স্ট্যাটস -->
<div class="row g-2 mb-3">
    <div class="col-4">
        <div class="profile-stat-box">
            <h5 class="mb-0 fw-bold"><?php echo $total_posts; ?></h5>
            <small class="text-muted">Posts</small>
        </div>
    </div>
    <div class="col-4">
        <div class="profile-stat-box">
            <h5 class="mb-0 fw-bold"><?php echo $total_followers; ?></h5>
            <small class="text-muted">Followers</small>
        </div>
    </div>
    <div class="col-4">
        <div class="profile-stat-box">
            <h5 class="mb-0 fw-bold"><?php echo $total_following; ?></h5>
            <small class="text-muted">Following</small>
        </div>
    </div>
</div>

<!-- ২. পোস্ট করার বক্স -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <textarea name="post_content" class="form-control border-0 bg-light mb-2" rows="2" placeholder="What's on your mind?"></textarea>
            <div class="d-flex justify-content-between align-items-center">
                <input type="file" name="post_image" class="form-control form-control-sm w-50">
                <button type="submit" class="btn btn-primary btn-sm px-4">Post</button>
            </div>
        </form>
    </div>
</div>

<!-- ৩. নিউজ ফিড (সব পোস্ট) -->
<?php foreach($posts as $post): ?>
    <?php 
        $pic = !empty($post['profile_pic']) ? "../assets/images/users/".$post['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png";
    ?>
    <div class="post-card">
        <!-- হেডার -->
        <div class="d-flex align-items-center mb-2">
            <img src="<?php echo $pic; ?>" class="user-pic me-2">
            <div>
                <h6 class="mb-0 fw-bold">
                    <?php echo htmlspecialchars($post['username']); ?>
                    <?php if($post['role'] == 'admin') echo '<span class="admin-badge"><i class="fas fa-check-circle"></i> Admin</span>'; ?>
                </h6>
                <small class="text-muted" style="font-size: 11px;"><?php echo date('d M, h:i A', strtotime($post['created_at'])); ?></small>
            </div>
            
            <!-- ফলো বাটন (নিজেকে ছাড়া) -->
            <?php if($post['user_id'] != $user_id): ?>
                <button class="btn btn-sm btn-outline-primary ms-auto py-0 follow-btn" data-id="<?php echo $post['user_id']; ?>">Follow</button>
            <?php endif; ?>
        </div>

        <!-- কন্টেন্ট -->
        <p class="mb-2"><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
        <?php if(!empty($post['image'])): ?>
            <img src="../assets/images/posts/<?php echo $post['image']; ?>" class="img-fluid rounded mb-2 w-100">
        <?php endif; ?>

        <hr class="my-2">

        <!-- অ্যাকশন বাটন -->
        <div class="d-flex justify-content-between">
            <button class="action-btn like-btn <?php echo $post['is_liked'] ? 'liked' : ''; ?>" data-id="<?php echo $post['id']; ?>">
                <i class="fas fa-thumbs-up"></i> <span><?php echo $post['like_count']; ?></span> Like
            </button>
            <a href="post_details.php?id=<?php echo $post['id']; ?>" class="action-btn text-decoration-none">
                <i class="fas fa-comment"></i> Comment
            </a>
            <button class="action-btn" onclick="sharePost()">
                <i class="fas fa-share"></i> Share
            </button>
        </div>
    </div>
<?php endforeach; ?>

<!-- AJAX স্ক্রিপ্ট (লাইক ও ফলো এর জন্য) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    // লাইক বাটন
    $('.like-btn').click(function(){
        let btn = $(this);
        let pid = btn.data('id');
        
        $.post('../api/social_api.php', { action: 'like', post_id: pid }, function(res){
            if(res.status == 'liked') {
                btn.addClass('liked');
                btn.find('span').text(parseInt(btn.find('span').text()) + 1);
            } else {
                btn.removeClass('liked');
                btn.find('span').text(parseInt(btn.find('span').text()) - 1);
            }
        }, 'json');
    });

    // ফলো বাটন
    $('.follow-btn').click(function(){
        let btn = $(this);
        let uid = btn.data('id');
        
        $.post('../api/social_api.php', { action: 'follow', follow_id: uid }, function(res){
            alert(res.msg);
            btn.text(res.status == 'followed' ? 'Unfollow' : 'Follow');
        }, 'json');
    });
});

function sharePost() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo SITE_NAME; ?>',
            text: 'Check out this post on AlphaEarner!',
            url: window.location.href
        });
    } else {
        alert('Link copied to clipboard!');
    }
}
</script>

<!-- ফুটার হাইড স্পেস -->
<div style="height: 60px;"></div>
<?php require '../common/footer.php'; ?>