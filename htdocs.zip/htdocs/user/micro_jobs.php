<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

// সব একটিভ জব আনা
$sql = "SELECT j.*, u.username 
        FROM user_jobs j 
        JOIN users u ON j.user_id = u.id 
        WHERE j.status = 'active' ORDER BY j.id DESC";
$jobs = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center text-success mb-3"><i class="fas fa-search-dollar"></i> Available Micro Jobs</h3>

<div class="row g-3">
    <?php foreach($jobs as $j): ?>
    <div class="col-12">
        <div class="card shadow-sm border-start border-5 border-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold"><?php echo htmlspecialchars($j['title']); ?></h5>
                    <span class="badge bg-success fs-6"><?php echo CURRENCY . $j['rate']; ?></span>
                </div>
                <p class="text-muted small mb-2">Posted by: <?php echo $j['username']; ?> | Workers Needed: <?php echo $j['quantity']; ?></p>
                <a href="do_job.php?id=<?php echo $j['id']; ?>" class="btn btn-sm btn-outline-primary w-100">Do this Job</a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if(empty($jobs)) echo "<p class='text-center'>No jobs available.</p>"; ?>
</div>

<?php require '../common/footer.php'; ?>