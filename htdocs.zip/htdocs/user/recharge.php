<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

// Fetch Active Numbers
$stmt = $pdo->query("SELECT * FROM deposit_methods WHERE is_active = 1");
$methods = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = $_POST['amount'];
    $method = $_POST['method'];
    $trx_id = $_POST['trx_id'];
    $sender = $_POST['sender_number'];

    // Insert request
    $sql = "INSERT INTO deposits (user_id, amount, method, sender_number, trx_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    try {
        $stmt->execute([$_SESSION['user_id'], $amount, $method, $sender, $trx_id]);
        $success = "Deposit request submitted successfully! Wait for admin approval.";
    } catch(Exception $e) {
        $error = "Error: Transaction ID might be duplicate.";
    }
}
require '../common/header.php';
?>

<div class="card">
    <div class="card-header">Add Money / Recharge</div>
    <div class="card-body">
        <?php if(isset($success)) showAlert($success); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <div class="alert alert-info">
            <strong>Payment Methods:</strong><br>
            <?php foreach($methods as $m): ?>
                <?php echo $m['method_name']; ?>: <?php echo $m['number']; ?> (<?php echo $m['type']; ?>)<br>
            <?php endforeach; ?>
        </div>

        <form method="POST">
            <div class="mb-3">
                <label>Select Method</label>
                <select name="method" class="form-control" required>
                    <option value="bkash">bKash</option>
                    <option value="nagad">Nagad</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Amount</label>
                <input type="number" name="amount" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Sender Number</label>
                <input type="text" name="sender_number" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Transaction ID</label>
                <input type="text" name="trx_id" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit Request</button>
        </form>
    </div>
</div>
<?php require '../common/footer.php'; ?>