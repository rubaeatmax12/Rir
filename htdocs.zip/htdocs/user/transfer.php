<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$my_balance = getUserBalance($pdo, $user_id);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $receiver_username = trim($_POST['username']);
    $amount = $_POST['amount'];
    $password = $_POST['password'];

    // ১. নিজের পাসওয়ার্ড চেক করা
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $my_pass = $stmt->fetchColumn();

    if (!password_verify($password, $my_pass)) {
        $error = "Incorrect Password!";
    } 
    // ২. ব্যালেন্স চেক
    elseif ($amount > $my_balance) {
        $error = "Insufficient Balance!";
    } 
    elseif ($amount < 10) {
        $error = "Minimum transfer amount is 10 Tk.";
    } 
    else {
        // ৩. যাকে পাঠাবে সে আছে কিনা চেক করা
        $stmt = $pdo->prepare("SELECT id, username FROM users WHERE username = ?");
        $stmt->execute([$receiver_username]);
        $receiver = $stmt->fetch();

        if (!$receiver) {
            $error = "Receiver username not found!";
        } elseif ($receiver['id'] == $user_id) {
            $error = "You cannot send money to yourself!";
        } else {
            // ৪. সব ঠিক থাকলে টাকা পাঠানো (Transaction)
            $pdo->beginTransaction();
            try {
                // আমার টাকা কাটা
                $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user_id]);
                
                // তার একাউন্টে টাকা যোগ করা
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount, $receiver['id']]);
                
                // হিস্ট্রি সেভ করা
                $sql = "INSERT INTO transfer_history (sender_id, receiver_id, amount) VALUES (?, ?, ?)";
                $pdo->prepare($sql)->execute([$user_id, $receiver['id'], $amount]);

                // তাকে নোটিফিকেশন পাঠানো
                $msg = "You received " . CURRENCY . $amount . " from user: " . $_SESSION['username'];
                $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Money Received 💰', ?)")->execute([$receiver['id'], $msg]);

                $pdo->commit();
                $success = "Successfully sent " . CURRENCY . "$amount to " . $receiver['username'];
                $my_balance -= $amount; // ব্যালেন্স আপডেট দেখানো
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Something went wrong!";
            }
        }
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-success text-white text-center">
                <h4><i class="fas fa-exchange-alt"></i> Send Money</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-light text-center border">
                    Available Balance: <strong class="text-success"><?php echo CURRENCY . number_format($my_balance, 2); ?></strong>
                </div>

                <?php if(isset($error)) showAlert($error, 'danger'); ?>
                <?php if(isset($success)) showAlert($success, 'success'); ?>

                <form method="POST">
                    <div class="mb-3">
                        <label>Receiver Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Enter username (e.g. karim22)" required>
                    </div>
                    <div class="mb-3">
                        <label>Amount (Min: 10 Tk)</label>
                        <input type="number" name="amount" class="form-control" placeholder="Ex: 50" min="10" required>
                    </div>
                    <div class="mb-3">
                        <label>Your Password (For Security)</label>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100">Confirm Transfer 💸</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>