<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$my_id = $_SESSION['user_id'];

// সব ইউজার লিস্ট (নিজেকে ছাড়া)
$users = $pdo->query("SELECT * FROM users WHERE id != $my_id ORDER BY id DESC LIMIT 20")->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center text-primary mb-3"><i class="fas fa-phone-alt"></i> Call Friends</h3>

<div class="list-group">
    <?php foreach($users as $u): ?>
        <?php 
            $pic = !empty($u['profile_pic']) ? "../assets/images/users/".$u['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png";
            // রুম আইডি জেনারেট (ছোট আইডি আগে, বড় আইডি পরে - যাতে ইউনিক হয়)
            $roomID = ($my_id < $u['id']) ? "call_".$my_id."_".$u['id'] : "call_".$u['id']."_".$my_id;
        ?>
        <div class="list-group-item d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <img src="<?php echo $pic; ?>" width="45" height="45" class="rounded-circle border me-3">
                <div>
                    <h6 class="mb-0 fw-bold">
                        <?php echo $u['username']; ?>
                        <?php if($u['is_verified']) echo '<i class="fas fa-check-circle text-primary"></i>'; ?>
                    </h6>
                    <small class="text-muted"><?php echo $u['phone']; ?></small>
                </div>
            </div>
            
            <div>
                <!-- অডিও কল -->
                <a href="video_call.php?roomID=<?php echo $roomID; ?>&video=false" class="btn btn-light btn-sm text-primary rounded-circle p-2 me-1">
                    <i class="fas fa-phone-alt"></i>
                </a>
                <!-- ভিডিও কল -->
                <a href="video_call.php?roomID=<?php echo $roomID; ?>&video=true" class="btn btn-light btn-sm text-success rounded-circle p-2">
                    <i class="fas fa-video"></i>
                </a>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>