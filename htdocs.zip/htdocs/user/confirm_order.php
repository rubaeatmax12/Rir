<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$product_id = $_GET['pid'];

// প্রোডাক্ট ইনফো আনা
$stmt = $pdo->prepare("SELECT * FROM digital_products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) { die("Product not found!"); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    // ব্যালেন্স চেক
    $u_stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $u_stmt->execute([$user_id]);
    $balance = $u_stmt->fetchColumn();

    if ($balance >= $product['price']) {
        // ১. টাকা কাটা
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$product['price'], $user_id]);
        
        // ২. অর্ডার সেভ করা (ঠিকানা সহ)
        $sql = "INSERT INTO product_orders (user_id, product_id, price, delivery_name, delivery_phone, delivery_address, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')";
        $pdo->prepare($sql)->execute([$user_id, $product_id, $product['price'], $name, $phone, $address]);
        
        // ৩. অ্যাডমিনকে জানানো (অপশনাল) - বা ইউজারকে সাকসেস পেজে পাঠানো
        echo "<script>alert('Order Placed Successfully! We will deliver soon.'); window.location='shop.php';</script>";
    } else {
        $error = "Insufficient Balance!";
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">Confirm Order</h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <img src="../assets/images/products/<?php echo $product['image']; ?>" width="100" class="rounded">
                    <h5 class="mt-2"><?php echo $product['title']; ?></h5>
                    <h4 class="text-danger fw-bold"><?php echo CURRENCY . $product['price']; ?></h4>
                </div>

                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Your Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Receiver Name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone" class="form-control" placeholder="017xxxxxxxx" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Delivery Address</label>
                        <textarea name="address" class="form-control" rows="3" placeholder="Full Address (Village, Thana, District)" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-dark w-100">Pay & Confirm Order</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>