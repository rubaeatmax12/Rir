<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// মেসেজ পাঠানোর লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['message'])) {
    $msg = $_POST['message'];
    $sql = "INSERT INTO support_messages (user_id, sender, message) VALUES (?, 'user', ?)";
    $pdo->prepare($sql)->execute([$user_id, $msg]);
    header("Location: support.php"); // পেজ রিফ্রেশ
    exit;
}

// চ্যাট হিস্ট্রি আনা
$stmt = $pdo->prepare("SELECT * FROM support_messages WHERE user_id = ? ORDER BY id ASC");
$stmt->execute([$user_id]);
$chats = $stmt->fetchAll();

require '../common/header.php';
?>

<style>
    .chat-box { height: 400px; overflow-y: scroll; background: #f1f2f6; padding: 15px; border-radius: 10px; }
    .msg { padding: 10px 15px; margin-bottom: 10px; border-radius: 20px; max-width: 75%; font-size: 14px; }
    .msg-user { background: #007bff; color: white; margin-left: auto; text-align: right; border-bottom-right-radius: 0; }
    .msg-admin { background: #e4e6eb; color: black; margin-right: auto; border-bottom-left-radius: 0; }
    .time { font-size: 10px; opacity: 0.7; display: block; margin-top: 5px; }
</style>

<div class="card shadow-sm border-0">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0"><i class="fas fa-headset"></i> Live Support</h5>
    </div>
    <div class="card-body">
        <!-- চ্যাট বক্স -->
        <div class="chat-box mb-3" id="chatContainer">
            <?php foreach($chats as $c): ?>
                <div class="msg <?php echo $c['sender'] == 'user' ? 'msg-user' : 'msg-admin'; ?>">
                    <?php echo htmlspecialchars($c['message']); ?>
                    <span class="time"><?php echo date('h:i A', strtotime($c['created_at'])); ?></span>
                </div>
            <?php endforeach; ?>
            <?php if(count($chats) == 0): ?>
                <p class="text-center text-muted mt-5">Start a conversation with Admin...</p>
            <?php endif; ?>
        </div>

        <!-- মেসেজ সেন্ড ফর্ম -->
        <form method="POST" class="d-flex gap-2">
            <input type="text" name="message" class="form-control rounded-pill" placeholder="Type your message..." required autocomplete="off">
            <button type="submit" class="btn btn-primary rounded-circle"><i class="fas fa-paper-plane"></i></button>
        </form>
    </div>
</div>

<script>
    // অটোমেটিক নিচে স্ক্রল করার জন্য
    var objDiv = document.getElementById("chatContainer");
    objDiv.scrollTop = objDiv.scrollHeight;
</script>

<?php require '../common/footer.php'; ?>