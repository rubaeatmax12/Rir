<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ইউজারের কেনা প্রোডাক্ট লিস্ট
$sql = "SELECT p.*, o.created_at as buy_date 
        FROM product_orders o 
        JOIN digital_products p ON o.product_id = p.id 
        WHERE o.user_id = ? ORDER BY o.id DESC";
$downloads = $pdo->prepare($sql);
$downloads->execute([$user_id]);
$items = $downloads->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-download"></i> My Library</h3>
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <ul class="list-group list-group-flush">
            <?php if(count($items) > 0): ?>
                <?php foreach($items as $item): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <img src="../assets/images/products/<?php echo $item['image']; ?>" width="50" class="rounded me-3">
                        <div>
                            <h6 class="mb-0 fw-bold"><?php echo $item['title']; ?></h6>
                            <small class="text-muted">Bought: <?php echo date('d M', strtotime($item['buy_date'])); ?></small>
                        </div>
                    </div>
                    <a href="../assets/files/<?php echo $item['file_path']; ?>" class="btn btn-success btn-sm" download>
                        <i class="fas fa-download"></i>
                    </a>
                </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="list-group-item text-center py-5 text-muted">
                    <i class="fas fa-shopping-cart fa-3x mb-3"></i><br>
                    You haven't bought anything yet.
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<div class="text-center mt-3">
    <a href="shop.php" class="btn btn-outline-primary">Go to Shop</a>
</div>

<?php require '../common/footer.php'; ?>