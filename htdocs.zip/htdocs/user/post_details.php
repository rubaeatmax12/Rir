<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$pid = $_GET['id'];
$user_id = $_SESSION['user_id'];

// কমেন্ট সাবমিট
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cmt = $_POST['comment'];
    $pdo->prepare("INSERT INTO social_comments (user_id, post_id, comment) VALUES (?, ?, ?)")->execute([$user_id, $pid, $cmt]);
}

// পোস্ট এবং কমেন্ট আনা
$post = $pdo->query("SELECT * FROM social_posts WHERE id = $pid")->fetch();
$comments = $pdo->query("SELECT c.*, u.username FROM social_comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = $pid ORDER BY c.id DESC")->fetchAll();

require '../common/header.php';
?>

<div class="card mb-3">
    <div class="card-body">
        <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
        <?php if($post['image']) echo '<img src="../assets/images/posts/'.$post['image'].'" class="img-fluid rounded">'; ?>
    </div>
</div>

<h5>Comments</h5>
<form method="POST" class="mb-3 d-flex">
    <input type="text" name="comment" class="form-control" placeholder="Write a comment..." required>
    <button class="btn btn-primary ms-2"><i class="fas fa-paper-plane"></i></button>
</form>

<ul class="list-group">
    <?php foreach($comments as $c): ?>
    <li class="list-group-item">
        <strong><?php echo $c['username']; ?>:</strong> <?php echo htmlspecialchars($c['comment']); ?>
    </li>
    <?php endforeach; ?>
</ul>

<?php require '../common/footer.php'; ?>