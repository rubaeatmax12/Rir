<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

// সব নোটিশ আনা (নতুন আগে)
$notices = $pdo->query("SELECT * FROM app_notices ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<div class="d-flex align-items-center mb-4">
    <a href="../dashboard.php" class="text-dark me-3"><i class="fas fa-arrow-left fa-lg"></i></a>
    <h3 class="m-0 text-primary"><i class="fas fa-bell"></i> Important Notices</h3>
</div>

<div class="row">
    <div class="col-md-8 mx-auto">
        
        <?php if(count($notices) > 0): ?>
            <?php foreach($notices as $n): ?>
            <div class="card shadow-sm border-0 mb-3" style="border-left: 5px solid #001e6c !important;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h5 class="card-title fw-bold text-dark m-0">
                            <i class="fas fa-info-circle text-warning me-1"></i> 
                            <?php echo htmlspecialchars($n['title']); ?>
                        </h5>
                        <small class="text-muted" style="font-size: 11px;">
                            <?php echo date('d M, Y', strtotime($n['created_at'])); ?>
                        </small>
                    </div>
                    <p class="card-text text-secondary">
                        <?php echo nl2br(htmlspecialchars($n['message'])); ?>
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No notices available right now.</h5>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php require '../common/footer.php'; ?>