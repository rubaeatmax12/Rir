<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ১. জব ডিলিট এবং রিফান্ড লজিক (Delete Job) 🔥
if (isset($_GET['delete_job'])) {
    $jid = $_GET['delete_job'];

    // জবটি এই ইউজারের কিনা চেক করা
    $stmt = $pdo->prepare("SELECT * FROM user_jobs WHERE id = ? AND user_id = ?");
    $stmt->execute([$jid, $user_id]);
    $job_info = $stmt->fetch();

    if ($job_info) {
        $refund_amount = $job_info['total_cost'];

        // ট্রানজেকশন শুরু (টাকা ফেরত + ডিলিট)
        $pdo->beginTransaction();
        try {
            // ১. টাকা ফেরত দেওয়া
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$refund_amount, $user_id]);
            
            // ২. জবের প্রুফগুলো ডিলিট করা
            $pdo->prepare("DELETE FROM job_proofs WHERE job_id = ?")->execute([$jid]);
            
            // ৩. মেইন জব ডিলিট করা
            $pdo->prepare("DELETE FROM user_jobs WHERE id = ?")->execute([$jid]);

            $pdo->commit();
            echo "<script>alert('Job Deleted! " . CURRENCY . "$refund_amount Refunded to your balance.'); window.location='manage_jobs.php';</script>";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "<script>alert('Error deleting job.');</script>";
        }
    }
}

// ২. ওয়ার্কারের কাজ অ্যাপ্রুভ লজিক (Approve Proof)
if (isset($_GET['approve'])) {
    $pid = $_GET['approve'];
    $stmt = $pdo->prepare("SELECT * FROM job_proofs WHERE id = ?");
    $stmt->execute([$pid]);
    $proof = $stmt->fetch();
    
    // জব ইনফো (রেট জানার জন্য)
    $job = $pdo->query("SELECT rate FROM user_jobs WHERE id = ".$proof['job_id'])->fetch();

    if ($proof['status'] == 'pending') {
        // স্ট্যাটাস আপডেট
        $pdo->prepare("UPDATE job_proofs SET status = 'approved' WHERE id = ?")->execute([$pid]);
        // ওয়ার্কারকে টাকা দেওয়া
        $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$job['rate'], $proof['worker_id']]);
        
        echo "<script>alert('Work Approved & Paid!'); window.location='manage_jobs.php';</script>";
    }
}

// ৩. রিজেক্ট লজিক (Reject Proof)
if (isset($_GET['reject'])) {
    $pid = $_GET['reject'];
    $pdo->prepare("UPDATE job_proofs SET status = 'rejected' WHERE id = ?")->execute([$pid]);
    echo "<script>alert('Work Rejected!'); window.location='manage_jobs.php';</script>";
}

require '../common/header.php';
?>

<!-- পিলস নেভিগেশন (ট্যাব) -->
<ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
    <li class="nav-item">
        <button class="nav-link active" id="pills-review-tab" data-bs-toggle="pill" data-bs-target="#pills-review">Review Works</button>
    </li>
    <li class="nav-item">
        <button class="nav-link" id="pills-myjobs-tab" data-bs-toggle="pill" data-bs-target="#pills-myjobs">My Posted Jobs</button>
    </li>
</ul>

<div class="tab-content" id="pills-tabContent">

    <!-- ১. ওয়ার্কারদের কাজ চেক করা -->
    <div class="tab-pane fade show active" id="pills-review">
        <h5 class="text-center text-primary mb-3">Pending Proofs</h5>
        
        <?php
        $sql = "SELECT p.*, j.title, j.rate, u.username as worker 
                FROM job_proofs p 
                JOIN user_jobs j ON p.job_id = j.id 
                JOIN users u ON p.worker_id = u.id 
                WHERE j.user_id = ? AND p.status = 'pending'";
        $proofs = $pdo->prepare($sql);
        $proofs->execute([$user_id]);
        $list = $proofs->fetchAll();
        ?>

        <div class="row g-3">
            <?php foreach($list as $p): ?>
            <div class="col-12">
                <div class="card shadow-sm border-warning">
                    <div class="card-body">
                        <h6>Job: <strong><?php echo $p['title']; ?></strong></h6>
                        <p class="mb-1">Worker: <span class="badge bg-dark"><?php echo $p['worker']; ?></span></p>
                        <div class="bg-light p-2 mb-2 rounded border">
                            <small>Proof:</small><br>
                            <?php echo nl2br(htmlspecialchars($p['proof_text'])); ?>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <a href="?approve=<?php echo $p['id']; ?>" class="btn btn-success btn-sm flex-fill" onclick="return confirm('Approve and Pay <?php echo CURRENCY.$p['rate']; ?>?')">Approve</a>
                            <a href="?reject=<?php echo $p['id']; ?>" class="btn btn-danger btn-sm flex-fill" onclick="return confirm('Reject this work?')">Reject</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <?php if(empty($list)) echo "<p class='text-center text-muted'>No pending works to review.</p>"; ?>
        </div>
    </div>

    <!-- ২. আমার পোস্ট করা জব লিস্ট (ডিলিট বাটন সহ) -->
    <div class="tab-pane fade" id="pills-myjobs">
        <h5 class="text-center text-danger mb-3">Manage My Jobs</h5>
        
        <?php
        $my_jobs = $pdo->prepare("SELECT * FROM user_jobs WHERE user_id = ? ORDER BY id DESC");
        $my_jobs->execute([$user_id]);
        $all_jobs = $my_jobs->fetchAll();
        ?>

        <div class="row g-3">
            <?php foreach($all_jobs as $job): ?>
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($job['title']); ?></h6>
                            <span class="badge bg-primary"><?php echo CURRENCY . $job['total_cost']; ?></span>
                        </div>
                        <small class="text-muted">
                            Quantity: <?php echo $job['quantity']; ?> | Rate: <?php echo $job['rate']; ?> | Status: <?php echo ucfirst($job['status']); ?>
                        </small>
                        <hr class="my-2">
                        <a href="?delete_job=<?php echo $job['id']; ?>" class="btn btn-sm btn-outline-danger w-100" onclick="return confirm('Delete this job? Money will be refunded.')">
                            <i class="fas fa-trash-alt"></i> Delete Job & Refund
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if(empty($all_jobs)) echo "<p class='text-center text-muted'>You haven't posted any jobs.</p>"; ?>
        </div>
    </div>

</div>

<div class="text-center mt-4">
    <a href="post_job.php" class="btn btn-primary rounded-pill px-4">Post New Job <i class="fas fa-plus"></i></a>
</div>

<?php require '../common/footer.php'; ?>