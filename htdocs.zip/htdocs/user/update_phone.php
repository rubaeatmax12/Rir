<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// যদি ফোন নম্বর অলরেডি থাকে, তবে ড্যাশবোর্ডে পাঠিয়ে দেবে
$stmt = $pdo->prepare("SELECT phone FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!empty($user['phone'])) {
    header("Location: ../dashboard.php");
    exit;
}

// ফোন নম্বর সেভ করার লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $phone = trim($_POST['phone']);
    
    // চেক করা এই নম্বর অন্য কেউ নিয়েছে কিনা
    $chk = $pdo->prepare("SELECT id FROM users WHERE phone = ?");
    $chk->execute([$phone]);
    
    if ($chk->rowCount() > 0) {
        $error = "This phone number is already used!";
    } else {
        $upd = $pdo->prepare("UPDATE users SET phone = ? WHERE id = ?");
        if ($upd->execute([$phone, $user_id])) {
            echo "<script>alert('Phone Number Updated! You can now access dashboard.'); window.location.href='../dashboard.php';</script>";
            exit;
        } else {
            $error = "Update failed!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Phone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="height: 100vh;">

<div class="card shadow p-4" style="max-width: 400px; width: 100%;">
    <div class="text-center">
        <h3 class="text-danger fw-bold">⚠️ Security Alert</h3>
        <p class="text-muted">আপনার অ্যাকাউন্টে ফোন নম্বর সেট করা নেই। নিরাপত্তার জন্য দয়া করে ফোন নম্বরটি যুক্ত করুন।</p>
    </div>
    
    <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="fw-bold">Mobile Number</label>
            <input type="number" name="phone" class="form-control" placeholder="017xxxxxxxx" required>
        </div>
        <button type="submit" class="btn btn-danger w-100">Save & Continue</button>
    </form>
</div>

</body>
</html>