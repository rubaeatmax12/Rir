<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $phone = $_POST['phone'];
    $operator = $_POST['operator'];
    $amount = $_POST['amount'];
    $pin = $_POST['pin']; // পিন শুধু শো অফ এর জন্য

    // ব্যালেন্স চেক
    $u = $pdo->query("SELECT balance FROM users WHERE id = $user_id")->fetch();

    if ($u['balance'] >= $amount) {
        // ১. টাকা কাটা
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user_id]);
        
        // ২. হিস্ট্রি সেভ (অটো সাকসেস)
        $sql = "INSERT INTO recharge_history (user_id, phone, operator, amount, status) VALUES (?, ?, ?, ?, 'success')";
        $pdo->prepare($sql)->execute([$user_id, $phone, $operator, $amount]);

        echo "<script>alert('Recharge Successful! Check your phone.'); window.location='mobile_recharge.php';</script>";
    } else {
        $error = "Insufficient Balance!";
    }
}

require '../common/header.php';
?>

<div class="card shadow-sm border-0">
    <div class="card-header bg-info text-white text-center">
        <h4><i class="fas fa-mobile-alt"></i> Mobile Recharge</h4>
    </div>
    <div class="card-body">
        <?php if(isset($error)) showAlert($error, 'danger'); ?>
        
        <form method="POST">
            <div class="mb-3">
                <label>Phone Number</label>
                <input type="text" name="phone" class="form-control" placeholder="017xxxxxxxx" required>
            </div>
            <div class="mb-3">
                <label>Operator</label>
                <select name="operator" class="form-select">
                    <option>Grameenphone</option>
                    <option>Banglalink</option>
                    <option>Robi</option>
                    <option>Airtel</option>
                    <option>Teletalk</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Amount (10 - 1000 Tk)</label>
                <input type="number" name="amount" class="form-control" min="10" max="1000" required>
            </div>
            <div class="mb-3">
                <label>PIN (For Security)</label>
                <input type="password" name="pin" class="form-control" placeholder="****" required>
            </div>
            <button type="submit" class="btn btn-info w-100 text-white fw-bold">Recharge Now</button>
        </form>
    </div>
</div>

<?php require '../common/footer.php'; ?>