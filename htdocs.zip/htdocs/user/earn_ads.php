<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');

// অ্যাড দেখা শেষ হলে টাকা জমা করা (AJAX Request)
if (isset($_GET['claim_id'])) {
    $aid = $_GET['claim_id'];
    
    // চেক করা অ্যাডটি আজ দেখা হয়েছে কিনা
    $chk = $pdo->prepare("SELECT id FROM ptc_views WHERE user_id = ? AND ad_id = ? AND viewed_at = ?");
    $chk->execute([$user_id, $aid, $today]);

    if ($chk->rowCount() == 0) {
        $ad = $pdo->query("SELECT reward FROM ptc_ads WHERE id = $aid")->fetch();
        if ($ad) {
            // টাকা দেওয়া
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$ad['reward'], $user_id]);
            // ভিউ লিস্টে যোগ করা
            $pdo->prepare("INSERT INTO ptc_views (user_id, ad_id, viewed_at) VALUES (?, ?, ?)")->execute([$user_id, $aid, $today]);
            echo "success";
        }
    } else {
        echo "already_viewed";
    }
    exit;
}

// যেসব অ্যাড আজ দেখা হয়নি সেগুলো আনা
$sql = "SELECT * FROM ptc_ads WHERE status = 'active' 
        AND id NOT IN (SELECT ad_id FROM ptc_views WHERE user_id = $user_id AND viewed_at = '$today')";
$ads = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center text-primary mb-4"><i class="fas fa-eye"></i> Watch & Earn</h3>

<div class="row g-3">
    <?php foreach($ads as $ad): ?>
    <div class="col-12">
        <div class="card shadow-sm border-start border-5 border-primary">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="fw-bold mb-1"><?php echo $ad['title']; ?></h5>
                    <span class="badge bg-success">+<?php echo $ad['reward']; ?> Tk</span>
                    <span class="badge bg-secondary"><i class="fas fa-clock"></i> <?php echo $ad['timer']; ?>s</span>
                </div>
                <button onclick="viewAd(<?php echo $ad['id']; ?>, '<?php echo $ad['ad_link']; ?>', <?php echo $ad['timer']; ?>)" class="btn btn-primary btn-sm px-3">
                    View Ad
                </button>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if(empty($ads)) echo "<div class='alert alert-warning text-center'>No ads available today! Come back tomorrow.</div>"; ?>
</div>

<!-- টাইমার মডাল (Popup) -->
<div class="modal fade" id="timerModal" data-bs-backdrop="static" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center p-4">
            <h4>Watching Ad...</h4>
            <div class="spinner-border text-primary my-3" role="status"></div>
            <h2 id="countdown" class="fw-bold text-danger">0</h2>
            <p>Please wait on the ad page...</p>
        </div>
    </div>
</div>

<script>
function viewAd(id, link, time) {
    // ১. অ্যাড লিংক নতুন ট্যাবে ওপেন করা
    window.open(link, '_blank');
    
    // ২. মডাল দেখানো এবং টাইমার চালু করা
    var modal = new bootstrap.Modal(document.getElementById('timerModal'));
    modal.show();
    
    var counter = time;
    document.getElementById('countdown').innerText = counter;

    var interval = setInterval(function() {
        counter--;
        document.getElementById('countdown').innerText = counter;
        
        if (counter <= 0) {
            clearInterval(interval);
            // ৩. সার্ভারে রিকোয়েস্ট পাঠানো (টাকা জমার জন্য)
            fetch('earn_ads.php?claim_id=' + id)
                .then(response => response.text())
                .then(data => {
                    modal.hide();
                    if(data.trim() == 'success') {
                        alert("Congratulations! Money Added.");
                        location.reload();
                    } else {
                        alert("Error or Already Viewed.");
                    }
                });
        }
    }, 1000);
}
</script>

<?php require '../common/footer.php'; ?>