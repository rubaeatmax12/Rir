<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$amount = $_GET['amount'] ?? 0;
$win_amount = $amount * 1.8; // ১.৮ গুণ লাভ

// ব্যালেন্স চেক
$balance = getUserBalance($pdo, $user_id);
if($balance < $amount) {
    echo "<script>alert('Insufficient Balance!'); window.location='ludo.php';</script>";
    exit;
}

require '../common/header.php';
?>

<style>
    .dice-box { width: 100px; height: 100px; background: white; border: 2px solid #333; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 40px; font-weight: bold; margin: 0 auto; box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
    .player-area { background: #f8f9fa; padding: 20px; border-radius: 15px; margin-bottom: 20px; text-align: center; }
    .winner { background: #d4edda; border: 2px solid green; }
    .loser { background: #f8d7da; border: 2px solid red; }
</style>

<div class="text-center mt-3">
    <h3>🎲 Ludo Dice Match</h3>
    <p>Entry: <?php echo CURRENCY . $amount; ?> | Win: <?php echo CURRENCY . $win_amount; ?></p>
</div>

<!-- কম্পিউটার এরিয়া -->
<div class="player-area" id="compArea">
    <h5>🤖 Computer</h5>
    <div class="dice-box text-danger" id="compDice">?</div>
</div>

<!-- ইউজার এরিয়া -->
<div class="player-area" id="userArea">
    <h5>👤 You</h5>
    <div class="dice-box text-primary" id="userDice">?</div>
    <button id="rollBtn" class="btn btn-primary mt-3 btn-lg w-100">ROLL DICE 🎲</button>
</div>

<div id="resultMsg" class="text-center mt-3 fw-bold fs-4"></div>
<div class="text-center mt-3" id="backBtn" style="display:none;">
    <a href="ludo.php" class="btn btn-dark">Play Again</a>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $('#rollBtn').click(function(){
        $(this).prop('disabled', true).text('Rolling...');
        
        // ১. অ্যানিমেশন (রোলিং ইফেক্ট)
        let count = 0;
        let interval = setInterval(function(){
            $('#userDice').text(Math.floor(Math.random() * 6) + 1);
            $('#compDice').text(Math.floor(Math.random() * 6) + 1);
            count++;
            if(count > 10) {
                clearInterval(interval);
                processGame();
            }
        }, 100);
    });

    function processGame() {
        $.ajax({
            url: '../api/ludo_api.php',
            type: 'POST',
            data: { amount: <?php echo $amount; ?> },
            success: function(response) {
                let data = JSON.parse(response);
                
                $('#userDice').text(data.user_score);
                $('#compDice').text(data.comp_score);
                $('#resultMsg').text(data.msg);
                
                if(data.status == 'win') {
                    $('#userArea').addClass('winner');
                    $('#resultMsg').addClass('text-success');
                } else {
                    $('#userArea').addClass('loser');
                    $('#resultMsg').addClass('text-danger');
                }
                
                $('#backBtn').show();
            }
        });
    }
});
</script>

<?php require '../common/footer.php'; ?>