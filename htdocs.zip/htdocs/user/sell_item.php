<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// পণ্য আপলোড লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $desc = $_POST['description'];

    // ছবি আপলোড
    $img_name = time() . "_" . $_FILES['image']['name'];
    $target = "../assets/images/products/" . $img_name;

    // ফোল্ডার না থাকলে তৈরি করা
    if (!is_dir('../assets/images/products')) mkdir('../assets/images/products', 0777, true);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        // ডাটাবেসে সেভ (স্ট্যাটাস পেন্ডিং থাকবে)
        $sql = "INSERT INTO digital_products (user_id, title, description, price, image, file_path, status) VALUES (?, ?, ?, ?, ?, 'no_file', 'pending')";
        $pdo->prepare($sql)->execute([$user_id, $title, $desc, $price, $img_name]);
        
        $success = "Product uploaded! Wait for Admin approval.";
    } else {
        $error = "Image upload failed!";
    }
}

// ইউজারের আপলোড করা পণ্যের লিস্ট
$stmt = $pdo->prepare("SELECT * FROM digital_products WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$my_products = $stmt->fetchAll();

require '../common/header.php';
?>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-warning text-dark text-center">
        <h5 class="mb-0"><i class="fas fa-camera"></i> Sell Your Product</h5>
    </div>
    <div class="card-body">
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Product Name</label>
                <input type="text" name="title" class="form-control" placeholder="Ex: T-Shirt, Watch" required>
            </div>
            <div class="mb-3">
                <label>Price (<?php echo CURRENCY; ?>)</label>
                <input type="number" name="price" class="form-control" placeholder="Ex: 500" required>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="2" placeholder="Details..."></textarea>
            </div>
            <div class="mb-3">
                <label>Product Image</label>
                <input type="file" name="image" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-dark w-100">Upload Product</button>
        </form>
    </div>
</div>

<h5 class="text-center mb-3">My Uploaded Products</h5>
<div class="row g-2">
    <?php foreach($my_products as $p): ?>
    <div class="col-6">
        <div class="card h-100 shadow-sm border-0">
            <img src="../assets/images/products/<?php echo $p['image']; ?>" class="card-img-top" style="height: 100px; object-fit: cover;">
            <div class="card-body p-2 text-center">
                <small class="fw-bold d-block text-truncate"><?php echo htmlspecialchars($p['title']); ?></small>
                <span class="text-danger fw-bold"><?php echo CURRENCY . $p['price']; ?></span>
                <br>
                <?php if($p['status'] == 'approved'): ?>
                    <span class="badge bg-success" style="font-size: 10px;">Live in Shop</span>
                <?php elseif($p['status'] == 'rejected'): ?>
                    <span class="badge bg-danger" style="font-size: 10px;">Rejected</span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark" style="font-size: 10px;">Pending</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>