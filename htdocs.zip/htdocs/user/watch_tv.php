<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$id = $_GET['id'];
$ch = $pdo->query("SELECT * FROM tv_channels WHERE id = $id")->fetch();

if(!$ch) die("Channel not found");

// লিংক চেক করা (ইউটিউব নাকি m3u8)
$is_youtube = strpos($ch['stream_url'], 'youtube') !== false || strpos($ch['stream_url'], 'youtu.be') !== false;

require '../common/header.php';
?>

<!-- HLS Player (টিভির জন্য) -->
<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>

<div class="card shadow border-0 bg-black">
    <div class="card-body p-0 position-relative">
        
        <?php if ($is_youtube): ?>
            <!-- ইউটিউব প্লেয়ার -->
            <div class="ratio ratio-16x9">
                <iframe src="<?php echo $ch['stream_url']; ?>" title="Live TV" allowfullscreen allow="autoplay"></iframe>
            </div>
        <?php else: ?>
            <!-- রিয়েল আইপি টিভি প্লেয়ার -->
            <video id="video" controls autoplay style="width: 100%; height: auto; border-radius: 5px;"></video>
        <?php endif; ?>

    </div>
    <div class="card-footer bg-dark text-white d-flex align-items-center">
        <!-- লোগো লোড না হলে ডিফল্ট আইকন দেখাবে -->
        <img src="<?php echo $ch['logo']; ?>" width="50" class="rounded me-3 bg-white p-1" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3163/3163478.png'">
        <div>
            <h5 class="mb-0 fw-bold"><?php echo $ch['name']; ?></h5>
            <small class="text-danger">● Live Streaming</small>
        </div>
    </div>
</div>

<div class="text-center mt-4">
    <a href="live_tv.php" class="btn btn-outline-primary w-100 rounded-pill">
        <i class="fas fa-list"></i> All Channels
    </a>
</div>

<?php if (!$is_youtube): ?>
<script>
    var video = document.getElementById('video');
    var videoSrc = '<?php echo $ch['stream_url']; ?>';

    if (Hls.isSupported()) {
        var hls = new Hls();
        hls.loadSource(videoSrc);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, function() {
            video.play();
        });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = videoSrc;
        video.addEventListener('loadedmetadata', function() {
            video.play();
        });
    }
</script>
<?php endif; ?>

<?php require '../common/footer.php'; ?>