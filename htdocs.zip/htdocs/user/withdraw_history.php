<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ইউজারের উইথড্র হিস্ট্রি বের করা
$sql = "SELECT * FROM withdrawals WHERE user_id = ? ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$history = $stmt->fetchAll();

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-history"></i> Withdrawal History</h5>
                <a href="../withdraw.php" class="btn btn-light btn-sm text-danger fw-bold">Request New</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Date</th>
                                <th>Method</th>
                                <th>Account</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($history) > 0): ?>
                                <?php foreach($history as $h): ?>
                                <tr>
                                    <td><?php echo date('d M, h:i A', strtotime($h['created_at'])); ?></td>
                                    <td><?php echo ucfirst($h['method']); ?></td>
                                    <td><?php echo $h['account_number']; ?></td>
                                    <td class="fw-bold text-danger"><?php echo CURRENCY . $h['amount']; ?></td>
                                    <td>
                                        <?php 
                                            if($h['status'] == 'approved') {
                                                echo '<span class="badge bg-success">Paid</span>';
                                            } elseif($h['status'] == 'rejected') {
                                                echo '<span class="badge bg-danger">Rejected</span>';
                                            } else {
                                                echo '<span class="badge bg-warning text-dark">Pending</span>';
                                            }
                                        ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">
                                        You haven't made any withdrawal requests yet.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>