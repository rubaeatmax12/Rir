<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

function getYoutubeId($url) {
    preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match);
    return isset($match[1]) ? $match[1] : null;
}

$videos = $pdo->query("SELECT * FROM tutorial_videos ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<div class="d-flex align-items-center mb-4">
    <a href="../dashboard.php" class="text-dark me-3"><i class="fas fa-arrow-left fa-lg"></i></a>
    <h3 class="m-0 text-danger fw-bold"><i class="fab fa-youtube"></i> Work Tutorials</h3>
</div>

<div class="row g-3">
    <?php foreach($videos as $v): 
        $vid_id = getYoutubeId($v['video_link']);
    ?>
    <div class="col-12">
        <div class="card shadow-sm border-0 overflow-hidden">
            <div class="ratio ratio-16x9">
                <iframe src="https://www.youtube.com/embed/<?php echo $vid_id; ?>" title="YouTube video" allowfullscreen></iframe>
            </div>
            <div class="card-body p-3">
                <h6 class="fw-bold mb-0 text-dark"><?php echo htmlspecialchars($v['title']); ?></h6>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if(empty($videos)) echo "<div class='col-12 text-center py-5 text-muted'>No tutorials added yet.</div>"; ?>
</div>

<?php require '../common/footer.php'; ?>