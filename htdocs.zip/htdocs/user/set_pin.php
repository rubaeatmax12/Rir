<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$user = $pdo->query("SELECT security_pin FROM users WHERE id = $user_id")->fetch();

// যদি পিন আগে থেকেই সেট করা থাকে
if ($user['security_pin'] != NULL) {
    echo "<script>alert('PIN already set! Contact admin to reset.'); window.location='../dashboard.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pin = $_POST['pin'];
    $c_pin = $_POST['c_pin'];

    if (strlen($pin) != 4) {
        $error = "PIN must be 4 digits!";
    } elseif ($pin !== $c_pin) {
        $error = "PINs do not match!";
    } else {
        // পিন সেভ করা
        $pdo->prepare("UPDATE users SET security_pin = ? WHERE id = ?")->execute([$pin, $user_id]);
        echo "<script>alert('Security PIN Set Successfully!'); window.location='../dashboard.php';</script>";
        exit;
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white text-center">
                <h4><i class="fas fa-key"></i> Set Security PIN</h4>
            </div>
            <div class="card-body">
                <p class="text-danger small text-center">Note: Remember this PIN! It is required for withdrawal & transfer.</p>
                
                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <form method="POST">
                    <div class="mb-3">
                        <label>New 4-Digit PIN</label>
                        <input type="number" name="pin" class="form-control text-center fs-4" placeholder="XXXX" required>
                    </div>
                    <div class="mb-3">
                        <label>Confirm PIN</label>
                        <input type="number" name="c_pin" class="form-control text-center fs-4" placeholder="XXXX" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Set PIN</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>