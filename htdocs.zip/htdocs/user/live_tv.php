<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$channels = $pdo->query("SELECT * FROM tv_channels WHERE status='active'")->fetchAll();
require '../common/header.php';
?>

<h3 class="text-center text-danger mb-4"><i class="fas fa-tv"></i> Live TV Channels</h3>

<div class="row g-3">
    <?php foreach($channels as $ch): ?>
    <div class="col-4 col-md-3">
        <a href="watch_tv.php?id=<?php echo $ch['id']; ?>" class="text-decoration-none text-dark">
            <div class="card shadow-sm border-0 h-100 text-center p-2">
                <img src="../assets/images/tv/<?php echo $ch['logo']; ?>" class="img-fluid rounded mb-2" style="height: 60px; object-fit: contain;">
                <h6 style="font-size: 12px; font-weight: bold;"><?php echo $ch['name']; ?></h6>
            </div>
        </a>
    </div>
    <?php endforeach; ?>
    
    <?php if(empty($channels)) echo "<p class='text-center'>No channels added yet.</p>"; ?>
</div>

<?php require '../common/footer.php'; ?>