<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

// ১. রিয়েল ডিপোজিট হিস্ট্রি (শেষ ২০টি)
$stmt = $pdo->query("SELECT u.username, d.amount, d.created_at 
                     FROM deposits d 
                     JOIN users u ON d.user_id = u.id 
                     WHERE d.status = 'approved' 
                     ORDER BY d.id DESC LIMIT 20");
$real_deposits = $stmt->fetchAll();

// ২. রিয়েল উইথড্র হিস্ট্রি (শেষ ২০টি)
$stmt = $pdo->query("SELECT u.username, w.amount, w.created_at 
                     FROM withdrawals w 
                     JOIN users u ON w.user_id = u.id 
                     WHERE w.status = 'approved' 
                     ORDER BY w.id DESC LIMIT 20");
$real_withdrawals = $stmt->fetchAll();

require '../common/header.php';
?>

<!-- ফেক নোটিফিকেশন পপ-আপ স্টাইল -->
<style>
    .live-toast {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.8);
        color: #fff;
        padding: 10px 20px;
        border-radius: 30px;
        font-size: 14px;
        z-index: 9999;
        display: none; /* শুরুতে লুকানো থাকবে */
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        min-width: 280px;
        text-align: center;
    }
    .nav-tabs .nav-link.active {
        background-color: #0d6efd;
        color: white;
        border-color: #0d6efd;
    }
    .nav-tabs .nav-link {
        color: #495057;
        font-weight: bold;
    }
</style>

<!-- ফেক পপ-আপ এলিমেন্ট -->
<div id="liveToast" class="live-toast">
    <i class="fas fa-check-circle text-success"></i> <span id="toastMsg">Loading...</span>
</div>

<h3 class="text-center mb-4 text-primary"><i class="fas fa-rss"></i> Live Transactions</h3>

<!-- ট্যাব বাটন -->
<ul class="nav nav-tabs nav-fill mb-3" id="paymentTab" role="tablist">
    <li class="nav-item">
        <button class="nav-link active" id="deposit-tab" data-bs-toggle="tab" data-bs-target="#deposit" type="button">
            <i class="fas fa-arrow-down"></i> Recent Deposits
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" id="withdraw-tab" data-bs-toggle="tab" data-bs-target="#withdraw" type="button">
            <i class="fas fa-arrow-up"></i> Recent Withdrawals
        </button>
    </li>
</ul>

<!-- ট্যাব কন্টেন্ট -->
<div class="tab-content" id="paymentTabContent">
    
    <!-- ডিপোজিট লিস্ট -->
    <div class="tab-pane fade show active" id="deposit">
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>User</th>
                            <th>Amount</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($real_deposits as $d): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($d['username']); ?></td>
                            <td class="text-success fw-bold">+ <?php echo CURRENCY . $d['amount']; ?></td>
                            <td class="small text-muted"><?php echo date('h:i A, d M', strtotime($d['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($real_deposits)) echo "<tr><td colspan='3' class='text-center p-3'>No deposits yet.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- উইথড্র লিস্ট -->
    <div class="tab-pane fade" id="withdraw">
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>User</th>
                            <th>Amount</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($real_withdrawals as $w): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($w['username']); ?></td>
                            <td class="text-danger fw-bold">- <?php echo CURRENCY . $w['amount']; ?></td>
                            <td class="small text-muted"><?php echo date('h:i A, d M', strtotime($w['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($real_withdrawals)) echo "<tr><td colspan='3' class='text-center p-3'>No withdrawals yet.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- 🔥 ফেক নোটিফিকেশন স্ক্রিপ্ট 🔥 -->
<script>
    // এই নামগুলো ফেক হিসেবে দেখাবে
    const fakeNames = ["Rahim", "Karim", "Suman", "Rina", "Mina", "Tanvir", "Sakib", "Jwel", "Akash", "Nodi"];
    const fakeAmounts = [50, 100, 200, 500, 1000, 150];
    
    function showFakePopup() {
        const name = fakeNames[Math.floor(Math.random() * fakeNames.length)];
        const amount = fakeAmounts[Math.floor(Math.random() * fakeAmounts.length)];
        const type = Math.random() > 0.5 ? "Withdrew" : "Deposited"; // রেন্ডমলি টাইপ সিলেক্ট হবে
        
        // মেসেজ তৈরি
        const msg = `${name} just ${type} ৳${amount} - 1 min ago`;
        
        // পপ-আপ দেখানো
        const toast = document.getElementById("liveToast");
        const toastText = document.getElementById("toastMsg");
        
        toastText.innerText = msg;
        toast.style.display = "block";
        
        // ৩ সেকেন্ড পর লুকিয়ে ফেলা
        setTimeout(() => {
            toast.style.display = "none";
        }, 3000);
    }

    // প্রতি ৫ সেকেন্ড পর পর পপ-আপ আসবে
    setInterval(showFakePopup, 5000);
</script>

<?php require '../common/footer.php'; ?>