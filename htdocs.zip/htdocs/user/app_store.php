<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$apps = $pdo->query("SELECT * FROM app_downloads ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<div class="text-center mb-4">
    <img src="https://cdn-icons-png.flaticon.com/512/300/300218.png" width="60" class="mb-2">
    <h3 class="fw-bold text-primary">App Store</h3>
    <p class="text-muted">Download our official apps</p>
</div>

<div class="row g-3">
    <?php foreach($apps as $app): 
        $link = ($app['link_type'] == 'file') ? "../assets/files/".$app['download_link'] : $app['download_link'];
    ?>
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-body d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <img src="../assets/images/<?php echo $app['icon']; ?>" width="60" height="60" class="rounded-3 me-3" style="object-fit: cover;">
                    <div>
                        <h5 class="mb-0 fw-bold"><?php echo $app['app_name']; ?></h5>
                        <small class="text-muted">Version: <?php echo $app['version']; ?></small>
                        <br>
                        <?php if($app['platform'] == 'Android'): ?>
                            <span class="badge bg-success"><i class="fab fa-android"></i> Android</span>
                        <?php else: ?>
                            <span class="badge bg-dark"><i class="fab fa-apple"></i> iOS</span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <a href="<?php echo $link; ?>" target="_blank" class="btn btn-primary rounded-pill px-4">
                    Download <i class="fas fa-download ms-1"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if(empty($apps)) echo "<div class='text-center py-5 text-muted'>No apps available right now.</div>"; ?>
</div>

<div class="text-center mt-3">
    <a href="../dashboard.php" class="btn btn-outline-dark">Back to Dashboard</a>
</div>

<?php require '../common/footer.php'; ?>