<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $details = $_POST['description'];
    $link = $_POST['link'];
    $qty = $_POST['quantity'];
    $rate = $_POST['rate'];
    
    $total_cost = $qty * $rate; // মোট খরচ

    // ব্যালেন্স চেক
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetchColumn();

    if ($balance >= $total_cost) {
        // ১. টাকা কাটা
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$total_cost, $user_id]);
        
        // ২. জব পোস্ট করা
        $sql = "INSERT INTO user_jobs (user_id, title, description, link, quantity, rate, total_cost) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([$user_id, $title, $details, $link, $qty, $rate, $total_cost]);
        
        $success = "Job Posted Successfully! Cost: " . CURRENCY . $total_cost;
    } else {
        $error = "Insufficient Balance! You need " . CURRENCY . $total_cost;
    }
}

require '../common/header.php';
?>

<div class="card shadow-sm border-0">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0"><i class="fas fa-briefcase"></i> Post a New Job</h5>
    </div>
    <div class="card-body">
        <?php if(isset($success)) showAlert($success, 'success'); ?>
        <?php if(isset($error)) showAlert($error, 'danger'); ?>

        <form method="POST">
            <div class="mb-3">
                <label>Job Title</label>
                <input type="text" name="title" class="form-control" placeholder="Ex: Watch YouTube Video" required>
            </div>
            <div class="mb-3">
                <label>Instructions (কি করতে হবে)</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Ex: Watch full video and subscribe..." required></textarea>
            </div>
            <div class="mb-3">
                <label>Job Link</label>
                <input type="url" name="link" class="form-control" placeholder="https://..." required>
            </div>
            <div class="row">
                <div class="col-6 mb-3">
                    <label>Worker Needed (জন)</label>
                    <input type="number" name="quantity" class="form-control" placeholder="Ex: 50" min="1" required>
                </div>
                <div class="col-6 mb-3">
                    <label>Rate per Job (টাকা)</label>
                    <input type="number" step="0.01" name="rate" class="form-control" placeholder="Ex: 2.00" min="0.50" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Post Job & Pay</button>
        </form>
    </div>
</div>

<div class="text-center mt-3">
    <a href="manage_jobs.php" class="btn btn-outline-dark">Manage My Jobs</a>
</div>

<?php require '../common/footer.php'; ?>