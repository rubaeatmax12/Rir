<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php'; // Session check not strictly needed for public view
require 'common/header.php';

// টপ ১০ ইউজার ব্যালেন্স অনুযায়ী
$sql = "SELECT username, balance FROM users ORDER BY balance DESC LIMIT 10";
$top_users = $pdo->query($sql)->fetchAll();
?>

<div class="container text-center">
    <h2 class="mb-4"><i class="fas fa-trophy text-warning"></i> Top 10 Leaders</h2>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <ul class="list-group">
                <?php foreach($top_users as $index => $u): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>
                        <span class="badge bg-primary rounded-pill me-2"><?php echo $index + 1; ?></span>
                        <?php echo htmlspecialchars($u['username']); ?>
                    </span>
                    <span class="fw-bold text-success"><?php echo CURRENCY . $u['balance']; ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>