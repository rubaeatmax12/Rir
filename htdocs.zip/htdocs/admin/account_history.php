<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// কোন টাইপ দেখব (ডিফল্ট Gmail)
$type = $_GET['type'] ?? 'gmail';

// ১. মোট খরচ এবং মোট সংখ্যা বের করা
$stmt = $pdo->prepare("SELECT SUM(price) as total_cost, COUNT(*) as total_count 
                       FROM account_sales 
                       WHERE type = ? AND status = 'approved'");
$stmt->execute([$type]);
$stats = $stmt->fetch();

$total_cost = $stats['total_cost'] ?? 0;
$total_count = $stats['total_count'] ?? 0;

// ২. লিস্ট বের করা (সব অ্যাপ্রুভ করা অ্যাকাউন্ট)
$stmt = $pdo->prepare("SELECT a.*, u.username 
                       FROM account_sales a 
                       JOIN users u ON a.user_id = u.id 
                       WHERE a.type = ? AND a.status = 'approved' 
                       ORDER BY a.id DESC");
$stmt->execute([$type]);
$accounts = $stmt->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center mb-4 text-secondary"><i class="fas fa-history"></i> Account Purchase History</h3>

<!-- ৩টি বাটন (Tabs) -->
<div class="row g-2 mb-4">
    <div class="col-4">
        <a href="?type=gmail" class="btn w-100 <?php echo $type=='gmail'?'btn-danger':'btn-outline-danger'; ?>">
            <i class="fab fa-google"></i> Gmail
        </a>
    </div>
    <div class="col-4">
        <a href="?type=facebook" class="btn w-100 <?php echo $type=='facebook'?'btn-primary':'btn-outline-primary'; ?>">
            <i class="fab fa-facebook-f"></i> Facebook
        </a>
    </div>
    <div class="col-4">
        <a href="?type=instagram" class="btn w-100 <?php echo $type=='instagram'?'btn-warning':'btn-outline-warning'; ?>">
            <i class="fab fa-instagram"></i> Instagram
        </a>
    </div>
</div>

<!-- হিসাবের বক্স -->
<div class="card shadow-sm border-0 mb-3 bg-light">
    <div class="card-body text-center">
        <h5 class="text-uppercase text-muted">Total <?php echo ucfirst($type); ?> Bought</h5>
        <h2 class="fw-bold text-dark"><?php echo $total_count; ?> Piece</h2>
        <h4 class="text-success">Total Cost: <?php echo CURRENCY . number_format($total_cost, 2); ?></h4>
    </div>
</div>

<!-- লিস্ট টেবিল -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-dark text-white">
        Purchased List (<?php echo ucfirst($type); ?>)
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Seller</th>
                        <th>Email/ID</th>
                        <th>Password</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($accounts) > 0): ?>
                        <?php foreach($accounts as $acc): ?>
                        <tr>
                            <td><small><?php echo date('d M Y', strtotime($acc['created_at'])); ?></small></td>
                            <td><?php echo $acc['username']; ?></td>
                            <td class="fw-bold text-primary"><?php echo $acc['email_or_phone']; ?></td>
                            <td class="text-danger user-select-all"><?php echo $acc['password']; ?></td>
                            <td class="fw-bold text-success"><?php echo $acc['price']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">No <?php echo $type; ?> accounts bought yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>