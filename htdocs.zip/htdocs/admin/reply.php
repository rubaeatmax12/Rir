<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

$user_id = $_GET['uid'];

// ইউজার ইনফো
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$chat_user = $stmt->fetch();

// রিপ্লাই পাঠানো
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['message'])) {
    $msg = $_POST['message'];
    $sql = "INSERT INTO support_messages (user_id, sender, message) VALUES (?, 'admin', ?)";
    $pdo->prepare($sql)->execute([$user_id, $msg]);
    header("Location: reply.php?uid=$user_id");
    exit;
}

// চ্যাট হিস্ট্রি
$stmt = $pdo->prepare("SELECT * FROM support_messages WHERE user_id = ? ORDER BY id ASC");
$stmt->execute([$user_id]);
$chats = $stmt->fetchAll();

require '../common/header.php';
?>

<style>
    .chat-box { height: 450px; overflow-y: scroll; background: #e5ddd5; padding: 15px; border: 1px solid #ddd; }
    .msg { padding: 8px 12px; margin-bottom: 8px; border-radius: 10px; max-width: 70%; font-size: 14px; clear: both; }
    .msg-user { background: white; color: black; float: left; border: 1px solid #ccc; }
    .msg-admin { background: #dcf8c6; color: black; float: right; border: 1px solid #bcdec6; }
    .clearfix::after { content: ""; clear: both; display: table; }
</style>

<div class="card shadow-sm">
    <div class="card-header bg-success text-white">
        Chat with: <strong><?php echo $chat_user['username']; ?></strong>
        <a href="support.php" class="btn btn-sm btn-light float-end">Back</a>
    </div>
    <div class="card-body p-0">
        <div class="chat-box" id="chatContainer">
            <?php foreach($chats as $c): ?>
                <div class="clearfix">
                    <div class="msg <?php echo $c['sender'] == 'admin' ? 'msg-admin' : 'msg-user'; ?>">
                        <?php echo htmlspecialchars($c['message']); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <form method="POST" class="p-2 bg-light border-top d-flex gap-2">
            <input type="text" name="message" class="form-control" placeholder="Type reply..." required autocomplete="off">
            <button type="submit" class="btn btn-success"><i class="fas fa-paper-plane"></i></button>
        </form>
    </div>
</div>

<script>
    var objDiv = document.getElementById("chatContainer");
    objDiv.scrollTop = objDiv.scrollHeight;
</script>

<?php require '../common/footer.php'; ?>