<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// কোড তৈরি করার লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_code'])) {
    $code = strtoupper(trim($_POST['code'])); // কোড বড় হাতের হবে
    $amount = $_POST['amount'];

    // ৫ থেকে ১৫ টাকার লিমিট চেক
    if ($amount < 5 || $amount > 15) {
        showAlert("Bonus amount must be between 5 to 15 Taka!", "danger");
    } else {
        // ডুপ্লিকেট চেক
        $check = $pdo->prepare("SELECT id FROM promo_codes WHERE code = ?");
        $check->execute([$code]);
        
        if ($check->rowCount() > 0) {
            showAlert("This code already exists!", "warning");
        } else {
            $sql = "INSERT INTO promo_codes (code, amount) VALUES (?, ?)";
            $pdo->prepare($sql)->execute([$code, $amount]);
            showAlert("Promo Code '$code' Created Successfully!");
        }
    }
}

// কোড ডিলিট করা
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM promo_codes WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: promo_codes.php");
}

// সব কোড দেখানো
$codes = $pdo->query("SELECT * FROM promo_codes ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-ticket-alt"></i> Manage Promo Codes</h3>

<div class="row">
    <!-- কোড তৈরির ফর্ম -->
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">Create New Code</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Promo Code Name</label>
                        <input type="text" name="code" class="form-control" placeholder="Ex: EID2025" required>
                    </div>
                    <div class="mb-3">
                        <label>Bonus Amount (5-15 Tk)</label>
                        <input type="number" name="amount" class="form-control" min="5" max="15" placeholder="Ex: 10" required>
                    </div>
                    <button type="submit" name="create_code" class="btn btn-primary w-100">Create Code</button>
                </form>
            </div>
        </div>
    </div>

    <!-- কোড লিস্ট -->
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead class="bg-dark text-white">
                        <tr>
                            <th>Code</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($codes as $c): ?>
                        <tr>
                            <td class="fw-bold text-success"><?php echo $c['code']; ?></td>
                            <td><?php echo CURRENCY . $c['amount']; ?></td>
                            <td><span class="badge bg-success">Active</span></td>
                            <td>
                                <a href="?delete=<?php echo $c['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this code?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>