<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// অ্যাকশন (অ্যাপ্রুভ/রিজেক্ট)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $status = ($_GET['action'] == 'approve') ? 'approved' : 'rejected';
    
    $pdo->prepare("UPDATE digital_products SET status = ? WHERE id = ?")->execute([$status, $id]);
    showAlert("Product status updated to $status!");
}

// পেন্ডিং প্রোডাক্ট লিস্ট
$sql = "SELECT p.*, u.username 
        FROM digital_products p 
        JOIN users u ON p.user_id = u.id 
        WHERE p.status = 'pending' 
        ORDER BY p.id DESC";
$products = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-boxes"></i> User Product Requests</h3>

<div class="row g-3">
    <?php foreach($products as $p): ?>
    <div class="col-md-4">
        <div class="card shadow-sm">
            <img src="../assets/images/products/<?php echo $p['image']; ?>" class="card-img-top" style="height: 150px; object-fit: cover;">
            <div class="card-body">
                <h5><?php echo $p['title']; ?></h5>
                <p class="mb-1">Price: <strong class="text-danger"><?php echo CURRENCY . $p['price']; ?></strong></p>
                <p class="mb-2 text-muted">Seller: <?php echo $p['username']; ?></p>
                <p class="small"><?php echo $p['description']; ?></p>
                
                <div class="d-flex gap-2">
                    <a href="?action=approve&id=<?php echo $p['id']; ?>" class="btn btn-success flex-fill">Approve</a>
                    <a href="?action=reject&id=<?php echo $p['id']; ?>" class="btn btn-danger flex-fill">Reject</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if(empty($products)) echo "<p class='text-center text-muted w-100'>No pending products.</p>"; ?>
</div>

<?php require '../common/footer.php'; ?>