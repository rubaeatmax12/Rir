<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $message = $_POST['message'];

    // 🔥 এক ক্লিকে সব ইউজারকে মেসেজ পাঠানোর জাদুকরী SQL কুয়েরি
    // এটা লুপ চালানোর চেয়ে ১০০ গুণ ফাস্ট কাজ করবে
    $sql = "INSERT INTO notifications (user_id, title, message) 
            SELECT id, ?, ? FROM users";
            
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$title, $message]);
        
        showAlert("Success! Notification sent to ALL users.");
    } catch (Exception $e) {
        showAlert("Error sending notification.", "danger");
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-primary text-white text-center">
                <h4><i class="fas fa-bullhorn"></i> Global Notification</h4>
                <small>Send message to EVERYONE at once</small>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Title</label>
                        <input type="text" name="title" class="form-control" placeholder="Ex: Eid Mubarak / Bonus Offer" required>
                    </div>
                    <div class="mb-3">
                        <label>Message Content</label>
                        <textarea name="message" class="form-control" rows="5" placeholder="Write your announcement here..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100" onclick="return confirm('Are you sure you want to send this to ALL users?')">
                        Send to All Users 🚀
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>