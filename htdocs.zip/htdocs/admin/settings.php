<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ১. সাধারণ সেটিংস
    $site_name = $_POST['site_name'];
    $notice = $_POST['notice'];
    $whatsapp = $_POST['whatsapp']; // এটা সাপোর্ট নাম্বার
    
    // ২. রেট এবং ফি
    $ref_bonus = $_POST['ref_bonus'];
    $act_fee = $_POST['activation_fee'];
    $aviator_limit = $_POST['aviator_limit'];

    // ৩. সোশ্যাল লিংকস (নতুন যোগ করা হলো)
    $youtube = $_POST['youtube_link'];
    $telegram = $_POST['telegram'];
    $wa_group = $_POST['whatsapp_group'];
    $fb_page = $_POST['fb_page'];
    $fb_group = $_POST['fb_group'];

    // ৪. একাউন্ট সেলিং রেট ও পাসওয়ার্ড
    $r_gm = $_POST['rate_gmail']; $p_gm = $_POST['pass_gmail'];
    $r_fb = $_POST['rate_facebook']; $p_fb = $_POST['pass_facebook'];
    $r_in = $_POST['rate_instagram']; $p_in = $_POST['pass_instagram'];

    $check = $pdo->query("SELECT id FROM settings LIMIT 1")->fetch();
    
    if ($check) {
        $sql = "UPDATE settings SET 
                site_name=?, notice=?, whatsapp=?, 
                ref_bonus=?, activation_fee=?, aviator_limit=?,
                youtube_link=?, telegram=?, whatsapp_group=?, fb_page=?, fb_group=?,
                rate_gmail=?, pass_gmail=?, rate_facebook=?, pass_facebook=?, rate_instagram=?, pass_instagram=?
                WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $site_name, $notice, $whatsapp, 
            $ref_bonus, $act_fee, $aviator_limit,
            $youtube, $telegram, $wa_group, $fb_page, $fb_group,
            $r_gm, $p_gm, $r_fb, $p_fb, $r_in, $p_in,
            $check['id']
        ]);
    } else {
        // ইনসার্ট লজিক (সাধারণত লাগবে না)
    }
    showAlert("Settings Updated Successfully! ✅");
}

$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();
require '../common/header.php';
?>

<h3>⚙️ Master Settings</h3>

<form method="POST">
    
    <!-- ১. সোশ্যাল মিডিয়া লিংকস (তোমার জন্য নতুন সেকশন) -->
    <div class="card shadow-sm mb-4 border-primary">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-link"></i> Social Media Links</h5>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label class="fw-bold text-danger"><i class="fab fa-youtube"></i> YouTube Channel Link</label>
                <input type="url" name="youtube_link" class="form-control" placeholder="https://youtube.com/..." value="<?php echo $settings['youtube_link'] ?? ''; ?>">
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="fw-bold text-info"><i class="fab fa-telegram"></i> Telegram Channel/Group</label>
                    <input type="url" name="telegram" class="form-control" value="<?php echo $settings['telegram'] ?? ''; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="fw-bold text-success"><i class="fab fa-whatsapp"></i> WhatsApp Group Link</label>
                    <input type="url" name="whatsapp_group" class="form-control" value="<?php echo $settings['whatsapp_group'] ?? ''; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="fw-bold text-primary"><i class="fab fa-facebook"></i> Facebook Page</label>
                    <input type="url" name="fb_page" class="form-control" value="<?php echo $settings['fb_page'] ?? ''; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="fw-bold text-primary"><i class="fab fa-facebook-square"></i> Facebook Group</label>
                    <input type="url" name="fb_group" class="form-control" value="<?php echo $settings['fb_group'] ?? ''; ?>">
                </div>
            </div>
        </div>
    </div>

    <!-- ২. অ্যাকাউন্ট সেলিং রেট -->
    <div class="card shadow-sm mb-4 border-dark">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0"><i class="fas fa-tags"></i> Account Rates & Passwords</h5>
        </div>
        <div class="card-body">
            <div class="row mb-2">
                <div class="col-6"><label>Gmail Rate</label><input type="number" name="rate_gmail" class="form-control" value="<?php echo $settings['rate_gmail']; ?>"></div>
                <div class="col-6"><label>Gmail Pass</label><input type="text" name="pass_gmail" class="form-control" value="<?php echo $settings['pass_gmail']; ?>"></div>
            </div>
            <div class="row mb-2">
                <div class="col-6"><label>FB Rate</label><input type="number" name="rate_facebook" class="form-control" value="<?php echo $settings['rate_facebook']; ?>"></div>
                <div class="col-6"><label>FB Pass</label><input type="text" name="pass_facebook" class="form-control" value="<?php echo $settings['pass_facebook']; ?>"></div>
            </div>
            <div class="row">
                <div class="col-6"><label>Insta Rate</label><input type="number" name="rate_instagram" class="form-control" value="<?php echo $settings['rate_instagram']; ?>"></div>
                <div class="col-6"><label>Insta Pass</label><input type="text" name="pass_instagram" class="form-control" value="<?php echo $settings['pass_instagram']; ?>"></div>
            </div>
        </div>
    </div>

    <!-- ৩. জেনারেল সেটিংস -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div class="mb-3">
                <label>App Name</label>
                <input type="text" name="site_name" class="form-control" value="<?php echo $settings['site_name']; ?>">
            </div>
            <div class="row">
                <div class="col-6 mb-3"><label>Activation Fee</label><input type="number" name="activation_fee" class="form-control" value="<?php echo $settings['activation_fee']; ?>"></div>
                <div class="col-6 mb-3"><label>Refer Bonus</label><input type="number" name="ref_bonus" class="form-control" value="<?php echo $settings['ref_bonus']; ?>"></div>
                <div class="col-6 mb-3"><label>Aviator Limit</label><input type="number" name="aviator_limit" class="form-control" value="<?php echo $settings['aviator_limit']; ?>"></div>
                <div class="col-6 mb-3"><label>Support WhatsApp (Number)</label><input type="text" name="whatsapp" class="form-control" value="<?php echo $settings['whatsapp']; ?>"></div>
            </div>
            <div class="mb-3">
                <label>App Notice</label>
                <textarea name="notice" class="form-control" rows="3"><?php echo $settings['notice']; ?></textarea>
            </div>
        </div>
    </div>

    <!-- সেভ বাটন -->
    <div class="fixed-bottom p-3 bg-white border-top shadow">
        <button type="submit" class="btn btn-success w-100 btn-lg rounded-pill">Update All Settings ✅</button>
    </div>
    <div style="height: 60px;"></div>

</form>

<?php require '../common/footer.php'; ?>