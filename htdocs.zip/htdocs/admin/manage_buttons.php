<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// স্ট্যাটাস চেঞ্জ লজিক
if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    $pdo->prepare("UPDATE app_buttons SET status = ? WHERE id = ?")->execute([$status, $id]);
    header("Location: manage_buttons.php");
    exit;
}

// সব বাটন আনা
$buttons = $pdo->query("SELECT * FROM app_buttons ORDER BY section ASC")->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center mb-4"><i class="fas fa-toggle-on"></i> App Button Control</h3>

<div class="row">
    <?php foreach($buttons as $btn): ?>
    <div class="col-md-3 col-6 mb-3">
        <div class="card shadow-sm border-0 text-center p-2 <?php echo $btn['status']=='active'?'':'bg-light opacity-75'; ?>">
            <img src="<?php echo $btn['icon']; ?>" width="40" class="mb-2">
            <h6 class="mb-2"><?php echo $btn['name']; ?></h6>
            <small class="text-muted d-block mb-2"><?php echo ucfirst($btn['section']); ?></small>
            
            <?php if($btn['status'] == 'active'): ?>
                <a href="?id=<?php echo $btn['id']; ?>&status=inactive" class="btn btn-sm btn-danger w-100">Hide <i class="fas fa-eye-slash"></i></a>
            <?php else: ?>
                <a href="?id=<?php echo $btn['id']; ?>&status=active" class="btn btn-sm btn-success w-100">Show <i class="fas fa-eye"></i></a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>