<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// আপডেট লজিক
if (isset($_POST['status'])) {
    $status = $_POST['status'];
    $pdo->prepare("UPDATE settings SET app_status = ?")->execute([$status]);
    showAlert("App is now " . strtoupper($status) . "!");
}

$current = $pdo->query("SELECT app_status FROM settings LIMIT 1")->fetchColumn();

require '../common/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6 text-center">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-dark text-white">
                <h4><i class="fas fa-power-off"></i> App System Control</h4>
            </div>
            <div class="card-body py-5">
                <h5 class="mb-4">Current Status: 
                    <?php if($current == 'on'): ?>
                        <span class="badge bg-success">RUNNING 🟢</span>
                    <?php else: ?>
                        <span class="badge bg-danger">STOPPED 🔴</span>
                    <?php endif; ?>
                </h5>

                <form method="POST" class="d-flex justify-content-center gap-3">
                    <!-- অন বাটন -->
                    <button type="submit" name="status" value="on" class="btn btn-success btn-lg px-5 <?php echo $current=='on'?'disabled':''; ?>">
                        <i class="fas fa-play"></i> Turn ON
                    </button>

                    <!-- অফ বাটন -->
                    <button type="submit" name="status" value="off" class="btn btn-danger btn-lg px-5 <?php echo $current=='off'?'disabled':''; ?>" onclick="return confirm('Are you sure? Users cannot access the app!')">
                        <i class="fas fa-stop"></i> Turn OFF
                    </button>
                </form>
                
                <p class="text-muted mt-4 small">
                    Note: If you turn OFF, only Admins can access the app. Users will see a maintenance page.
                </p>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>