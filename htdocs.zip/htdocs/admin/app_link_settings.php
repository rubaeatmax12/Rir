<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// আপডেট লজিক
if (isset($_POST['app_link'])) {
    $link = $_POST['app_link'];
    // ডাটাবেসে app_link কলাম আছে কিনা চেক করে আপডেট বা ইনসার্ট করতে হবে।
    // আমরা সহজ করার জন্য settings টেবিলে app_link কলামটি ব্যবহার করব।
    // যদি কলাম না থাকে, আগে সেটা বানাতে হবে (ধাপ ২ এ বলা আছে)।
    
    $pdo->prepare("UPDATE settings SET app_link = ? WHERE id = 1")->execute([$link]);
    showAlert("App Link Updated Successfully! 🎉");
}

$current_link = $pdo->query("SELECT app_link FROM settings WHERE id = 1")->fetchColumn();

require '../common/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6 text-center">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-primary text-white">
                <h4><i class="fas fa-link"></i> Set App Download Link</h4>
            </div>
            <div class="card-body py-5">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Enter App Link (Drive/Mediafire/PlayStore)</label>
                        <input type="url" name="app_link" class="form-control" placeholder="https://..." value="<?php echo $current_link; ?>" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100 rounded-pill">
                        <i class="fas fa-save"></i> Save Link
                    </button>
                </form>
                
                <?php if($current_link): ?>
                    <div class="mt-4">
                        <p class="text-muted">Current Link:</p>
                        <a href="<?php echo $current_link; ?>" target="_blank" class="btn btn-outline-primary btn-sm">Test Link</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>