<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// কার্ড ডিলিট করার লজিক (Unbind)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM user_cards WHERE id = ?")->execute([$id]);
    showAlert("Wallet Number Unlinked Successfully!", "warning");
}

// সার্চ লজিক
$search = $_GET['search'] ?? '';
if ($search) {
    $sql = "SELECT c.*, u.username 
            FROM user_cards c 
            JOIN users u ON c.user_id = u.id 
            WHERE u.username LIKE ? OR c.account_number LIKE ? 
            ORDER BY c.id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $sql = "SELECT c.*, u.username 
            FROM user_cards c 
            JOIN users u ON c.user_id = u.id 
            ORDER BY c.id DESC LIMIT 50";
    $stmt = $pdo->query($sql);
}

$cards = $stmt->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-wallet"></i> User Linked Wallets</h3>

<!-- সার্চ বার -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="search" class="form-control" placeholder="Search by Username or Wallet Number..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>User</th>
                        <th>Method</th>
                        <th>Number</th>
                        <th>Added Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($cards) > 0): ?>
                        <?php foreach($cards as $c): ?>
                        <tr>
                            <td class="fw-bold"><?php echo htmlspecialchars($c['username']); ?></td>
                            <td><span class="badge bg-info"><?php echo $c['method_name']; ?></span></td>
                            <td class="fw-bold text-dark"><?php echo $c['account_number']; ?></td>
                            <td><small><?php echo date('d M, Y', strtotime($c['created_at'])); ?></small></td>
                            <td>
                                <a href="?delete=<?php echo $c['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure? User will have to add number again.')">
                                    <i class="fas fa-trash-alt"></i> Unlink
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">No linked wallets found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>