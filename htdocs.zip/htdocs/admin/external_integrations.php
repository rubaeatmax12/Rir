<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // এখানে আপনি settings টেবিলে এই ফিল্ডগুলো সেভ করবেন
    // উদাহরণস্বরূপ:
    // $smtp_host = $_POST['smtp_host'];
    // updateSetting('smtp_host', $smtp_host); -> এমন ফাংশন ব্যবহার করতে পারেন
    showAlert("Integrations Updated (Demo)!");
}

require '../common/header.php';
?>
<h3>External Integrations</h3>
<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-info text-white">SMTP Email Server</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3"><label>SMTP Host</label><input type="text" class="form-control" placeholder="smtp.gmail.com"></div>
                    <div class="mb-3"><label>SMTP Port</label><input type="text" class="form-control" placeholder="587"></div>
                    <div class="mb-3"><label>Email</label><input type="email" class="form-control"></div>
                    <div class="mb-3"><label>App Password</label><input type="password" class="form-control"></div>
                    <button class="btn btn-primary">Save SMTP</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">SMS Gateway (Optional)</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3"><label>API Key</label><input type="text" class="form-control"></div>
                    <div class="mb-3"><label>Sender ID</label><input type="text" class="form-control"></div>
                    <button class="btn btn-primary">Save SMS Config</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require '../common/footer.php'; ?>