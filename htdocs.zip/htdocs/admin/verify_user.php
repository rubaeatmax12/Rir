<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

if (isset($_GET['uid'])) {
    $uid = $_GET['uid'];
    $status = $_GET['status']; // 1 for verify, 0 for unverify
    
    $pdo->prepare("UPDATE users SET is_verified = ? WHERE id = ?")->execute([$status, $uid]);
    header("Location: verify_user.php");
}

$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3>Manage Verified Users</h3>
<table class="table table-bordered bg-white">
    <tr><th>User</th><th>Status</th><th>Action</th></tr>
    <?php foreach($users as $u): ?>
    <tr>
        <td>
            <?php echo $u['username']; ?>
            <?php if($u['is_verified']) echo '<i class="fas fa-check-circle text-primary"></i>'; ?>
        </td>
        <td><?php echo $u['is_verified'] ? '<span class="badge bg-success">Verified</span>' : 'Normal'; ?></td>
        <td>
            <?php if($u['is_verified']): ?>
                <a href="?uid=<?php echo $u['id']; ?>&status=0" class="btn btn-sm btn-danger">Remove Badge</a>
            <?php else: ?>
                <a href="?uid=<?php echo $u['id']; ?>&status=1" class="btn btn-sm btn-primary">Give Badge</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php require '../common/footer.php'; ?>