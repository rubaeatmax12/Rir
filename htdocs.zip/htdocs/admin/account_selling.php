<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    $stmt = $pdo->prepare("SELECT * FROM account_sales WHERE id = ?");
    $stmt->execute([$id]);
    $acc = $stmt->fetch();

    if ($acc['status'] == 'pending') {
        if ($action == 'approve') {
            // ইউজারকে টাকা দেওয়া
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$acc['price'], $acc['user_id']]);
            // স্ট্যাটাস আপডেট
            $pdo->prepare("UPDATE account_sales SET status = 'approved' WHERE id = ?")->execute([$id]);
            showAlert("Account bought successfully! User paid.");
        } elseif ($action == 'reject') {
            $pdo->prepare("UPDATE account_sales SET status = 'rejected' WHERE id = ?")->execute([$id]);
            showAlert("Account Rejected.", "warning");
        }
    }
}

// পেন্ডিং অ্যাকাউন্ট লিস্ট
$sql = "SELECT a.*, u.username FROM account_sales a JOIN users u ON a.user_id = u.id WHERE a.status = 'pending'";
$accounts = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>
<h3>Account Selling Requests</h3>
<table class="table table-bordered bg-white">
    <thead>
        <tr>
            <th>User</th>
            <th>Type</th>
            <th>Email/Phone</th>
            <th>Password</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($accounts as $a): ?>
        <tr>
            <td><?php echo $a['username']; ?></td>
            <td><span class="badge bg-info"><?php echo ucfirst($a['type']); ?></span></td>
            <td><?php echo htmlspecialchars($a['email_or_phone']); ?></td>
            <td class="text-danger"><?php echo htmlspecialchars($a['password']); ?></td>
            <td><?php echo $a['price']; ?></td>
            <td>
                <a href="?action=approve&id=<?php echo $a['id']; ?>" class="btn btn-success btn-sm">Buy</a>
                <a href="?action=reject&id=<?php echo $a['id']; ?>" class="btn btn-danger btn-sm">Reject</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php require '../common/footer.php'; ?>