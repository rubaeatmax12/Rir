<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// হিস্ট্রি ফেচ করা
$sql = "SELECT s.*, u.username FROM salary_logs s 
        JOIN users u ON s.user_id = u.id 
        ORDER BY s.date DESC";
$logs = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>
<h3><i class="fas fa-file-invoice-dollar"></i> Salary Payment History</h3>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Date Paid</th>
                    <th>User / Employee</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($logs) > 0): ?>
                    <?php foreach($logs as $l): ?>
                    <tr>
                        <td><?php echo date('d M Y, h:i A', strtotime($l['date'])); ?></td>
                        <td><?php echo htmlspecialchars($l['username']); ?></td>
                        <td class="text-success fw-bold"><?php echo CURRENCY . $l['amount']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" class="text-center">No salary records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require '../common/footer.php'; ?>