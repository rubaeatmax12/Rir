<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// যারা মেসেজ দিয়েছে তাদের লিস্ট (Unique Users)
$sql = "SELECT DISTINCT u.id, u.username, u.email 
        FROM users u 
        JOIN support_messages sm ON u.id = sm.user_id 
        ORDER BY sm.created_at DESC";
$users = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-comments"></i> User Support Messages</h3>
<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="list-group list-group-flush">
            <?php foreach($users as $u): ?>
                <a href="reply.php?uid=<?php echo $u['id']; ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($u['username']); ?></h6>
                        <small class="text-muted"><?php echo $u['email']; ?></small>
                    </div>
                    <span class="btn btn-primary btn-sm rounded-pill">Chat Now <i class="fas fa-arrow-right"></i></span>
                </a>
            <?php endforeach; ?>
            <?php if(count($users) == 0): ?>
                <div class="p-4 text-center text-muted">No messages yet.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require '../common/footer.php'; ?>