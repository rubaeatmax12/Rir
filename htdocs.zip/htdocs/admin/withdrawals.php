<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];
    
    $stmt = $pdo->prepare("SELECT * FROM withdrawals WHERE id = ?");
    $stmt->execute([$id]);
    $wd = $stmt->fetch();

    if ($wd['status'] == 'pending') {
        if ($action == 'paid') {
            $pdo->prepare("UPDATE withdrawals SET status = 'approved' WHERE id = ?")->execute([$id]);
            showAlert("Marked as Paid!");
        } elseif ($action == 'reject') {
            // রিজেক্ট হলে টাকা ফেরত দেওয়া
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$wd['amount'], $wd['user_id']]);
            $pdo->prepare("UPDATE withdrawals SET status = 'rejected' WHERE id = ?")->execute([$id]);
            $pdo->commit();
            showAlert("Request Rejected and Money Refunded!", "warning");
        }
    }
}

$withdrawals = $pdo->query("SELECT w.*, u.username FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.status = 'pending'")->fetchAll();

require '../common/header.php';
?>
<h3>Pending Withdrawals</h3>
<table class="table table-bordered bg-white">
    <thead>
        <tr>
            <th>User</th>
            <th>Amount</th>
            <th>To</th>
            <th>Account</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($withdrawals as $w): ?>
        <tr>
            <td><?php echo $w['username']; ?></td>
            <td><?php echo $w['amount']; ?></td>
            <td><?php echo ucfirst($w['method']); ?></td>
            <td><?php echo $w['account_number']; ?></td>
            <td>
                <a href="?action=paid&id=<?php echo $w['id']; ?>" class="btn btn-success btn-sm">Mark Paid</a>
                <a href="?action=reject&id=<?php echo $w['id']; ?>" class="btn btn-danger btn-sm">Reject & Refund</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php require '../common/footer.php'; ?>