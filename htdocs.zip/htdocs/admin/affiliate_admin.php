<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $link = $_POST['link'];
    $comm = $_POST['commission'];
    $img_name = "aff_".time().".jpg";
    
    // ডাইরেক্ট লিংক বা ইমেজ আপলোড
    move_uploaded_file($_FILES['image']['tmp_name'], "../assets/images/products/".$img_name);
    
    $pdo->prepare("INSERT INTO affiliate_products (title, product_link, image, commission) VALUES (?, ?, ?, ?)")->execute([$title, $link, $img_name, $comm]);
    showAlert("Affiliate Product Added!");
}

require '../common/header.php';
?>
<h3>Add Affiliate Product</h3>
<form method="POST" enctype="multipart/form-data" class="card p-3 shadow-sm mb-4">
    <input type="text" name="title" class="form-control mb-2" placeholder="Product Name (e.g. Daraz Watch)" required>
    <input type="url" name="link" class="form-control mb-2" placeholder="Product Link (https://daraz...)" required>
    <input type="number" step="0.01" name="commission" class="form-control mb-2" placeholder="Commission per Click (Ex: 0.50)" required>
    <input type="file" name="image" class="form-control mb-2" required>
    <button class="btn btn-success w-100">Add Product</button>
</form>
<?php require '../common/footer.php'; ?>