<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

// ব্যানার আপলোড
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $target_dir = "../assets/images/banners/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
    
    $file_name = time() . "_" . basename($_FILES["banner_img"]["name"]);
    $target_file = $target_dir . $file_name;
    $link = $_POST['link'];
    
    if (move_uploaded_file($_FILES["banner_img"]["tmp_name"], $target_file)) {
        $pdo->prepare("INSERT INTO banners (image_path, link) VALUES (?, ?)")->execute([$file_name, $link]);
        showAlert("Banner Added Successfully!");
    } else {
        showAlert("Image upload failed!", "danger");
    }
}

// ব্যানার ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM banners WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: banners.php");
}

$banners = $pdo->query("SELECT * FROM banners")->fetchAll();
require '../common/header.php';
?>

<h3>Manage Homepage Banners</h3>

<div class="card mb-4">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-5">
                    <input type="file" name="banner_img" class="form-control" required>
                </div>
                <div class="col-md-5">
                    <input type="text" name="link" class="form-control" placeholder="Link (Optional)">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Upload</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="row">
    <?php foreach($banners as $b): ?>
    <div class="col-md-4 mb-3">
        <div class="card">
            <img src="../assets/images/banners/<?php echo $b['image_path']; ?>" class="card-img-top" alt="Banner">
            <div class="card-body text-center">
                <p>Link: <?php echo $b['link'] ?: 'No Link'; ?></p>
                <a href="?delete=<?php echo $b['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmAction()">Delete</a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>