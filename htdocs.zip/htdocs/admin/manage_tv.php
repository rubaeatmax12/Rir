<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// চ্যানেল অ্যাড করা
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $url = $_POST['stream_url'];
    $cat = $_POST['category'];
    
    // লোগো আপলোড
    $img_name = time() . "_" . $_FILES['logo']['name'];
    $target = "../assets/images/tv/" . $img_name;
    if (!is_dir('../assets/images/tv')) mkdir('../assets/images/tv', 0777, true);
    
    if (move_uploaded_file($_FILES['logo']['tmp_name'], $target)) {
        $sql = "INSERT INTO tv_channels (name, logo, stream_url, category) VALUES (?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([$name, $img_name, $url, $cat]);
        showAlert("TV Channel Added Successfully!");
    }
}

// চ্যানেল ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM tv_channels WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: manage_tv.php");
}

$channels = $pdo->query("SELECT * FROM tv_channels ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3><i class="fas fa-tv"></i> Manage Live TV</h3>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Channel Name</label>
                <input type="text" name="name" class="form-control" placeholder="Ex: Somoy TV" required>
            </div>
            <div class="mb-3">
                <label>Stream URL (m3u8 or YouTube Embed)</label>
                <input type="text" name="stream_url" class="form-control" placeholder="http://server.com/live.m3u8" required>
                <small class="text-muted">Google search 'Free BD IP TV m3u8 links' to get urls.</small>
            </div>
            <div class="mb-3">
                <label>Category</label>
                <select name="category" class="form-control">
                    <option>News</option>
                    <option>Sports</option>
                    <option>Entertainment</option>
                    <option>Islamic</option>
                </select>
            </div>
            <div class="mb-3">
                <label>Channel Logo</label>
                <input type="file" name="logo" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-danger w-100">Add Channel</button>
        </form>
    </div>
</div>

<div class="row">
    <?php foreach($channels as $ch): ?>
    <div class="col-md-4 mb-3">
        <div class="card">
            <div class="d-flex align-items-center p-2">
                <img src="../assets/images/tv/<?php echo $ch['logo']; ?>" width="60" class="rounded me-3">
                <div>
                    <h6 class="mb-0 fw-bold"><?php echo $ch['name']; ?></h6>
                    <small class="text-muted"><?php echo $ch['category']; ?></small>
                </div>
                <a href="?delete=<?php echo $ch['id']; ?>" class="btn btn-sm btn-outline-danger ms-auto" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>