<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

// মেসেজ পাঠানোর লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $title = $_POST['title'];
    $message = $_POST['message'];

    // ইউজার আইডি বের করা
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {
        $sql = "INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)";
        $pdo->prepare($sql)->execute([$user['id'], $title, $message]);
        showAlert("Message sent successfully to $username!");
    } else {
        showAlert("User not found!", "danger");
    }
}

require '../common/header.php';
?>

<h3>Send Message to User</h3>
<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label>Username (To whom?)</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username (e.g. rubaeat22)" required>
            </div>
            <div class="mb-3">
                <label>Title</label>
                <input type="text" name="title" class="form-control" placeholder="Ex: Withdrawal Update" required>
            </div>
            <div class="mb-3">
                <label>Message</label>
                <textarea name="message" class="form-control" rows="4" placeholder="Ex: Your money has been sent to bKash." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary w-100">Send Notification <i class="fas fa-paper-plane"></i></button>
        </form>
    </div>
</div>

<?php require '../common/footer.php'; ?>