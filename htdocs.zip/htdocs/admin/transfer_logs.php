<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// হিস্ট্রি ডাটা আনা (Sender এবং Receiver এর নাম সহ)
$sql = "SELECT t.*, s.username as sender, r.username as receiver 
        FROM transfer_history t 
        JOIN users s ON t.sender_id = s.id 
        JOIN users r ON t.receiver_id = r.id 
        ORDER BY t.id DESC LIMIT 50";
$logs = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-exchange-alt"></i> User Transfer Logs</h3>
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <table class="table table-striped table-hover mb-0">
            <thead class="bg-primary text-white">
                <tr>
                    <th>Date</th>
                    <th>Sender (From)</th>
                    <th>Receiver (To)</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($logs as $log): ?>
                <tr>
                    <td><?php echo date('d M, h:i A', strtotime($log['created_at'])); ?></td>
                    <td class="text-danger fw-bold"><?php echo $log['sender']; ?></td>
                    <td class="text-success fw-bold"><?php echo $log['receiver']; ?></td>
                    <td class="fw-bold"><?php echo CURRENCY . $log['amount']; ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($logs)) echo "<tr><td colspan='4' class='text-center p-3'>No transfers yet.</td></tr>"; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../common/footer.php'; ?>