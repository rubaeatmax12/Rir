<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// --- ফাংশন: হিসাব বের করার জন্য ---
function getSum($pdo, $table, $status, $period = 'all') {
    $sql = "SELECT SUM(amount) FROM $table WHERE status = ?";
    if ($period == 'today') {
        $sql .= " AND DATE(created_at) = CURDATE()";
    } elseif ($period == 'month') {
        $sql .= " AND MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$status]);
    return $stmt->fetchColumn() ?: 0;
}

// ১. মোট হিসাব (Life Time)
$total_dep = getSum($pdo, 'deposits', 'approved');
$total_wit = getSum($pdo, 'withdrawals', 'approved');
$net_profit = $total_dep - $total_wit;

// ২. আজকের হিসাব (Today)
$today_dep = getSum($pdo, 'deposits', 'approved', 'today');
$today_wit = getSum($pdo, 'withdrawals', 'approved', 'today');
$today_profit = $today_dep - $today_wit;

// ৩. এই মাসের হিসাব (Monthly)
$month_dep = getSum($pdo, 'deposits', 'approved', 'month');
$month_wit = getSum($pdo, 'withdrawals', 'approved', 'month');

// ৪. পেন্ডিং (বাকি)
$pending_dep = getSum($pdo, 'deposits', 'pending');
$pending_wit = getSum($pdo, 'withdrawals', 'pending');

// ৫. মোট ইউজার ব্যালেন্স (দায়)
$user_liability = $pdo->query("SELECT SUM(balance) FROM users")->fetchColumn() ?: 0;

require '../common/header.php';
?>

<style>
    .stat-box { border-radius: 15px; padding: 20px; color: white; margin-bottom: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .bg-profit { background: linear-gradient(45deg, #11998e, #38ef7d); }
    .bg-loss { background: linear-gradient(45deg, #ff416c, #ff4b2b); }
    .bg-info-grad { background: linear-gradient(45deg, #2193b0, #6dd5ed); }
    .bg-dark-grad { background: linear-gradient(45deg, #232526, #414345); }
</style>

<div class="container mt-3">
    <h3 class="text-center fw-bold mb-4 text-primary"><i class="fas fa-calculator"></i> Business Report</h3>

    <!-- 🔥 মেইন লাভ/লস কার্ড 🔥 -->
    <div class="stat-box <?php echo $net_profit >= 0 ? 'bg-profit' : 'bg-loss'; ?> text-center">
        <h4>Net Profit (All Time)</h4>
        <h1 class="fw-bold display-4"><?php echo CURRENCY . number_format($net_profit, 2); ?></h1>
        <small>(Total Deposit - Total Withdraw)</small>
    </div>

    <!-- আজকের হিসাব -->
    <div class="card shadow-sm mb-3">
        <div class="card-header bg-dark text-white">📅 Today's Report</div>
        <div class="card-body">
            <div class="row text-center">
                <div class="col-4 border-end">
                    <h6 class="text-success">Income</h6>
                    <b>+<?php echo $today_dep; ?></b>
                </div>
                <div class="col-4 border-end">
                    <h6 class="text-danger">Expense</h6>
                    <b>-<?php echo $today_wit; ?></b>
                </div>
                <div class="col-4">
                    <h6 class="text-primary">Profit</h6>
                    <b><?php echo $today_profit; ?></b>
                </div>
            </div>
        </div>
    </div>

    <!-- লাইফটাইম বিস্তারিত -->
    <div class="row g-3">
        <!-- ইনকাম -->
        <div class="col-md-6">
            <div class="card border-success shadow-sm h-100">
                <div class="card-body">
                    <h5 class="text-success"><i class="fas fa-arrow-down"></i> Total Deposit</h5>
                    <h3 class="fw-bold"><?php echo CURRENCY . number_format($total_dep, 2); ?></h3>
                    <hr>
                    <small>This Month: <b><?php echo $month_dep; ?></b></small><br>
                    <small class="text-muted">Pending Req: <?php echo $pending_dep; ?></small>
                </div>
            </div>
        </div>

        <!-- ব্যয় -->
        <div class="col-md-6">
            <div class="card border-danger shadow-sm h-100">
                <div class="card-body">
                    <h5 class="text-danger"><i class="fas fa-arrow-up"></i> Total Paid</h5>
                    <h3 class="fw-bold"><?php echo CURRENCY . number_format($total_wit, 2); ?></h3>
                    <hr>
                    <small>This Month: <b><?php echo $month_wit; ?></b></small><br>
                    <small class="text-muted">Pending Req: <?php echo $pending_wit; ?></small>
                </div>
            </div>
        </div>

        <!-- কোম্পানির দায় (Liability) -->
        <div class="col-12">
            <div class="alert alert-warning shadow-sm border-warning">
                <h5><i class="fas fa-users"></i> Users Wallet Balance</h5>
                <h3 class="fw-bold text-dark"><?php echo CURRENCY . number_format($user_liability, 2); ?></h3>
                <small>এই টাকাটা ইউজারদের অ্যাকাউন্টে আছে (এখনো তোলে নাই)।</small>
            </div>
        </div>
    </div>

</div>

<?php require '../common/footer.php'; ?>