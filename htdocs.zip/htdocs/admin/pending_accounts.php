<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// কোন ট্যাবে আছে সেটা ধরা (ডিফল্ট gmail)
$current_tab = $_GET['tab'] ?? 'gmail';

// ১. চেকিং স্ট্যাটাস আপডেট
if (isset($_GET['action']) && $_GET['action'] == 'checking' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $pdo->prepare("UPDATE account_sales SET status = 'checking' WHERE id = ?")->execute([$id]);
    showAlert("Marked as Checking! 🧐", "info");
}

// ২. অ্যাপ্রুভ বা রিজেক্ট লজিক
if (isset($_POST['action'])) {
    $id = $_POST['id'];
    $action = $_POST['action'];
    $reason = $_POST['reason'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM account_sales WHERE id = ?");
    $stmt->execute([$id]);
    $acc = $stmt->fetch();

    if ($acc && ($acc['status'] == 'pending' || $acc['status'] == 'checking')) {
        if ($action == 'approve') {
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$acc['price'], $acc['user_id']]);
            $pdo->prepare("UPDATE account_sales SET status = 'approved' WHERE id = ?")->execute([$id]);
            $msg = "Your {$acc['type']} account is Approved! Money added.";
            $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Account Sold! ✅', ?)")->execute([$acc['user_id'], $msg]);
            showAlert("Approved & User Notified!");

        } elseif ($action == 'reject') {
            $pdo->prepare("UPDATE account_sales SET status = 'rejected' WHERE id = ?")->execute([$id]);
            $msg = "Your {$acc['type']} account was Rejected. Reason: " . $reason;
            $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Sale Rejected ❌', ?)")->execute([$acc['user_id'], $msg]);
            showAlert("Rejected!", "warning");
        }
    }
}

// ৩. লিস্ট আনা (শুধুমাত্র সিলেক্ট করা ট্যাবের ডাটা)
$stmt = $pdo->prepare("SELECT a.*, u.username 
                       FROM account_sales a 
                       JOIN users u ON a.user_id = u.id 
                       WHERE a.status IN ('pending', 'checking') AND a.type = ? 
                       ORDER BY a.id ASC");
$stmt->execute([$current_tab]);
$accounts = $stmt->fetchAll();

require '../common/header.php';
?>

<h3 class="text-warning text-center mb-3"><i class="fas fa-store"></i> Manage Accounts</h3>

<!-- 🔥 ৩টি বাটন (Gmail, Facebook, Instagram) 🔥 -->
<div class="row g-2 mb-4">
    <div class="col-4">
        <a href="?tab=gmail" class="btn w-100 <?php echo $current_tab=='gmail'?'btn-danger':'btn-outline-danger'; ?>">
            <i class="fab fa-google"></i> Gmail
        </a>
    </div>
    <div class="col-4">
        <a href="?tab=facebook" class="btn w-100 <?php echo $current_tab=='facebook'?'btn-primary':'btn-outline-primary'; ?>">
            <i class="fab fa-facebook-f"></i> FB
        </a>
    </div>
    <div class="col-4">
        <a href="?tab=instagram" class="btn w-100 <?php echo $current_tab=='instagram'?'btn-warning text-dark':'btn-outline-warning text-dark'; ?>">
            <i class="fab fa-instagram"></i> Insta
        </a>
    </div>
</div>

<!-- অ্যাকাউন্ট লিস্ট -->
<?php foreach($accounts as $a): ?>
    <div class="card mb-3 shadow-sm <?php echo $a['status'] == 'checking' ? 'border-info' : 'border-warning'; ?>">
        <div class="card-header d-flex justify-content-between text-white <?php echo $a['status'] == 'checking' ? 'bg-info' : 'bg-warning text-dark'; ?>">
            <span>Seller: <strong><?php echo $a['username']; ?></strong></span>
            <span class="badge bg-light text-dark"><?php echo ucfirst($a['status']); ?></span>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-12">
                    <p class="mb-1"><strong>ID/Email:</strong> <span class="text-primary fw-bold user-select-all"><?php echo $a['email_or_phone']; ?></span></p>
                    <p class="mb-1"><strong>Password:</strong> <span class="text-danger fw-bold user-select-all"><?php echo $a['password']; ?></span></p>
                    
                    <!-- 🔥 2FA Key দেখাচ্ছে (যদি থাকে) 🔥 -->
                    <?php if(!empty($a['two_fa_key'])): ?>
                        <div class="alert alert-success py-1 mt-2 mb-1">
                            <strong>🔑 2FA Key:</strong> <span class="fw-bold fs-5 user-select-all"><?php echo $a['two_fa_key']; ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <p class="mb-0 text-muted small">Rate: <?php echo CURRENCY . $a['price']; ?></p>
                </div>
            </div>
            
            <!-- অ্যাকশন বাটন -->
            <div class="d-flex flex-wrap gap-2">
                <?php if($a['status'] == 'pending'): ?>
                    <a href="?tab=<?php echo $current_tab; ?>&action=checking&id=<?php echo $a['id']; ?>" class="btn btn-info btn-sm text-white flex-fill">
                        <i class="fas fa-eye"></i> Mark Checking
                    </a>
                <?php endif; ?>

                <form method="POST" action="?tab=<?php echo $current_tab; ?>" class="d-flex gap-2 flex-fill" style="min-width: 100%;">
                    <input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                    <button type="submit" name="action" value="approve" class="btn btn-success btn-sm flex-fill" onclick="return confirm('Approve & Add Balance?')">
                        Approve
                    </button>
                    <div class="input-group input-group-sm flex-fill">
                        <input type="text" name="reason" class="form-control" placeholder="Reject Reason..." required>
                        <button type="submit" name="action" value="reject" class="btn btn-danger">Reject</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<?php if(empty($accounts)): ?>
    <div class="alert alert-light text-center border mt-4 text-muted">
        <i class="fas fa-box-open fa-3x mb-2"></i><br>
        No pending <b><?php echo ucfirst($current_tab); ?></b> accounts to review.
    </div>
<?php endif; ?>

<?php require '../common/footer.php'; ?>