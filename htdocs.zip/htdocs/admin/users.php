<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// স্ট্যাটাস চেঞ্জ লজিক
if (isset($_GET['activate'])) {
    $uid = $_GET['activate'];
    $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?")->execute([$uid]);
    showAlert("User Activated Manually!");
}
if (isset($_GET['ban'])) {
    $uid = $_GET['ban'];
    $pdo->prepare("UPDATE users SET status = 'ban' WHERE id = ?")->execute([$uid]);
    showAlert("User Banned!");
}

// সার্চ অপশন
$search = $_GET['search'] ?? '';
$sql = "SELECT * FROM users WHERE username LIKE ? ORDER BY id DESC LIMIT 50";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$search%"]);
$users = $stmt->fetchAll();

require '../common/header.php';
?>

<h3>User Management</h3>

<form class="mb-3 d-flex">
    <input type="text" name="search" class="form-control me-2" placeholder="Search Username..." value="<?php echo $search; ?>">
    <button type="submit" class="btn btn-primary">Search</button>
</form>

<div class="table-responsive">
    <table class="table table-bordered bg-white">
        <thead>
            <tr>
                <th>User</th>
                <th>Balance</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($users as $u): ?>
            <tr>
                <td>
                    <strong><?php echo $u['username']; ?></strong><br>
                    <small><?php echo $u['phone']; ?></small>
                </td>
                <td><?php echo CURRENCY . $u['balance']; ?></td>
                <td>
                    <?php if($u['status'] == 'active'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php elseif($u['status'] == 'ban'): ?>
                        <span class="badge bg-danger">Banned</span>
                    <?php else: ?>
                        <span class="badge bg-warning text-dark">Inactive</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($u['status'] == 'inactive'): ?>
                        <a href="?activate=<?php echo $u['id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Activate this user for FREE?')">Activate</a>
                    <?php endif; ?>
                    
                    <?php if($u['status'] != 'ban'): ?>
                        <a href="?ban=<?php echo $u['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Ban this user?')">Ban</a>
                    <?php else: ?>
                        <a href="?activate=<?php echo $u['id']; ?>" class="btn btn-sm btn-warning">Unban</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require '../common/footer.php'; ?>