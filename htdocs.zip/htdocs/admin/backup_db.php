<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// ব্যাকআপ ফাইলের নাম (তারিখ ও সময় সহ)
$backup_name = "backup_" . date("Y-m-d_H-i-s") . ".sql";
$tables = [];

// ১. সব টেবিলের নাম আনা
$query = $pdo->query('SHOW TABLES');
while ($row = $query->fetch(PDO::FETCH_NUM)) {
    $tables[] = $row[0];
}

// SQL ফাইলের হেডার
$content = "-- Database Backup\n";
$content .= "-- Site: " . SITE_NAME . "\n";
$content .= "-- Date: " . date("Y-m-d H:i:s") . "\n\n";
$content .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
$content .= "SET time_zone = \"+06:00\";\n\n";

// ২. প্রতিটি টেবিলের ডাটা এবং স্ট্রাকচার নেওয়া
foreach ($tables as $table) {
    // টেবিল ড্রপ করার কোড (রিস্টোর করার সময় আগেরটা মুছে ফেলবে)
    $content .= "DROP TABLE IF EXISTS `$table`;\n";

    // টেবিল তৈরির কোড (Structure)
    $create_table = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
    $content .= $create_table[1] . ";\n\n";

    // টেবিলের ভেতরের ডাটা (Data)
    $rows = $pdo->query("SELECT * FROM `$table`");
    $column_count = $rows->columnCount();

    while ($row = $rows->fetch(PDO::FETCH_NUM)) {
        $content .= "INSERT INTO `$table` VALUES(";
        for ($j = 0; $j < $column_count; $j++) {
            $row[$j] = addslashes($row[$j]);
            $row[$j] = str_replace("\n", "\\n", $row[$j]);
            
            if (isset($row[$j])) {
                $content .= '"' . $row[$j] . '"';
            } else {
                $content .= '""';
            }
            
            if ($j < ($column_count - 1)) {
                $content .= ',';
            }
        }
        $content .= ");\n";
    }
    $content .= "\n\n";
}

// ৩. ফাইল ডাউনলোড করানো (Force Download)
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $backup_name . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . strlen($content));
echo $content;
exit;
?>