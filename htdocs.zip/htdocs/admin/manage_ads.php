<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// অ্যাড যোগ করা
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $link = $_POST['ad_link'];
    $reward = $_POST['reward'];
    $time = $_POST['timer'];

    $sql = "INSERT INTO ptc_ads (title, ad_link, reward, timer_seconds) VALUES (?, ?, ?, ?)";
    $pdo->prepare($sql)->execute([$title, $link, $reward, $time]);
    showAlert("Ad Added Successfully!");
}

// অ্যাড ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM ptc_ads WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: manage_ads.php");
}

$ads = $pdo->query("SELECT * FROM ptc_ads ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3><i class="fas fa-ad"></i> Manage PTC Ads</h3>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="POST">
            <div class="mb-2">
                <label>Ad Title</label>
                <input type="text" name="title" class="form-control" placeholder="Ex: Visit & Earn" required>
            </div>
            <div class="mb-2">
                <label>Ad Direct Link (Adsterra/Monetag)</label>
                <input type="url" name="ad_link" class="form-control" placeholder="https://..." required>
            </div>
            <div class="row">
                <div class="col-6 mb-2">
                    <label>Reward (Tk)</label>
                    <input type="number" step="0.01" name="reward" class="form-control" value="0.50" required>
                </div>
                <div class="col-6 mb-2">
                    <label>Timer (Seconds)</label>
                    <input type="number" name="timer" class="form-control" value="15" required>
                </div>
            </div>
            <button type="submit" class="btn btn-success w-100">Add New Ad</button>
        </form>
    </div>
</div>

<div class="list-group">
    <?php foreach($ads as $ad): ?>
    <div class="list-group-item d-flex justify-content-between align-items-center">
        <div>
            <h6 class="mb-0 fw-bold"><?php echo $ad['title']; ?></h6>
            <small class="text-muted"><?php echo $ad['timer']; ?>s | Pay: <?php echo $ad['reward']; ?> Tk</small>
        </div>
        <a href="?delete=<?php echo $ad['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</a>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>