<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

$type = $_GET['type'] ?? 'gmail'; // ডিফল্ট জিমেইল

// ডাটাবেস থেকে সব অ্যাপ্রুভড অ্যাকাউন্ট আনা
$stmt = $pdo->prepare("SELECT * FROM account_sales WHERE type = ? AND status = 'approved' ORDER BY created_at DESC");
$stmt->execute([$type]);
$all_accounts = $stmt->fetchAll();

// সপ্তাহ অনুযায়ী গ্রুপ করা (PHP Logic)
$weekly_data = [];
foreach ($all_accounts as $acc) {
    // সপ্তাহের শুরুর তারিখ বের করা
    $date = new DateTime($acc['created_at']);
    $week_start = $date->modify('this week')->format('d M, Y');
    $week_end = $date->modify('+6 days')->format('d M, Y');
    
    $key = "$week_start - $week_end"; // গ্রুপের নাম
    $weekly_data[$key][] = $acc;
}

require '../common/header.php';
?>

<h3 class="text-center mb-4 text-primary"><i class="fas fa-sticky-note"></i> Weekly Password Notes</h3>

<!-- ৩টি বাটন -->
<div class="row g-2 mb-4">
    <div class="col-4">
        <a href="?type=gmail" class="btn w-100 <?php echo $type=='gmail'?'btn-danger':'btn-outline-danger'; ?>">
            <i class="fab fa-google"></i> Gmail
        </a>
    </div>
    <div class="col-4">
        <a href="?type=facebook" class="btn w-100 <?php echo $type=='facebook'?'btn-primary':'btn-outline-primary'; ?>">
            <i class="fab fa-facebook-f"></i> Facebook
        </a>
    </div>
    <div class="col-4">
        <a href="?type=instagram" class="btn w-100 <?php echo $type=='instagram'?'btn-warning':'btn-outline-warning'; ?>">
            <i class="fab fa-instagram"></i> Instagram
        </a>
    </div>
</div>

<?php if (empty($weekly_data)): ?>
    <div class="alert alert-warning text-center">No sold accounts found for <?php echo ucfirst($type); ?>.</div>
<?php else: ?>

    <div class="accordion" id="accordionWeeks">
        <?php $i = 0; foreach ($weekly_data as $week => $accounts): $i++; ?>
            
            <div class="accordion-item shadow-sm mb-3 border-0">
                <h2 class="accordion-header" id="heading<?php echo $i; ?>">
                    <button class="accordion-button <?php echo $i>1?'collapsed':''; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i; ?>">
                        <span>📅 <strong>Week:</strong> <?php echo $week; ?></span>
                        <span class="badge bg-dark ms-auto"><?php echo count($accounts); ?> Acc</span>
                    </button>
                </h2>
                <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $i==1?'show':''; ?>" data-bs-parent="#accordionWeeks">
                    <div class="accordion-body bg-light">
                        
                        <!-- নোট কপি করার বক্স -->
                        <div class="mb-3">
                            <label class="fw-bold small text-muted">Copy for Notepad:</label>
                            <textarea id="note<?php echo $i; ?>" class="form-control" rows="4" readonly style="font-size: 12px; font-family: monospace;"><?php 
                                foreach($accounts as $a) {
                                    echo $a['email_or_phone'] . " : " . $a['password'] . "\n";
                                }
                            ?></textarea>
                            <button onclick="copyNote('note<?php echo $i; ?>')" class="btn btn-sm btn-dark w-100 mt-1">
                                <i class="fas fa-copy"></i> Copy All Passwords
                            </button>
                        </div>

                        <!-- সুন্দর টেবিল ভিউ -->
                        <table class="table table-bordered bg-white table-sm" style="font-size: 13px;">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID/Email</th>
                                    <th>Password</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($accounts as $acc): ?>
                                <tr>
                                    <td class="text-primary fw-bold"><?php echo $acc['email_or_phone']; ?></td>
                                    <td class="text-danger user-select-all"><?php echo $acc['password']; ?></td>
                                    <td><?php echo date('d M', strtotime($acc['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

        <?php endforeach; ?>
    </div>

<?php endif; ?>

<script>
function copyNote(id) {
    let textarea = document.getElementById(id);
    textarea.select();
    document.execCommand("copy");
    alert("List Copied! Now paste it in your Notepad.");
}
</script>

<?php require '../common/footer.php'; ?>