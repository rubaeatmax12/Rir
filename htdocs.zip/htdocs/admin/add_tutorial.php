<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// ইউটিউব ভিডিও আইডি বের করার ফাংশন (অটোমেটিক থাম্বনেইলের জন্য)
function getYoutubeId($url) {
    preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match);
    return isset($match[1]) ? $match[1] : null;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $link = $_POST['link'];
    
    // ভিডিও আইডি চেক
    $vid_id = getYoutubeId($link);
    
    if ($vid_id) {
        $stmt = $pdo->prepare("INSERT INTO tutorial_videos (title, video_link) VALUES (?, ?)");
        $stmt->execute([$title, $link]);
        showAlert("Tutorial Video Added!");
    } else {
        showAlert("Invalid YouTube Link!", "danger");
    }
}

// ডিলিট অপশন
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM tutorial_videos WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: add_tutorial.php");
}

$videos = $pdo->query("SELECT * FROM tutorial_videos ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3><i class="fab fa-youtube text-danger"></i> Add Work Tutorial</h3>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label>Video Title</label>
                <input type="text" name="title" class="form-control" placeholder="Ex: How to create account" required>
            </div>
            <div class="mb-3">
                <label>YouTube Link</label>
                <input type="url" name="link" class="form-control" placeholder="https://youtu.be/..." required>
            </div>
            <button type="submit" class="btn btn-danger w-100">Add Video</button>
        </form>
    </div>
</div>

<div class="row">
    <?php foreach($videos as $v): 
        $vid_id = getYoutubeId($v['video_link']);
        $thumb = "https://img.youtube.com/vi/$vid_id/mqdefault.jpg";
    ?>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <img src="<?php echo $thumb; ?>" class="card-img-top">
            <div class="card-body p-2">
                <h6 class="mb-2"><?php echo htmlspecialchars($v['title']); ?></h6>
                <a href="?delete=<?php echo $v['id']; ?>" class="btn btn-sm btn-outline-danger w-100" onclick="return confirm('Delete?')">Delete</a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>