<?php
require '../common/config.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// মেমোরি লিমিট এবং টাইম বাড়ানো
@ini_set('memory_limit', '256M');
@ini_set('max_execution_time', 300);

// নিরাপদ উপায়ে রুট ফোল্ডার ধরা
$rootPath = dirname(__DIR__); 

$zipname = 'Source_Code_Backup_' . date('Y-m-d_H-i-s') . '.zip';
$zipPath = $rootPath . '/' . $zipname;

$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    die("⚠️ Error: Cannot create zip file. Permission denied.");
}

// ফাইল স্ক্যানার (SKIP_DOTS ব্যবহার করা হয়েছে যাতে এরর না আসে)
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($rootPath, RecursiveDirectoryIterator::SKIP_DOTS),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $name => $file) {
    // ফাইল পাথ বের করা
    $filePath = $file->getRealPath();
    
    // যদি realpath কাজ না করে (ফ্রি হোস্টিংয়ে মাঝে মাঝে হয়)
    if (!$filePath) {
        $filePath = $file->getPathname();
    }

    // রিলেটিভ পাথ তৈরি
    $relativePath = substr($filePath, strlen($rootPath) + 1);

    // জিপ ফাইল এবং এরর লগ বাদ দেওয়া (লুপ আটকানোর জন্য)
    if (pathinfo($filePath, PATHINFO_EXTENSION) == 'zip' || strpos($filePath, 'error_log') !== false) {
        continue;
    }

    // ফাইলে যোগ করা
    if (!$file->isDir()) {
        // @ চিহ্ন দিয়ে এরর সাপ্রেস করা হলো যাতে ছোটখাটো পারমিশন এররে কোড না থামে
        @$zip->addFile($filePath, $relativePath);
    }
}

$zip->close();

// ডাউনলোড করানো
if (file_exists($zipPath)) {
    // বাফার ক্লিন করা
    if (ob_get_level()) ob_end_clean();
    
    header('Content-Description: File Transfer');
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="'.basename($zipPath).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($zipPath));
    
    readfile($zipPath);
    
    // ডাউনলোডের পর সার্ভার থেকে ফাইল মুছে ফেলা
    @unlink($zipPath);
    exit;
} else {
    echo "⚠️ Error: Backup file could not be created.";
}
?>