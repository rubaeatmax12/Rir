<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// অ্যাপ্রুভ বা রিজেক্ট করার লজিক
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    // সাবমিশনের তথ্য আনা
    $stmt = $pdo->prepare("SELECT * FROM task_submissions WHERE id = ? AND status = 'pending'");
    $stmt->execute([$id]);
    $sub = $stmt->fetch();

    if ($sub) {
        if ($action == 'approve') {
            // টাস্কের রেট (টাকা) কত সেটা জানা
            $t_stmt = $pdo->prepare("SELECT reward FROM tasks WHERE id = ?");
            $t_stmt->execute([$sub['task_id']]);
            $reward = $t_stmt->fetchColumn();

            // ১. ইউজারকে টাকা দেওয়া
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$reward, $sub['user_id']]);
            // ২. স্ট্যাটাস অ্যাপ্রুভ করা
            $pdo->prepare("UPDATE task_submissions SET status = 'approved' WHERE id = ?")->execute([$id]);
            // ৩. মেসেজ পাঠানো
            $msg = "Your task proof has been Approved! You earned " . CURRENCY . $reward;
            $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Task Approved ✅', ?)")->execute([$sub['user_id'], $msg]);

            showAlert("Task Approved & Reward Sent!");
        } elseif ($action == 'reject') {
            // স্ট্যাটাস রিজেক্ট করা
            $pdo->prepare("UPDATE task_submissions SET status = 'rejected' WHERE id = ?")->execute([$id]);
            // মেসেজ পাঠানো
            $msg = "Your task proof was Rejected. Please follow the instructions properly.";
            $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Task Rejected ❌', ?)")->execute([$sub['user_id'], $msg]);

            showAlert("Task Rejected!", "danger");
        }
    }
}

// সব পেন্ডিং প্রুফ লিস্ট আনা
$sql = "SELECT ts.*, u.username, t.title, t.reward 
        FROM task_submissions ts 
        JOIN users u ON ts.user_id = u.id 
        JOIN tasks t ON ts.task_id = t.id 
        WHERE ts.status = 'pending' 
        ORDER BY ts.id ASC";
$submissions = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3 class="text-primary mb-4"><i class="fas fa-images"></i> Review Task Proofs</h3>

<div class="row g-3">
    <?php foreach($submissions as $s): ?>
    <div class="col-md-4 col-sm-6">
        <div class="card shadow-sm border-info h-100">
            <div class="card-header bg-info text-white d-flex justify-content-between">
                <span class="fw-bold"><?php echo htmlspecialchars($s['username']); ?></span>
                <span class="badge bg-dark"><?php echo CURRENCY . $s['reward']; ?></span>
            </div>
            
            <!-- স্ক্রিনশট ইমেজ -->
            <a href="../assets/images/proofs/<?php echo $s['proof_img']; ?>" target="_blank">
                <img src="../assets/images/proofs/<?php echo $s['proof_img']; ?>" class="card-img-top" style="height: 200px; object-fit: cover;" alt="Proof Image">
            </a>

            <div class="card-body text-center p-2">
                <p class="mb-2 fw-bold text-truncate" style="font-size: 13px;"><?php echo htmlspecialchars($s['title']); ?></p>
                <small class="text-muted d-block mb-2">Click image to view full size</small>
                
                <div class="d-flex gap-2">
                    <a href="?action=approve&id=<?php echo $s['id']; ?>" class="btn btn-success btn-sm w-50" onclick="return confirm('Approve this task?')">Approve</a>
                    <a href="?action=reject&id=<?php echo $s['id']; ?>" class="btn btn-danger btn-sm w-50" onclick="return confirm('Reject this task?')">Reject</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if(empty($submissions)) echo "<div class='col-12 text-center py-5 text-muted'><i class='fas fa-check-circle fa-3x mb-3 text-success'></i><br>No pending task proofs.</div>"; ?>
</div>

<?php require '../common/footer.php'; ?>