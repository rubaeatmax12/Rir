<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// আপডেট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // এই ডাটাগুলো সাধারণত আলাদা কনফিগ টেবিলে রাখা ভালো
    // এখানে ডেমো হিসেবে দেখাচ্ছি
    $bkash_app_key = $_POST['bkash_app_key'];
    $bkash_secret = $_POST['bkash_secret'];
    $ssl_store_id = $_POST['ssl_store_id'];
    
    // ডাটাবেসে সেভ করার কোড এখানে হবে (settings টেবিলে নতুন কলাম যোগ করে)
    // $pdo->prepare("UPDATE settings SET bkash_key=? ...")->execute([...]);
    
    showAlert("API Credentials Updated (Demo Mode)");
}

require '../common/header.php';
?>
<h3>Payment Gateway Settings (Auto Approve)</h3>
<div class="alert alert-warning">
    <strong>Note:</strong> You need valid Merchant Accounts from bKash/Nagad/SSLCommerz to use these features.
</div>

<div class="row">
    <!-- bKash Settings -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header bg-danger text-white">bKash Merchant API</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>App Key</label>
                        <input type="text" name="bkash_app_key" class="form-control" placeholder="xxxx-xxxx">
                    </div>
                    <div class="mb-3">
                        <label>App Secret</label>
                        <input type="password" name="bkash_secret" class="form-control" placeholder="****">
                    </div>
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="bkash_user" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Save bKash Config</button>
                </form>
            </div>
        </div>
    </div>

    <!-- SSLCommerz Settings -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header bg-dark text-white">SSLCommerz API</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Store ID</label>
                        <input type="text" name="ssl_store_id" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Store Password</label>
                        <input type="password" name="ssl_pass" class="form-control">
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="is_sandbox" checked>
                        <label class="form-check-label">Enable Sandbox Mode</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Save SSL Config</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require '../common/footer.php'; ?>