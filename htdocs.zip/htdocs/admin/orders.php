<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// ডেলিভারি কনফার্ম লজিক
if (isset($_GET['deliver_id'])) {
    $oid = $_GET['deliver_id'];
    
    // ১. অর্ডার ইনফো আনা (ইউজারকে মেসেজ দেওয়ার জন্য)
    $stmt = $pdo->prepare("SELECT o.*, p.title FROM product_orders o JOIN digital_products p ON o.product_id = p.id WHERE o.id = ?");
    $stmt->execute([$oid]);
    $order = $stmt->fetch();

    if ($order && $order['status'] == 'pending') {
        // ২. স্ট্যাটাস আপডেট
        $pdo->prepare("UPDATE product_orders SET status = 'delivered' WHERE id = ?")->execute([$oid]);
        
        // ৩. ইউজারকে মেসেজ পাঠানো
        $msg = "Great News! Your order for '{$order['title']}' has been processed and shipped. You will receive it soon! 🚚";
        $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Order Shipped ✅', ?)")->execute([$order['user_id'], $msg]);
        
        showAlert("Order marked as Delivered & User Notified!");
    }
}

// সব অর্ডার লিস্ট
$sql = "SELECT o.*, p.title, u.username 
        FROM product_orders o 
        JOIN digital_products p ON o.product_id = p.id 
        JOIN users u ON o.user_id = u.id 
        ORDER BY o.id DESC";
$orders = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-truck"></i> Customer Orders</h3>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Details</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($orders as $o): ?>
                    <tr>
                        <td>
                            <span class="badge bg-primary"><?php echo $o['title']; ?></span><br>
                            <small>User: <strong><?php echo $o['username']; ?></strong></small><br>
                            <small class="text-danger fw-bold">Price: <?php echo CURRENCY . $o['price']; ?></small>
                        </td>
                        <td>
                            <small><strong>Name:</strong> <?php echo $o['delivery_name']; ?></small><br>
                            <small><strong>Phone:</strong> <?php echo $o['delivery_phone']; ?></small><br>
                            <small><strong>Addr:</strong> <?php echo $o['delivery_address']; ?></small>
                        </td>
                        <td>
                            <?php if($o['status'] == 'pending'): ?>
                                <a href="?deliver_id=<?php echo $o['id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Mark as Delivered?')">
                                    Deliver <i class="fas fa-paper-plane"></i>
                                </a>
                            <?php else: ?>
                                <span class="badge bg-secondary">Completed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>