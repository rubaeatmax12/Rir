<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $amount = $_POST['amount'];
    $msg = $_POST['message'];

    // ১. লিমিট চেক করা (১০ থেকে ২০০০ টাকা)
    if ($amount < 10 || $amount > 2000) {
        showAlert("Gift amount must be between 10 to 2000 " . CURRENCY, "danger");
    } else {
        // ইউজার খুঁজে বের করা
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user) {
            try {
                // ২. ব্যালেন্স বাড়িয়ে দেওয়া
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount, $user['id']]);
                
                // ৩. গিফট হিস্ট্রিতে জমা করা
                $sql = "INSERT INTO gift_history (user_id, amount, message) VALUES (?, ?, ?)";
                $pdo->prepare($sql)->execute([$user['id'], $amount, $msg]);

                // ৪. নোটিফিকেশন পাঠানো
                $notif_msg = "You received a Gift of " . CURRENCY . $amount . " from Admin! 🎁";
                $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)")->execute([$user['id'], 'Surprise Gift! 🎉', $notif_msg]);

                showAlert("Success! Sent " . CURRENCY . "$amount to $username.");
            } catch (Exception $e) {
                showAlert("System Error: Please dont use Emojis if database is not ready.", "danger");
            }
        } else {
            showAlert("User not found!", "danger");
        }
    }
}

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow border-0">
            <div class="card-header bg-danger text-white text-center">
                <h4><i class="fas fa-gift"></i> Send Gift to User</h4>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label>Username (To whom?)</label>
                        <input type="text" name="username" class="form-control" placeholder="Ex: rubaeat22" required>
                    </div>
                    
                    <div class="mb-3">
                        <label>Amount (Limit: 10 - 2000 <?php echo CURRENCY; ?>)</label>
                        <input type="number" name="amount" class="form-control" placeholder="Ex: 100" min="10" max="2000" required>
                        <small class="text-muted">You can verify min 10 and max 2000.</small>
                    </div>
                    
                    <div class="mb-3">
                        <label>Short Message</label>
                        <input type="text" name="message" class="form-control" value="Gift from Admin ❤️" required>
                    </div>
                    
                    <button type="submit" class="btn btn-danger w-100">Send Gift Now 🎁</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>