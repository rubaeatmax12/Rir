<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

$total_users = $pdo->query("SELECT count(*) FROM users")->fetchColumn();
$pending_withdrawals = $pdo->query("SELECT count(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; padding-bottom: 50px; }
        .admin-header { background: #1a237e; color: white; padding: 15px; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; position: sticky; top: 0; z-index: 1000; }
        
        /* গোল বাটন ডিজাইন */
        .app-btn {
            width: 70px;
            height: 70px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin: 0 auto 5px auto;
            position: relative;
            color: #333;
        }
        .app-btn i { font-size: 28px; }
        .menu-text { font-size: 11px; font-weight: 600; color: #555; text-align: center; display: block; margin-bottom: 15px; }
        .notif-badge { position: absolute; top: -2px; right: -2px; background: red; color: white; width: 22px; height: 22px; border-radius: 50%; font-size: 10px; display: flex; align-items: center; justify-content: center; border: 2px solid white; }
    </style>
</head>
<body>

<div class="admin-header d-flex justify-content-between align-items-center">
    <span class="fw-bold fs-5">Admin Dashboard</span>
    <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt"></i></a>
</div>

<div class="container mt-3">
    <!-- Stats -->
    <div class="row g-2 mb-4">
        <div class="col-6">
            <div class="p-3 bg-primary text-white rounded-4 text-center">
                <h3 class="mb-0 fw-bold"><?php echo $total_users; ?></h3>
                <small>Total Users</small>
            </div>
        </div>
        <div class="col-6">
            <div class="p-3 bg-danger text-white rounded-4 text-center">
                <h3 class="mb-0 fw-bold"><?php echo $pending_withdrawals; ?></h3>
                <small>Pending WD</small>
            </div>
        </div>
    </div>

    <h6 class="text-secondary fw-bold mb-3 ps-1" style="font-size: 13px;">ACTIONS</h6>

    <!-- অ্যাকশন বাটন -->
    <div class="row">
        <!-- ডিপোজিট -->
        <div class="col-4">
            <a href="deposit_requests.php" class="text-decoration-none">
                <div class="app-btn text-success"><i class="fas fa-wallet"></i></div>
                <span class="menu-text">Deposits</span>
            </a>
        </div>
        
        <!-- উইথড্র -->
        <div class="col-4">
            <a href="withdrawals.php" class="text-decoration-none">
                <div class="app-btn text-danger">
                    <?php if($pending_withdrawals > 0): ?><div class="notif-badge"><?php echo $pending_withdrawals; ?></div><?php endif; ?>
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <span class="menu-text">Withdraw</span>
            </a>
        </div>

        <!-- অ্যাকাউন্টস -->
        <div class="col-4">
            <a href="pending_accounts.php" class="text-decoration-none">
                <div class="app-btn text-warning"><i class="fas fa-user-check"></i></div>
                <span class="menu-text">Accounts</span>
            </a>
        </div>

        <!-- সেটিংস -->
        <div class="col-4">
            <a href="settings.php" class="text-decoration-none">
                <div class="app-btn text-secondary"><i class="fas fa-cogs"></i></div>
                <span class="menu-text">Settings</span>
            </a>
        </div>

        <!-- ইউজারস -->
        <div class="col-4">
            <a href="users.php" class="text-decoration-none">
                <div class="app-btn text-primary"><i class="fas fa-users"></i></div>
                <span class="menu-text">All Users</span>
            </a>
        </div>
        
        <!-- মেসেজ -->
        <div class="col-4">
            <a href="send_message.php" class="text-decoration-none">
                <div class="app-btn text-info"><i class="fas fa-paper-plane"></i></div>
                <span class="menu-text">Message</span>
            </a>
        </div>
        
        <!-- লোন -->
        <div class="col-4">
            <a href="loans.php" class="text-decoration-none">
                <div class="app-btn text-dark"><i class="fas fa-hand-holding-usd"></i></div>
                <span class="menu-text">Loans</span>
            </a>
        </div>
        
        <!-- টিভি -->
        <div class="col-4">
            <a href="manage_tv.php" class="text-decoration-none">
                <div class="app-btn text-danger"><i class="fas fa-tv"></i></div>
                <span class="menu-text">Live TV</span>
            </a>
        </div>
        
        <!-- গিফট -->
        <div class="col-4">
            <a href="send_gift.php" class="text-decoration-none">
                <div class="app-btn text-info"><i class="fas fa-gift"></i></div>
                <span class="menu-text">Gift</span>
            </a>
        </div>

    </div>
</div>
</body>
</html>