<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// অ্যাকশন হ্যান্ডলিং (Approve/Reject)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    $stmt = $pdo->prepare("SELECT * FROM loan_requests WHERE id = ?");
    $stmt->execute([$id]);
    $loan = $stmt->fetch();

    if ($loan && $loan['status'] == 'pending') {
        if ($action == 'approve') {
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$loan['amount'], $loan['user_id']]);
            $pdo->prepare("UPDATE loan_requests SET status = 'approved' WHERE id = ?")->execute([$id]);
            
            $msg = "Your Loan of " . CURRENCY . $loan['amount'] . " is Approved! ✅";
            $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Loan Approved', ?)")->execute([$loan['user_id'], $msg]);

            showAlert("Loan Approved & Money Sent!");
        } elseif ($action == 'reject') {
            $pdo->prepare("UPDATE loan_requests SET status = 'rejected' WHERE id = ?")->execute([$id]);
            showAlert("Loan Request Rejected!", "warning");
        }
    }
}

// পেন্ডিং লোন লিস্ট আনা
$loans = $pdo->query("SELECT l.*, u.username FROM loan_requests l JOIN users u ON l.user_id = u.id WHERE l.status = 'pending' ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<h3 class="text-primary mb-4"><i class="fas fa-hand-holding-usd"></i> Verify Loan Requests</h3>

<div class="row">
    <?php if(count($loans) > 0): ?>
        <?php foreach($loans as $l): ?>
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm border-primary">
                <div class="card-header bg-light d-flex justify-content-between">
                    <strong>User: <?php echo $l['username']; ?></strong>
                    <strong class="text-success"><?php echo CURRENCY . $l['amount']; ?></strong>
                </div>
                <div class="card-body">
                    <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($l['full_name']); ?></p>
                    <p class="mb-1"><strong>Address:</strong> <?php echo htmlspecialchars($l['address']); ?></p>
                    <p class="mb-3"><strong>Reason:</strong> <?php echo htmlspecialchars($l['reason']); ?></p>
                    
                    <div class="d-flex justify-content-center gap-3 mb-3">
                        <div class="text-center">
                            <a href="../assets/images/loans/<?php echo $l['nid_front']; ?>" target="_blank">
                                <img src="../assets/images/loans/<?php echo $l['nid_front']; ?>" width="100" class="border rounded">
                            </a>
                            <br><small>Front</small>
                        </div>
                        <div class="text-center">
                            <a href="../assets/images/loans/<?php echo $l['nid_back']; ?>" target="_blank">
                                <img src="../assets/images/loans/<?php echo $l['nid_back']; ?>" width="100" class="border rounded">
                            </a>
                            <br><small>Back</small>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <a href="?action=approve&id=<?php echo $l['id']; ?>" class="btn btn-success w-100" onclick="return confirm('Documents Verified? Give Loan?')">Approve</a>
                        <a href="?action=reject&id=<?php echo $l['id']; ?>" class="btn btn-danger w-100" onclick="return confirm('Reject this request?')">Reject</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="col-12 text-center py-5 text-muted">
            <i class="fas fa-check-circle fa-3x mb-3 text-success"></i><br>
            No pending loan requests.
        </div>
    <?php endif; ?>
</div>

<?php require '../common/footer.php'; ?>