<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

// নতুন টাস্ক এড করা
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_task'])) {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $link = $_POST['link'];
    $reward = $_POST['reward'];
    $type = $_POST['type'];

    $sql = "INSERT INTO tasks (title, description, link, reward, type) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$title, $desc, $link, $reward, $type]);
    $msg = "New Task Created Successfully!";
}

// টাস্ক ডিলিট করা
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM tasks WHERE id = ?")->execute([$id]);
    header("Location: tasks.php");
    exit;
}

// সব টাস্ক ফেচ করা
$tasks = $pdo->query("SELECT * FROM tasks ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3 class="mb-4">Manage Tasks</h3>

<!-- Add Task Form -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white">Add New Task</div>
    <div class="card-body">
        <?php if(isset($msg)) showAlert($msg); ?>
        <form method="POST">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Task Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Task Type</label>
                    <select name="type" class="form-control">
                        <option value="website">Website Visit</option>
                        <option value="video">Video Watch</option>
                        <option value="social">Social Media Like/Follow</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Link/URL</label>
                    <input type="url" name="link" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Reward Amount (<?php echo CURRENCY; ?>)</label>
                    <input type="number" step="0.01" name="reward" class="form-control" required>
                </div>
                <div class="col-md-12 mb-3">
                    <label>Description/Instructions</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
            </div>
            <button type="submit" name="add_task" class="btn btn-success">Create Task</button>
        </form>
    </div>
</div>

<!-- Task List -->
<div class="card">
    <div class="card-header">All Tasks</div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Reward</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($tasks as $t): ?>
                <tr>
                    <td><?php echo $t['id']; ?></td>
                    <td><?php echo $t['title']; ?></td>
                    <td><span class="badge bg-info"><?php echo ucfirst($t['type']); ?></span></td>
                    <td><?php echo $t['reward']; ?></td>
                    <td>
                        <a href="?delete=<?php echo $t['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require '../common/footer.php'; ?>