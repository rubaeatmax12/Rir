<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// ভিডিও আপলোড
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $vid_name = time() . "_" . $_FILES['video_file']['name'];
    $target = "../assets/videos/" . $vid_name;
    
    if (!is_dir('../assets/videos')) mkdir('../assets/videos', 0777, true);
    
    if (move_uploaded_file($_FILES['video_file']['tmp_name'], $target)) {
        $pdo->prepare("INSERT INTO app_videos (user_id, title, video_file) VALUES (?, ?, ?)")->execute([$_SESSION['user_id'], $title, $vid_name]);
        showAlert("Admin Video Uploaded!");
    }
}

// ভিডিও ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM app_videos WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: manage_videos.php");
}

$videos = $pdo->query("SELECT * FROM app_videos ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3><i class="fas fa-video"></i> Manage Videos</h3>

<div class="card mb-4 p-3 shadow-sm">
    <h5>Upload Official Video</h5>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="title" class="form-control mb-2" placeholder="Title" required>
        <input type="file" name="video_file" class="form-control mb-2" accept="video/mp4" required>
        <button class="btn btn-danger w-100">Upload Video</button>
    </form>
</div>

<div class="row">
    <?php foreach($videos as $v): ?>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <video src="../assets/videos/<?php echo $v['video_file']; ?>" class="card-img-top" controls style="height: 200px; background:black;"></video>
            <div class="card-body">
                <h6><?php echo $v['title']; ?></h6>
                <a href="?delete=<?php echo $v['id']; ?>" class="btn btn-sm btn-danger w-100" onclick="return confirm('Delete video?')">Delete</a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>