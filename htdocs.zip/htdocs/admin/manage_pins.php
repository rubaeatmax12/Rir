<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// পিন আপডেট লজিক
if (isset($_POST['update_pin'])) {
    $uid = $_POST['user_id'];
    $new_pin = $_POST['pin'];
    
    // পিন অবশ্যই ৪ সংখ্যার হতে হবে
    if(strlen($new_pin) == 4 && is_numeric($new_pin)) {
        $pdo->prepare("UPDATE users SET security_pin = ? WHERE id = ?")->execute([$new_pin, $uid]);
        showAlert("User PIN Updated Successfully!");
    } else {
        showAlert("PIN must be 4 digits!", "danger");
    }
}

// সার্চ লজিক
$search = $_GET['search'] ?? '';
$sql = "SELECT id, username, email, security_pin FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 50";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$search%", "%$search%"]);
$users = $stmt->fetchAll();

require '../common/header.php';
?>

<h3 class="text-center mb-4 text-dark"><i class="fas fa-user-lock"></i> Manage User PINs</h3>

<!-- সার্চ বক্স -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="search" class="form-control" placeholder="Search by Username or Email..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
        </form>
    </div>
</div>

<!-- ইউজার লিস্ট -->
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>User</th>
                        <th>Current PIN</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($users) > 0): ?>
                        <?php foreach($users as $u): ?>
                        <tr>
                            <td>
                                <strong><?php echo $u['username']; ?></strong><br>
                                <small class="text-muted"><?php echo $u['email']; ?></small>
                            </td>
                            
                            <!-- পিন এডিট করার ফর্ম -->
                            <form method="POST">
                                <td>
                                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                    <input type="text" name="pin" class="form-control text-center fw-bold text-danger" 
                                           value="<?php echo $u['security_pin'] ?? 'Not Set'; ?>" 
                                           style="width: 100px;" maxlength="4">
                                </td>
                                <td>
                                    <button type="submit" name="update_pin" class="btn btn-sm btn-success">
                                        <i class="fas fa-save"></i> Save
                                    </button>
                                </td>
                            </form>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center py-5 text-muted">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>