<?php
// tasks.php এর কোডই ব্যবহার হবে, শুধু কুয়েরি ফিল্টার হবে
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// Delete logic same as tasks.php...

// Fetch Only Video Tasks
$tasks = $pdo->query("SELECT * FROM tasks WHERE type = 'video' ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>
<h3>Manage Video Tasks</h3>
<a href="tasks.php" class="btn btn-primary mb-3">Add New Task</a>
<!-- Table displaying only video tasks -->
<table class="table table-bordered">
    <thead><tr><th>Title</th><th>Link</th><th>Reward</th><th>Action</th></tr></thead>
    <tbody>
        <?php foreach($tasks as $t): ?>
        <tr>
            <td><?php echo $t['title']; ?></td>
            <td><a href="<?php echo $t['link']; ?>" target="_blank">View Video</a></td>
            <td><?php echo $t['reward']; ?></td>
            <td><a href="tasks.php?delete=<?php echo $t['id']; ?>" class="btn btn-danger btn-sm">Delete</a></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php require '../common/footer.php'; ?>