<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// টাকা কেটে নেওয়ার লজিক
if (isset($_POST['repay_loan'])) {
    $loan_id = $_POST['loan_id'];
    $user_id = $_POST['user_id'];
    $amount = $_POST['amount'];

    // ইউজারের বর্তমান ব্যালেন্স চেক করা
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $current_balance = $stmt->fetchColumn();

    if ($current_balance >= $amount) {
        // ১. টাকা কেটে নেওয়া
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $user_id]);
        
        // ২. লোনের স্ট্যাটাস 'repaid' করে দেওয়া
        $pdo->prepare("UPDATE loan_requests SET status = 'repaid' WHERE id = ?")->execute([$loan_id]);

        // ৩. ইউজারকে মেসেজ পাঠানো
        $msg = "Dear User, your loan of " . CURRENCY . $amount . " has been successfully repaid from your account balance. Thank you!";
        $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'Loan Repaid ✅', ?)")->execute([$user_id, $msg]);

        showAlert("Success! Loan recovered from user account.");
    } else {
        showAlert("Failed! User does not have enough balance to pay back.", "danger");
    }
}

// যারা লোন নিয়েছে এবং এখনো শোধ করেনি (Approved status)
$sql = "SELECT l.*, u.username, u.balance as user_balance 
        FROM loan_requests l 
        JOIN users u ON l.user_id = u.id 
        WHERE l.status = 'approved' 
        ORDER BY l.id DESC";
$active_loans = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3 class="text-danger mb-4"><i class="fas fa-sack-dollar"></i> Active Loans (Recovery)</h3>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>User</th>
                        <th>Loan Amount</th>
                        <th>User Balance</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($active_loans) > 0): ?>
                        <?php foreach($active_loans as $l): ?>
                        <tr>
                            <td>
                                <span class="fw-bold"><?php echo htmlspecialchars($l['username']); ?></span>
                            </td>
                            <td class="fw-bold text-danger">
                                <?php echo CURRENCY . $l['amount']; ?>
                            </td>
                            <td>
                                <!-- ইউজারের বর্তমান ব্যালেন্স -->
                                <?php if($l['user_balance'] >= $l['amount']): ?>
                                    <span class="badge bg-success">Has: <?php echo CURRENCY . $l['user_balance']; ?></span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Low: <?php echo CURRENCY . $l['user_balance']; ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Are you sure you want to deduct money from this user?');">
                                    <input type="hidden" name="loan_id" value="<?php echo $l['id']; ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $l['user_id']; ?>">
                                    <input type="hidden" name="amount" value="<?php echo $l['amount']; ?>">
                                    
                                    <?php if($l['user_balance'] >= $l['amount']): ?>
                                        <button type="submit" name="repay_loan" class="btn btn-sm btn-danger">
                                            <i class="fas fa-cut"></i> Cut Money
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-secondary" disabled>
                                            Not Enough Money
                                        </button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-muted">
                                <i class="fas fa-check-circle fa-3x mb-3 text-success"></i><br>
                                No active loans found. Everyone paid!
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>