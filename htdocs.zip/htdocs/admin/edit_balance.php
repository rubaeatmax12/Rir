<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

$user = null;

// ১. ইউজার খোঁজা
if (isset($_POST['search_user'])) {
    $username = trim($_POST['username']);
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();
    
    if (!$user) showAlert("User not found!", "danger");
}

// ২. ব্যালেন্স আপডেট করা
if (isset($_POST['update_balance'])) {
    $uid = $_POST['user_id'];
    $amount = $_POST['amount'];
    $action = $_POST['action']; // add or cut
    $reason = $_POST['reason'];

    // ইউজার ইনফো আবার আনা
    $stmt = $pdo->prepare("SELECT username, balance FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $u_info = $stmt->fetch();

    if ($action == 'add') {
        // টাকা যোগ করা
        $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount, $uid]);
        $msg_type = "Added";
        $icon = "💰 Money Added";
    } else {
        // টাকা কেটে নেওয়া
        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$amount, $uid]);
        $msg_type = "Deducted";
        $icon = "⚠️ Money Deducted";
    }

    // ইউজারকে নোটিফিকেশন পাঠানো
    $notif = "Admin has $msg_type " . CURRENCY . "$amount from your account. Reason: $reason";
    $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)")->execute([$uid, $icon, $notif]);

    showAlert("Success! Balance Updated.");
}

require '../common/header.php';
?>

<h3><i class="fas fa-edit"></i> Edit User Balance</h3>

<!-- ইউজার সার্চ ফর্ম -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="POST" class="d-flex gap-2">
            <input type="text" name="username" class="form-control" placeholder="Enter Username or Email" required>
            <button type="submit" name="search_user" class="btn btn-dark">Search</button>
        </form>
    </div>
</div>

<?php if ($user): ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card border-primary shadow">
            <div class="card-header bg-primary text-white text-center">
                <h5><?php echo $user['username']; ?></h5>
                <small><?php echo $user['email']; ?></small>
            </div>
            <div class="card-body text-center">
                <h2 class="text-primary fw-bold mb-4">
                    Current Balance: <?php echo CURRENCY . number_format($user['balance'], 2); ?>
                </h2>

                <form method="POST">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    
                    <div class="mb-3 text-start">
                        <label>Action</label>
                        <select name="action" class="form-select">
                            <option value="add">➕ Add Money (Gift/Bonus)</option>
                            <option value="cut">➖ Cut Money (Penalty/Fine)</option>
                        </select>
                    </div>

                    <div class="mb-3 text-start">
                        <label>Amount</label>
                        <input type="number" name="amount" class="form-control" placeholder="Ex: 50" required>
                    </div>

                    <div class="mb-3 text-start">
                        <label>Reason (User will see this)</label>
                        <input type="text" name="reason" class="form-control" placeholder="Ex: Winning Bonus / Fake Work" required>
                    </div>

                    <button type="submit" name="update_balance" class="btn btn-success w-100">Update Balance</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require '../common/footer.php'; ?>