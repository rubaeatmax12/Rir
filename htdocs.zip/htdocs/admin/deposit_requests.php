<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

// Handle Approve/Reject
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action']; // 'approved' or 'rejected'
    
    // Get deposit info
    $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ?");
    $stmt->execute([$id]);
    $deposit = $stmt->fetch();

    if ($deposit['status'] == 'pending') {
        if ($action == 'approved') {
            // Update Deposit Status
            $pdo->prepare("UPDATE deposits SET status = 'approved' WHERE id = ?")->execute([$id]);
            // Add Balance to User
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$deposit['amount'], $deposit['user_id']]);
            showAlert("Deposit Approved and Balance Added!");
        } elseif ($action == 'rejected') {
            $pdo->prepare("UPDATE deposits SET status = 'rejected' WHERE id = ?")->execute([$id]);
            showAlert("Deposit Rejected!", "warning");
        }
    }
}

// Fetch Pending Lists
$stmt = $pdo->query("SELECT deposits.*, users.username FROM deposits JOIN users ON deposits.user_id = users.id WHERE deposits.status = 'pending' ORDER BY id DESC");
$requests = $stmt->fetchAll();

require '../common/header.php';
?>
<h3>Pending Deposits</h3>
<table class="table table-bordered bg-white">
    <thead>
        <tr>
            <th>User</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Trx ID</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($requests as $r): ?>
        <tr>
            <td><?php echo $r['username']; ?></td>
            <td><?php echo $r['amount']; ?></td>
            <td><?php echo $r['method']; ?> (<?php echo $r['sender_number']; ?>)</td>
            <td><?php echo $r['trx_id']; ?></td>
            <td>
                <a href="?action=approved&id=<?php echo $r['id']; ?>" class="btn btn-success btn-sm">Approve</a>
                <a href="?action=rejected&id=<?php echo $r['id']; ?>" class="btn btn-danger btn-sm">Reject</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php require '../common/footer.php'; ?>