<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// অ্যাপ অ্যাড করা
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['app_name'];
    $platform = $_POST['platform'];
    $version = $_POST['version'];
    $type = $_POST['link_type'];
    
    // আইকন আপলোড
    $icon_name = time() . "_icon_" . $_FILES['icon']['name'];
    move_uploaded_file($_FILES['icon']['tmp_name'], "../assets/images/" . $icon_name);
    
    $final_link = "";

    if ($type == 'file') {
        // ফাইল আপলোড (APK)
        $file_name = time() . "_app_" . $_FILES['app_file']['name'];
        $target = "../assets/files/" . $file_name;
        if (!is_dir('../assets/files')) mkdir('../assets/files', 0777, true);
        
        if (move_uploaded_file($_FILES['app_file']['tmp_name'], $target)) {
            $final_link = $file_name;
        } else {
            showAlert("File upload failed! File might be too large.", "danger");
        }
    } else {
        // লিংক
        $final_link = $_POST['app_link'];
    }

    if ($final_link) {
        $sql = "INSERT INTO app_downloads (app_name, platform, version, icon, download_link, link_type) VALUES (?, ?, ?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([$name, $platform, $version, $icon_name, $final_link, $type]);
        showAlert("App Added Successfully!");
    }
}

// অ্যাপ ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM app_downloads WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: upload_app.php");
}

$apps = $pdo->query("SELECT * FROM app_downloads ORDER BY id DESC")->fetchAll();
require '../common/header.php';
?>

<h3><i class="fab fa-android text-success"></i> Manage App Downloads</h3>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-6 mb-3">
                    <label>App Name</label>
                    <input type="text" name="app_name" class="form-control" placeholder="Ex: Alpha Earner Pro" required>
                </div>
                <div class="col-6 mb-3">
                    <label>Version</label>
                    <input type="text" name="version" class="form-control" placeholder="v1.0" required>
                </div>
                <div class="col-6 mb-3">
                    <label>Platform</label>
                    <select name="platform" class="form-control">
                        <option value="Android">Android (APK)</option>
                        <option value="iOS">iOS (iPhone)</option>
                    </select>
                </div>
                <div class="col-6 mb-3">
                    <label>Upload Type</label>
                    <select name="link_type" class="form-control" onchange="toggleType(this.value)">
                        <option value="url">Direct Link (Drive/PlayStore)</option>
                        <option value="file">Upload File (Max 10MB)</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label>App Icon</label>
                <input type="file" name="icon" class="form-control" required>
            </div>

            <div class="mb-3" id="urlInput">
                <label>Download Link</label>
                <input type="url" name="app_link" class="form-control" placeholder="https://...">
            </div>

            <div class="mb-3" id="fileInput" style="display:none;">
                <label>Upload APK File</label>
                <input type="file" name="app_file" class="form-control">
            </div>

            <button type="submit" class="btn btn-success w-100">Add App</button>
        </form>
    </div>
</div>

<div class="row">
    <?php foreach($apps as $app): ?>
    <div class="col-md-6 mb-3">
        <div class="card p-2">
            <div class="d-flex align-items-center">
                <img src="../assets/images/<?php echo $app['icon']; ?>" width="50" class="rounded me-3">
                <div>
                    <h6 class="mb-0 fw-bold"><?php echo $app['app_name']; ?> <span class="badge bg-secondary"><?php echo $app['version']; ?></span></h6>
                    <small class="<?php echo $app['platform']=='Android'?'text-success':'text-dark'; ?>">
                        <i class="fab fa-<?php echo strtolower($app['platform']); ?>"></i> <?php echo $app['platform']; ?>
                    </small>
                </div>
                <a href="?delete=<?php echo $app['id']; ?>" class="btn btn-sm btn-outline-danger ms-auto" onclick="return confirm('Delete?')">
                    <i class="fas fa-trash"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<script>
function toggleType(val) {
    if(val == 'file') {
        document.getElementById('urlInput').style.display = 'none';
        document.getElementById('fileInput').style.display = 'block';
    } else {
        document.getElementById('urlInput').style.display = 'block';
        document.getElementById('fileInput').style.display = 'none';
    }
}
</script>

<?php require '../common/footer.php'; ?>