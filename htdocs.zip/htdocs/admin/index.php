<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

$pending_tasks = $pdo->query("SELECT count(*) FROM task_submissions WHERE status='pending'")->fetchColumn();

// ডাটা গণনা
$total_users = $pdo->query("SELECT count(*) FROM users")->fetchColumn();
$pending_withdrawals = $pdo->query("SELECT count(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; padding-bottom: 50px; }
        .admin-header { background: #1a237e; color: white; padding: 15px; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 1000; }
        .app-btn { background: white; border-radius: 12px; padding: 10px; text-align: center; display: block; text-decoration: none; color: #333; box-shadow: 0 2px 5px rgba(0,0,0,0.05); height: 90px; display: flex; flex-direction: column; justify-content: center; align-items: center; position: relative; border: 1px solid #eee; transition: 0.2s; }
        .app-btn:active { transform: scale(0.95); }
        .app-btn i { font-size: 24px; margin-bottom: 5px; display: block; }
        .app-btn h6 { font-size: 10px; font-weight: 600; margin: 0; }
    </style>
</head>
<body>

<div class="admin-header d-flex justify-content-between align-items-center">
    <span class="fw-bold fs-5">Admin Dashboard</span>
    <a href="../logout.php" class="text-white"><i class="fas fa-sign-out-alt"></i></a>
</div>

<div class="container mt-3">
    
    <!-- Stats -->
    <div class="row g-2 mb-4">
        <div class="col-6">
            <div class="p-3 bg-primary text-white rounded-3 text-center">
                <h3 class="mb-0 fw-bold"><?php echo $total_users; ?></h3>
                <small style="font-size: 10px;">Total Users</small>
            </div>
        </div>
        <div class="col-6">
            <div class="p-3 bg-danger text-white rounded-3 text-center">
                <h3 class="mb-0 fw-bold"><?php echo $pending_withdrawals; ?></h3>
                <small style="font-size: 10px;">Withdrawals</small>
            </div>
        </div>
    </div>

    <h6 class="text-secondary fw-bold mb-2 ps-1" style="font-size: 12px;">PENDING ACTIONS</h6>

    <!-- অ্যাকশন বাটন -->
    <div class="row g-2">
        <div class="col-4"><a href="deposit_requests.php" class="app-btn"><i class="fas fa-wallet text-success"></i><h6>Deposits</h6></a></div>
        <div class="col-4"><a href="withdrawals.php" class="app-btn"><i class="fas fa-hand-holding-usd text-danger"></i><h6>Withdraw</h6></a></div>
        <div class="col-4"><a href="pending_accounts.php" class="app-btn"><i class="fas fa-user-check text-warning"></i><h6>Accounts</h6></a></div>
        <div class="col-4"><a href="loans.php" class="app-btn"><i class="fas fa-hand-holding-usd text-info"></i><h6>Loan Req</h6></a></div>
        <div class="col-4"><a href="active_loans.php" class="app-btn"><i class="fas fa-money-check-alt text-danger"></i><h6>Recover</h6></a></div>
        <div class="col-4"><a href="product_requests.php" class="app-btn"><i class="fas fa-check-double text-success"></i><h6>Approve Prod</h6></a></div>
        <div class="col-4"><a href="orders.php" class="app-btn"><i class="fas fa-box-open text-warning"></i><h6>Orders</h6></a></div>
    </div>

    <h6 class="text-secondary fw-bold mb-2 ps-1 mt-3" style="font-size: 12px;">MANAGEMENT</h6>

    <div class="row g-2">
        <div class="col-4"><a href="send_gift.php" class="app-btn"><i class="fas fa-gift text-info"></i><h6>Send Gift</h6></a></div>
        <div class="col-4"><a href="send_message.php" class="app-btn"><i class="fas fa-paper-plane text-primary"></i><h6>Message</h6></a></div>
        <div class="col-4"><a href="support.php" class="app-btn"><i class="fas fa-headset text-secondary"></i><h6>Support</h6></a></div>
        <div class="col-4"><a href="global_notification.php" class="app-btn"><i class="fas fa-bullhorn text-warning"></i><h6>Global Notice</h6></a></div>
        <div class="col-4"><a href="edit_balance.php" class="app-btn"><i class="fas fa-sliders-h text-dark"></i><h6>Edit Bal</h6></a></div>
        <div class="col-4"><a href="app_control.php" class="app-btn"><i class="fas fa-power-off text-danger"></i><h6>System</h6></a></div>
        <div class="col-4"><a href="promo_codes.php" class="app-btn"><i class="fas fa-ticket-alt text-dark"></i><h6>Promo</h6></a></div>
        <div class="col-4"><a href="add_product.php" class="app-btn"><i class="fas fa-cloud-upload-alt text-warning"></i><h6>Products</h6></a></div>
        <div class="col-4"><a href="manage_videos.php" class="app-btn"><i class="fas fa-video text-danger"></i><h6>Videos</h6></a></div>
        <div class="col-4"><a href="affiliate_admin.php" class="app-btn"><i class="fas fa-bullhorn text-primary"></i><h6>Affiliate</h6></a></div>
        <div class="col-4"><a href="manage_tv.php" class="app-btn"><i class="fas fa-tv text-danger"></i><h6>Live TV</h6></a></div>
        <div class="col-4"><a href="verify_user.php" class="app-btn"><i class="fas fa-check-circle text-primary"></i><h6>Verify User</h6></a></div>
        <div class="col-4"><a href="tasks.php" class="app-btn"><i class="fas fa-tasks text-success"></i><h6>Tasks</h6></a></div>
        <div class="col-4"><a href="settings.php" class="app-btn"><i class="fas fa-cogs text-secondary"></i><h6>Settings</h6></a></div>
        <div class="col-4"><a href="deposit_settings.php" class="app-btn"><i class="fas fa-mobile-alt text-info"></i><h6>Pay Num</h6></a></div>
        <div class="col-4"><a href="transfer_logs.php" class="app-btn"><i class="fas fa-history text-danger"></i><h6>Transfers</h6></a></div>
        <div class="col-4"><a href="../user/public_chat.php" class="app-btn"><i class="fas fa-comments text-primary"></i><h6>Chat Room</h6></a></div>
        <div class="col-4"><a href="users.php" class="app-btn"><i class="fas fa-users text-primary"></i><h6>All Users</h6></a></div>
    </div>
   <div class="col-4">

    <a href="account_history.php" class="app-btn">

        <i class="fas fa-folder-open text-primary"></i>

        <h6>Acc History</h6>

    </a>
       <div class="col-4">
    <a href="weekly_notes.php" class="app-btn">
        <i class="fas fa-sticky-note text-warning"></i>
        <h6>Notes</h6>
    </a>
</div>
       <div class="col-4">
    <a href="manage_cards.php" class="app-btn">
        <i class="fas fa-credit-card text-secondary"></i>
        <h6>User Cards</h6>
    </a>
           <div class="col-4">
    <a href="my_vault.php" class="app-btn">
        <i class="fas fa-user-secret text-dark"></i>
        <h6>Admin Vault</h6>
    </a>
</div>
     
</div><div class="col-4">
    <a href="theme_control.php" class="app-btn">
        <i class="fas fa-palette text-warning"></i>
        <h6>Design</h6>
    </a>
       <div class="col-4">
    <a href="manage_pins.php" class="app-btn">
        <i class="fas fa-key text-dark"></i>
        <h6>User PINs</h6>
    </a>
</div>
       <div class="col-4">
    <a href="manage_notices.php" class="app-btn">
        <i class="fas fa-bullhorn text-danger"></i>
        <h6>Notices</h6>
    </a>
           <div class="col-4">
    <a href="backup_code.php" class="app-btn">
        <i class="fas fa-file-code text-primary"></i>
        <h6>Source Code</h6>
    </a>
</div>
</div>
    <div class="col-4">
    <a href="backup_db.php" class="app-btn">
        <i class="fas fa-database text-success"></i>
        <h6>Backup DB</h6>
    </a>
</div>
</div>
     <div class="col-4">
    <a href="manage_ads.php" class="app-btn">
        <i class="fas fa-ad text-success"></i>
        <h6>PTC Ads</h6>
    </a>
</div>
       <div class="col-4">
    <a href="manage_buttons.php" class="app-btn">
        <i class="fas fa-th-large text-primary"></i>
        <h6>Buttons</h6>
    </a>
</div>
       
<div class="col-4">
    <a href="add_tutorial.php" class="app-btn">
        <i class="fab fa-youtube text-danger"></i>
        <h6>Tutorials</h6>
    </a>
    <div class="col-4">
    <a href="report.php" class="app-btn">
        <i class="fas fa-chart-line text-success"></i>
        <h6>Reports</h6>
    </a>
        <div class="col-4">
    <a href="upload_app.php" class="app-btn">
        <i class="fab fa-google-play text-success"></i>
        <h6>Upload App</h6>
    </a>
      <div class="col-4">
    <a href="manage_tutorials.php" class="app-btn">
        <i class="fab fa-youtube text-danger"></i>
        <h6>Tutorials</h6>
    </a>
</div>
   <div class="col-4">
    <a href="javascript:location.reload();" class="app-btn">
        <i class="fas fa-sync-alt text-success"></i>
        <h6>Refresh</h6>
    </a>
    <div class="col-4">
    <a href="app_link_settings.php" class="app-btn">
        <div class="col-4">
    <a href="manage_tutorials.php" class="app-btn">
        <i class="fab fa-youtube text-danger"></i>
        <h6>Tutorials</h6>
    </a>
</div>
        <i class="fab fa-android text-success"></i>
        <h6>App Link</h6>
    </a>
      <div class="col-4">
    <a href="submissions.php" class="app-btn">

        <?php if($pending_tasks > 0): ?>
        <div class="notif-badge">
            <?php echo $pending_tasks; ?>
        </div>
        <?php endif; ?>

        <i class="fas fa-image text-info"></i>
        <h6>Task Proofs</h6>

    </a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</body>
</html>