<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// নোটিশ পোস্ট করা
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $message = $_POST['message'];
    
    if(!empty($title) && !empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO app_notices (title, message) VALUES (?, ?)");
        $stmt->execute([$title, $message]);
        showAlert("Notice Posted Successfully!");
    }
}

// নোটিশ ডিলিট করা
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM app_notices WHERE id = ?")->execute([$id]);
    header("Location: manage_notices.php");
}

// সব নোটিশ আনা
$notices = $pdo->query("SELECT * FROM app_notices ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-bullhorn"></i> Manage App Notices</h3>

<!-- নোটিশ লেখার বক্স -->
<div class="card shadow-sm mb-4">
    <div class="card-header bg-primary text-white">Post New Notice</div>
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label>Notice Title</label>
                <input type="text" name="title" class="form-control" placeholder="Ex: Eid Mubarak / Server Update" required>
            </div>
            <div class="mb-3">
                <label>Details</label>
                <textarea name="message" class="form-control" rows="4" placeholder="Write details here..." required></textarea>
            </div>
            <button type="submit" class="btn btn-success w-100">Publish Notice 📢</button>
        </form>
    </div>
</div>

<!-- নোটিশ লিস্ট -->
<h5 class="text-secondary">Previous Notices</h5>
<div class="list-group">
    <?php foreach($notices as $n): ?>
    <div class="list-group-item list-group-item-action flex-column align-items-start">
        <div class="d-flex w-100 justify-content-between">
            <h5 class="mb-1 text-primary"><?php echo htmlspecialchars($n['title']); ?></h5>
            <small class="text-muted"><?php echo date('d M, h:i A', strtotime($n['created_at'])); ?></small>
        </div>
        <p class="mb-1"><?php echo nl2br(htmlspecialchars($n['message'])); ?></p>
        <a href="?delete=<?php echo $n['id']; ?>" class="btn btn-sm btn-outline-danger mt-2" onclick="return confirm('Delete this notice?')">Delete</a>
    </div>
    <?php endforeach; ?>
    
    <?php if(empty($notices)) echo "<p class='text-center py-3'>No notices posted yet.</p>"; ?>
</div>

<?php require '../common/footer.php'; ?>