<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

// স্যালারি পেমেন্ট হ্যান্ডলিং
if (isset($_POST['pay_salary'])) {
    $uid = $_POST['user_id'];
    $amount = $_POST['amount'];
    
    // ব্যালেন্স অ্যাড
    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amount, $uid]);
    showAlert("Salary Paid: " . CURRENCY . $amount);
}

// সবচেয়ে বেশি রেফার করেছে এমন ইউজাররা
$sql = "SELECT u.id, u.username, COUNT(r.id) as total_refs 
        FROM users u 
        JOIN users r ON u.id = r.referrer_id 
        GROUP BY u.id 
        ORDER BY total_refs DESC 
        LIMIT 10";
$performers = $pdo->query($sql)->fetchAll();

require '../common/header.php';
?>

<h3>Top Performers (Based on Referrals)</h3>
<p>You can pay monthly salary manually from here.</p>

<table class="table table-bordered bg-white">
    <thead>
        <tr>
            <th>Rank</th>
            <th>Username</th>
            <th>Total Referrals</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($performers as $index => $p): ?>
        <tr>
            <td>#<?php echo $index + 1; ?></td>
            <td><?php echo $p['username']; ?></td>
            <td><?php echo $p['total_refs']; ?> Members</td>
            <td>
                <form method="POST" class="d-flex">
                    <input type="hidden" name="user_id" value="<?php echo $p['id']; ?>">
                    <input type="number" name="amount" class="form-control form-control-sm me-2" placeholder="Amount" style="width: 100px;" required>
                    <button type="submit" name="pay_salary" class="btn btn-success btn-sm">Pay Salary</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require '../common/footer.php'; ?>