<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// আপডেট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $color = $_POST['theme_color'];
    $bg = $_POST['body_bg'];
    $shape = $_POST['btn_shape'];

    $pdo->prepare("UPDATE settings SET theme_color=?, body_bg=?, btn_shape=?")->execute([$color, $bg, $shape]);
    showAlert("App Design Updated Successfully! 🎉");
}

$s = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();

require '../common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-lg border-0">
            <div class="card-header text-white text-center" style="background: <?php echo $s['theme_color']; ?>;">
                <h4><i class="fas fa-palette"></i> App Design Control</h4>
            </div>
            <div class="card-body">
                
                <!-- লাইভ প্রিভিউ -->
                <div class="text-center mb-4 p-3 border rounded" style="background: <?php echo $s['body_bg']; ?>;">
                    <p class="text-muted">Live Preview Button</p>
                    <div style="
                        width: 60px; height: 60px; 
                        background: white; 
                        border-radius: <?php echo $s['btn_shape']; ?>; 
                        display: inline-flex; align-items: center; justify-content: center;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                        border: 2px solid <?php echo $s['theme_color']; ?>;">
                        <i class="fas fa-home fa-2x" style="color: <?php echo $s['theme_color']; ?>;"></i>
                    </div>
                </div>

                <form method="POST">
                    
                    <!-- ১. মেইন কালার -->
                    <div class="mb-3">
                        <label class="fw-bold">App Main Color (Header & Icons)</label>
                        <input type="color" name="theme_color" class="form-control form-control-color w-100" value="<?php echo $s['theme_color']; ?>">
                    </div>

                    <!-- ২. ব্যাকগ্রাউন্ড কালার -->
                    <div class="mb-3">
                        <label class="fw-bold">Background Color</label>
                        <input type="color" name="body_bg" class="form-control form-control-color w-100" value="<?php echo $s['body_bg']; ?>">
                    </div>

                    <!-- ৩. বাটন স্টাইল -->
                    <div class="mb-4">
                        <label class="fw-bold">Button Shape</label>
                        <select name="btn_shape" class="form-select">
                            <option value="50%" <?php if($s['btn_shape']=='50%') echo 'selected'; ?>>🟡 Circle (গোল)</option>
                            <option value="15px" <?php if($s['btn_shape']=='15px') echo 'selected'; ?>>🔲 Rounded (রাউন্ডেড)</option>
                            <option value="0px" <?php if($s['btn_shape']=='0px') echo 'selected'; ?>>⬛ Square (চারকোনা)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-dark w-100 btn-lg">Update Design 🎨</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require '../common/footer.php'; ?>