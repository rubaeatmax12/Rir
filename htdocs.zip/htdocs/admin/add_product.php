<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $desc = $_POST['description'];

    // ১. ছবি আপলোড
    $img_name = time() . "_" . $_FILES['image']['name'];
    $img_target = "../assets/images/products/" . $img_name;
    
    // ২. ফাইল (PDF/Zip) আপলোড
    $file_name = time() . "_" . $_FILES['file']['name'];
    $file_target = "../assets/files/" . $file_name;

    // ফোল্ডার না থাকলে তৈরি করা
    if (!is_dir('../assets/images/products')) mkdir('../assets/images/products', 0777, true);
    if (!is_dir('../assets/files')) mkdir('../assets/files', 0777, true);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $img_target) && move_uploaded_file($_FILES['file']['tmp_name'], $file_target)) {
        $sql = "INSERT INTO digital_products (title, description, price, image, file_path) VALUES (?, ?, ?, ?, ?)";
        $pdo->prepare($sql)->execute([$title, $desc, $price, $img_name, $file_name]);
        showAlert("Product Uploaded Successfully!");
    } else {
        showAlert("File upload failed!", "danger");
    }
}

// প্রোডাক্ট ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM digital_products WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: add_product.php");
}

$products = $pdo->query("SELECT * FROM digital_products ORDER BY id DESC")->fetchAll();

require '../common/header.php';
?>

<h3><i class="fas fa-cloud-upload-alt"></i> Digital Products</h3>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Product Title</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Price (<?php echo CURRENCY; ?>)</label>
                <input type="number" name="price" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <div class="mb-3">
                <label>Cover Image (JPG/PNG)</label>
                <input type="file" name="image" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Main File (PDF/ZIP)</label>
                <input type="file" name="file" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Upload Product</button>
        </form>
    </div>
</div>

<!-- প্রোডাক্ট লিস্ট -->
<div class="row">
    <?php foreach($products as $p): ?>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <img src="../assets/images/products/<?php echo $p['image']; ?>" class="card-img-top" style="height: 150px; object-fit: cover;">
            <div class="card-body">
                <h5><?php echo $p['title']; ?></h5>
                <p class="text-danger fw-bold"><?php echo CURRENCY . $p['price']; ?></p>
                <a href="?delete=<?php echo $p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php require '../common/footer.php'; ?>