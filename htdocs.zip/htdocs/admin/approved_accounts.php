<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin(); checkAdmin();

// অ্যাপ্রুভড লিস্ট
$accounts = $pdo->query("SELECT a.*, u.username FROM account_sales a JOIN users u ON a.user_id = u.id WHERE a.status = 'approved' ORDER BY a.id DESC LIMIT 50")->fetchAll();

require '../common/header.php';
?>
<h3 class="text-success"><i class="fas fa-check-circle"></i> Approved/Sold Accounts</h3>
<div class="card">
    <div class="card-body p-0">
        <table class="table table-bordered mb-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Seller</th>
                    <th>Type</th>
                    <th>Credentials (Sold)</th>
                    <th>Price Paid</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($accounts as $a): ?>
                <tr>
                    <td><?php echo date('d M Y', strtotime($a['created_at'])); ?></td>
                    <td><?php echo $a['username']; ?></td>
                    <td><?php echo ucfirst($a['type']); ?></td>
                    <td><?php echo $a['email_or_phone']; ?> | <?php echo $a['password']; ?></td>
                    <td><?php echo CURRENCY . $a['price']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require '../common/footer.php'; ?>