<?php
require '../common/config.php';
require '../common/db.php';
require '../common/functions.php';
checkLogin();
checkAdmin();

// নম্বর অ্যাড করা
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $method = $_POST['method_name'];
    $number = $_POST['number'];
    $type = $_POST['type']; // Personal/Agent

    $stmt = $pdo->prepare("INSERT INTO deposit_methods (method_name, number, type) VALUES (?, ?, ?)");
    $stmt->execute([$method, $number, $type]);
    $msg = "Number Added!";
}

// নম্বর ডিলিট
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM deposit_methods WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: deposit_settings.php");
}

$methods = $pdo->query("SELECT * FROM deposit_methods")->fetchAll();
require '../common/header.php';
?>
<h3>Payment Methods Settings</h3>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5>Add New Method</h5>
                <form method="POST">
                    <div class="mb-2">
                        <label>Method Name</label>
                        <select name="method_name" class="form-control">
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Rocket">Rocket</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label>Number</label>
                        <input type="text" name="number" class="form-control" required>
                    </div>
                    <div class="mb-2">
                        <label>Type</label>
                        <select name="type" class="form-control">
                            <option value="personal">Personal</option>
                            <option value="agent">Agent</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Add</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <table class="table table-bordered bg-white">
            <tr>
                <th>Method</th>
                <th>Number</th>
                <th>Type</th>
                <th>Action</th>
            </tr>
            <?php foreach($methods as $m): ?>
            <tr>
                <td><?php echo $m['method_name']; ?></td>
                <td><?php echo $m['number']; ?></td>
                <td><?php echo ucfirst($m['type']); ?></td>
                <td><a href="?delete=<?php echo $m['id']; ?>" class="text-danger">Delete</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
<?php require '../common/footer.php'; ?>