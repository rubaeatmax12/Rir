<?php
require 'common/db.php';

try {
    // সেটিংস টেবিলে ref_bonus কলাম যোগ করা হচ্ছে
    $sql = "ALTER TABLE settings ADD COLUMN ref_bonus DECIMAL(10,2) DEFAULT 5.00";
    $pdo->exec($sql);
    echo "<h1>Database Updated Successfully! ✅</h1>";
    echo "<p>Now delete this file.</p>";
} catch (PDOException $e) {
    echo "<h1>Already Updated or Error: " . $e->getMessage() . "</h1>";
}
?>