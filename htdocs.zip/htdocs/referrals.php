<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT ref_code FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$my_ref_code = $stmt->fetchColumn();

// আমার রেফারে যারা জয়েন করেছে
$stmt = $pdo->prepare("SELECT username, created_at FROM users WHERE referrer_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$my_team = $stmt->fetchAll();

require 'common/header.php';
?>

<div class="card mb-4 shadow-sm">
    <div class="card-body text-center bg-primary text-white">
        <h4>My Referral Code</h4>
        <h1 class="display-4 fw-bold text-warning"><?php echo $my_ref_code; ?></h1>
        <p>Share this code to earn bonuses!</p>
        
        <div class="input-group mb-3">
            <input type="text" value="<?php echo SITE_URL; ?>/register.php?ref=<?php echo $my_ref_code; ?>" class="form-control text-center" id="refLink" readonly>
            <button class="btn btn-warning" onclick="copyRef()">Copy Link</button>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-dark text-white">My Team List (Total: <?php echo count($my_team); ?>)</div>
    <div class="card-body p-0">
        <table class="table table-striped mb-0">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Joined Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($my_team) > 0): ?>
                    <?php foreach($my_team as $member): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($member['username']); ?></td>
                        <td><?php echo date('d M Y', strtotime($member['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="2" class="text-center p-3">You haven't referred anyone yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function copyRef() {
    var copyText = document.getElementById("refLink");
    copyText.select();
    document.execCommand("copy");
    alert("Referral Link Copied!");
}
</script>

<?php require 'common/footer.php'; ?>