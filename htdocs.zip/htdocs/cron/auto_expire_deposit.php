<?php
// ডাটাবেস কানেকশন পাথ ঠিক করতে হবে কারণ এটি cron ফোল্ডারে আছে
require __DIR__ . '/../common/config.php'; 
require __DIR__ . '/../common/db.php';

// ২৪ ঘণ্টার পুরনো এবং পেন্ডিং ডিপোজিট খুঁজে বের করা
$sql = "UPDATE deposits SET status = 'rejected' 
        WHERE status = 'pending' 
        AND created_at < NOW() - INTERVAL 24 HOUR";

$stmt = $pdo->prepare($sql);
$stmt->execute();

echo "Auto expire job executed. Rows affected: " . $stmt->rowCount();
?>