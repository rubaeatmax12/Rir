<?php
if(!isset($pdo)) { require __DIR__.'/db.php'; }
if(!defined('SITE_URL')) { require __DIR__.'/config.php'; }

$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch();

// ডিফল্ট ভ্যালু (যদি ডাটাবেসে না থাকে)
$main_color = $settings['theme_color'] ?? '#001e6c';
$body_bg = $settings['body_bg'] ?? '#f0f2f5';
$btn_shape = $settings['btn_shape'] ?? '50%';

// মেইনটেন্যান্স এবং ব্যান চেক
if (isset($settings['app_status']) && $settings['app_status'] == 'off') {
    $current_page = basename($_SERVER['PHP_SELF']);
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        if ($current_page != 'maintenance.php' && $current_page != 'login.php') {
            header("Location: " . SITE_URL . "/maintenance.php"); exit;
        }
    }
}
if (isset($_SESSION['user_id'])) {
    $chk_usr = $pdo->prepare("SELECT status, role FROM users WHERE id = ?");
    $chk_usr->execute([$_SESSION['user_id']]);
    $u_stat = $chk_usr->fetch();
    if ($u_stat && $u_stat['status'] == 'ban' && basename($_SERVER['PHP_SELF']) != 'logout.php') {
        echo "<h1 style='color:red;text-align:center;margin-top:50px;'>YOU ARE BANNED!</h1><center><a href='".SITE_URL."/logout.php'>Logout</a></center>"; exit;
    }
}

$u_bal = 0;
$header_pic = "https://cdn-icons-png.flaticon.com/512/149/149071.png";
if(isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT balance, username, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $u_data = $stmt->fetch();
    $u_bal = $u_data['balance'] ?? 0;
    if (!empty($u_data['profile_pic'])) { $header_pic = SITE_URL . "/assets/images/users/" . $u_data['profile_pic']; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $settings['site_name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* 🔥 ডাইনামিক স্টাইল (অ্যাডমিন যা সেট করবে) 🔥 */
        :root {
            --main-color: <?php echo $main_color; ?>;
            --bg-color: <?php echo $body_bg; ?>;
            --btn-radius: <?php echo $btn_shape; ?>;
        }

        body { background-color: var(--bg-color); font-family: 'Segoe UI', sans-serif; padding-bottom: 70px; }
        
        .app-header { background: var(--main-color); color: white; padding: 15px; position: sticky; top: 0; z-index: 1000; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.15); }
        
        /* ডাইনামিক বাটন শেপ */
        .icon-box, .feature-box, .social-btn, .app-btn {
            border-radius: var(--btn-radius) !important;
        }
        
        /* ডাইনামিক বাটন কালার */
        .nav-icon.active { color: var(--main-color); }
        .menu-item:hover { color: var(--main-color); }
        .sidebar { border-top-right-radius: 20px; border-bottom-right-radius: 20px; }
        
        /* কমন স্টাইল */
        .balance-badge { background: rgba(255,255,255,0.2); padding: 5px 15px; border-radius: 20px; font-weight: bold; font-size: 14px; }
        .sidebar { width: 280px; background: white; height: 100vh; position: fixed; top: 0; left: -280px; z-index: 2000; transition: 0.3s; box-shadow: 2px 0 5px rgba(0,0,0,0.2); }
        .sidebar.active { left: 0; }
        .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1999; display: none; }
        .overlay.active { display: block; }
        .user-profile-header { background: var(--main-color); padding: 30px 20px; color: white; border-bottom-right-radius: 30px; }
        .menu-item { padding: 12px 20px; display: block; color: #333; text-decoration: none; font-weight: 500; border-bottom: 1px solid #f0f0f0; transition: 0.2s; }
        .menu-item i { width: 25px; color: var(--main-color); }
        .bottom-nav { position: fixed; bottom: 0; width: 100%; background: white; display: flex; justify-content: space-around; padding: 10px 0; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); z-index: 999; }
        .nav-icon { text-align: center; color: #666; text-decoration: none; font-size: 12px; }
        .nav-icon i { font-size: 20px; display: block; margin-bottom: 2px; }
        
        /* এনিমেশন */
        .btn, .feature-box, .social-btn, .app-btn, .card, .icon-box { transition: all 0.2s; position: relative; overflow: hidden; }
        .btn:active, .feature-box:active, .social-btn:active, .app-btn:active, .icon-box:active { transform: scale(0.95); box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
    </style>
    
    <script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('active');
        document.querySelector('.overlay').classList.toggle('active');
    }
    </script>
</head>
<body>

<div class="overlay" onclick="toggleSidebar()"></div>
<div class="sidebar" id="sidebar">
    <div class="user-profile-header">
        <div class="d-flex align-items-center">
            <img src="<?php echo $header_pic; ?>" width="60" height="60" class="rounded-circle border border-2 bg-white" style="object-fit: cover;">
            <div class="ms-3">
                <h5 class="mb-0 fw-bold"><?php echo $u_data['username'] ?? 'Guest'; ?></h5>
                <small class="opacity-75">ID: <?php echo $_SESSION['user_id'] ?? 'N/A'; ?></small>
            </div>
        </div>
    </div>
    <div class="py-2">
        <a href="<?php echo SITE_URL; ?>/dashboard.php" class="menu-item"><i class="fas fa-home"></i> Home</a>
        <a href="<?php echo SITE_URL; ?>/user/deposit_history.php" class="menu-item"><i class="fas fa-history"></i> Payment History</a>
        <a href="<?php echo SITE_URL; ?>/user/my_gifts.php" class="menu-item"><i class="fas fa-gift"></i> My Gifts</a>
        <a href="<?php echo SITE_URL; ?>/referrals.php" class="menu-item"><i class="fas fa-users"></i> My Team</a>
        <a href="<?php echo SITE_URL; ?>/user/support.php" class="menu-item"><i class="fas fa-headset"></i> Support</a>
        <a href="<?php echo SITE_URL; ?>/profile.php" class="menu-item"><i class="fas fa-user-cog"></i> Settings</a>
        <a href="<?php echo SITE_URL; ?>/logout.php" class="menu-item text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<div class="app-header d-flex justify-content-between align-items-center">
    <i class="fas fa-bars fa-lg cursor-pointer" onclick="toggleSidebar()"></i>
    <span class="fw-bold fs-5"><?php echo $settings['site_name']; ?></span>
    <div class="balance-badge">৳ <?php echo number_format($u_bal, 2); ?></div>
</div>

<div class="container mt-3" style="min-height: 80vh;">