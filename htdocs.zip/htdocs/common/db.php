<?php
$host = "sql300.infinityfree.com";
$db   = "if0_41110992_project_db";
$user = "if0_41110992";
$pass = "b8bRSQC0FSxvUVS";
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // এরর হলে পরিষ্কারভাবে দেখাবে
    die("Connection Failed: " . $e->getMessage());
}
?>