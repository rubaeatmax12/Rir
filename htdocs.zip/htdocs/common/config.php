<?php
// ১. সেশন শুরু
session_start();

// ২. টাইমজোন
date_default_timezone_set('Asia/Dhaka');

// ৩. সাইট লিংক (তোমার স্ক্রিনশট অনুযায়ী)
define('SITE_URL', 'http://alphaearner.ct.ws'); 

// ৪. সাইট নাম
define('SITE_NAME', 'AlphaEarner');
define('CURRENCY', '৳');

// ৫. 🔥 এরর দেখার জন্য এই লাইনগুলো জরুরি (আগে এটা বন্ধ ছিল) 🔥
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>