<?php
// এই ফাইলটি অন্য কোনো PHP ফাইল থেকে ইনক্লুড করলে অ্যারে রিটার্ন করবে
// অথবা সরাসরি কল করলে JSON রিটার্ন করবে।

require_once __DIR__ . '/db.php';

function getActiveDepositNumbers($pdo) {
    $stmt = $pdo->query("SELECT * FROM deposit_methods WHERE is_active = 1");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// যদি ফাইলটি সরাসরি ব্রাউজারে হিট করা হয় (AJAX এর জন্য)
if (basename($_SERVER['PHP_SELF']) == 'deposit_numbers.php') {
    header('Content-Type: application/json');
    echo json_encode(getActiveDepositNumbers($pdo));
}
?>