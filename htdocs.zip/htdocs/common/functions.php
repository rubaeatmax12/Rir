<?php
// ইউজার লগইন আছে কিনা চেক করা
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . SITE_URL . "/login.php");
        exit;
    }
}

// অ্যাডমিন চেক করা
function checkAdmin() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header("Location: " . SITE_URL . "/index.php");
        exit;
    }
}

// অ্যালার্ট মেসেজ দেখানো
function showAlert($message, $type = 'success') {
    echo "<div class='alert alert-$type'>$message</div>";
}

// ইউজার ব্যালেন্স আনা
function getUserBalance($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn() ?: 0.00;
}
?>