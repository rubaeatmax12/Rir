<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f8d7da; height: 100vh; display: flex; align-items: center; justify-content: center; text-align: center; font-family: 'Segoe UI', sans-serif; }
        .error-box { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); max-width: 400px; width: 90%; border-top: 6px solid #dc3545; }
        .icon { font-size: 60px; color: #dc3545; margin-bottom: 20px; animation: pulse 2s infinite; }
        @keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.1); } 100% { transform: scale(1); } }
    </style>
</head>
<body>
    <div class="error-box">
        <i class="fas fa-shield-alt icon"></i>
        <h2 class="fw-bold text-danger">VPN Detected!</h2>
        <p class="text-muted mt-3">
            আমাদের অ্যাপ ব্যবহার করার জন্য ভিপিএন (VPN) বা প্রক্সি ব্যবহার করা নিষিদ্ধ।
            <br><br>
            <strong>দয়া করে VPN বন্ধ করুন এবং অ্যাপ রিফ্রেশ করুন।</strong>
        </p>
        <button onclick="window.location.href='index.php'" class="btn btn-danger w-100 rounded-pill mt-3">
            <i class="fas fa-sync-alt"></i> I turned off VPN
        </button>
    </div>
</body>
</html>