<?php
// এরর দেখার জন্য
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']); // নতুন: ফোন নম্বর
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $ref_by = !empty($_POST['ref_code']) ? trim($_POST['ref_code']) : null;
    
    $my_ref_code = rand(100000, 999999); 

    // ১. চেক করা ইমেইল, ইউজারনেম বা ফোন নম্বর আগে আছে কিনা
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ? OR phone = ?");
    $stmt->execute([$email, $username, $phone]);
    
    if ($stmt->rowCount() > 0) {
        $error = "Email, Username or Phone Number already exists!";
    } else {
        // ২. রেফারার চেক
        $referrer_id = NULL;
        if ($ref_by) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE ref_code = ?");
            $stmt->execute([$ref_by]);
            $found_id = $stmt->fetchColumn();
            if ($found_id) $referrer_id = $found_id;
        }

        // ৩. ডাটাবেসে ইনসার্ট (ফোন নম্বর সহ)
        $sql = "INSERT INTO users (username, email, phone, password, ref_code, referrer_id, role, status) VALUES (?, ?, ?, ?, ?, ?, 'user', 'inactive')";
        $stmt = $pdo->prepare($sql);
        
        try {
            if ($stmt->execute([$username, $email, $phone, $password, $my_ref_code, $referrer_id])) {
                echo "<script>alert('Account Created Successfully!'); window.location.href='login.php';</script>";
                exit;
            } else {
                $error = "Registration failed!";
            }
        } catch (Exception $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}
require 'common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm mt-4 border-0">
            <div class="card-header bg-primary text-white text-center">
                <h4 class="mb-0">Create New Account</h4>
            </div>
            <div class="card-body p-4">
                <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="fw-bold">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="User Name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="fw-bold">Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="example@gmail.com" required>
                    </div>

                    <!-- 🔥 নতুন ফোন নম্বর বক্স 🔥 -->
                    <div class="mb-3">
                        <label class="fw-bold">Phone Number</label>
                        <input type="number" name="phone" class="form-control" placeholder="017xxxxxxxx" required>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="******" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="fw-bold">Referral Code (Optional)</label>
                        <input type="text" name="ref_code" class="form-control" placeholder="123456">
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 btn-lg">Register Now</button>
                </form>
            </div>
            <div class="card-footer text-center">
                <a href="login.php" class="text-decoration-none">Already have an account? Login</a>
            </div>
        </div>
    </div>
</div>
<?php require 'common/footer.php'; ?>