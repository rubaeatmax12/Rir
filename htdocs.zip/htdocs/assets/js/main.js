// Copy Referral Code Function
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Copied to clipboard: ' + text);
    }, function(err) {
        console.error('Async: Could not copy text: ', err);
    });
}

// Auto-hide alerts after 3 seconds
document.addEventListener("DOMContentLoaded", function() {
    let alerts = document.querySelectorAll('.alert');
    if (alerts.length > 0) {
        setTimeout(function() {
            alerts.forEach(function(alert) {
                alert.style.transition = "opacity 0.5s ease";
                alert.style.opacity = "0";
                setTimeout(() => alert.remove(), 500);
            });
        }, 3000);
    }
});

// Confirm Delete globally
function confirmAction(message) {
    return confirm(message || "Are you sure you want to perform this action?");
}