<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
require 'common/header.php';

// সেটিংস টেবিল থেকে ডেটা আনা (ম্যানুয়ালি ইনসার্ট করতে হবে প্রথমে অথবা অ্যাডমিন প্যানেল থেকে)
// ধরে নিচ্ছি settings টেবিলে ডেটা আছে। না থাকলে ডিফল্ট দেখাবে।
$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch();

$whatsapp = $settings['whatsapp'] ?? '+8801700000000';
$telegram = $settings['telegram'] ?? 'telegram_username';
?>

<div class="container mt-5 text-center">
    <div class="card shadow-lg">
        <div class="card-body py-5">
            <h2 class="card-title text-primary"><i class="fas fa-headset"></i> Support Center</h2>
            <p class="card-text lead">Need help? Contact us directly via WhatsApp or Telegram.</p>
            
            <div class="row mt-4 justify-content-center">
                <div class="col-md-4 mb-3">
                    <a href="https://wa.me/<?php echo str_replace('+', '', $whatsapp); ?>" target="_blank" class="btn btn-success btn-lg w-100">
                        <i class="fab fa-whatsapp"></i> WhatsApp
                    </a>
                </div>
                <div class="col-md-4 mb-3">
                    <a href="https://t.me/<?php echo $telegram; ?>" target="_blank" class="btn btn-info text-white btn-lg w-100">
                        <i class="fab fa-telegram"></i> Telegram
                    </a>
                </div>
            </div>
            
            <p class="mt-3 text-muted">Support Available: 10:00 AM - 10:00 PM</p>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>