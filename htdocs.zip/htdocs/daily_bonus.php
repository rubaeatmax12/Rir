<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$current_month = date('Y-m'); // বর্তমান মাস (যেমন: 2025-02)

// চেক করা এই মাসে বোনাস নিয়েছে কিনা
$stmt = $pdo->prepare("SELECT last_daily_bonus FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$last_bonus_date = $stmt->fetchColumn();

// তারিখ থেকে মাস বের করা
$last_month = date('Y-m', strtotime($last_bonus_date));

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['claim_bonus'])) {
    if ($last_month == $current_month) {
        $error = "You already claimed this month's bonus! Come back next month.";
    } else {
        $amount = rand(1, 10); // ১ থেকে ১০ টাকা বোনাস
        
        $pdo->prepare("UPDATE users SET balance = balance + ?, last_daily_bonus = NOW() WHERE id = ?")->execute([$amount, $user_id]);
        $msg = "Congratulation! You received " . CURRENCY . $amount . " Monthly Bonus!";
        $last_month = $current_month; 
    }
}

require 'common/header.php';
?>

<div class="card shadow text-center mt-5">
    <div class="card-header bg-warning text-dark">
        <h4><i class="fas fa-calendar-check"></i> Monthly Salary</h4>
    </div>
    <div class="card-body py-5">
        <?php if($msg) showAlert($msg, 'success'); ?>
        <?php if($error) showAlert($error, 'danger'); ?>

        <?php if($last_month == $current_month): ?>
            <i class="fas fa-check-circle fa-4x text-success mb-3"></i>
            <h3>Bonus Claimed!</h3>
            <p>Wait for next month.</p>
        <?php else: ?>
            <i class="fas fa-gift fa-4x text-primary mb-3"></i>
            <p class="lead">Claim your monthly salary now!</p>
            <form method="POST">
                <button type="submit" name="claim_bonus" class="btn btn-primary btn-lg rounded-pill px-5">Claim Bonus</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php require 'common/footer.php'; ?>