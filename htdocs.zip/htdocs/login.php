<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login_input = trim($_POST['login_input']); // ইমেইল বা ইউজারনেম
    $password = $_POST['password'];

    // ইমেইল বা ইউজারনেম দিয়ে খোঁজা
    $sql = "SELECT * FROM users WHERE email = ? OR username = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$login_input, $login_input]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // লগইন সফল
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        
        // রোল অনুযায়ী রিডাইরেক্ট
        if($user['role'] == 'admin'){
            header("Location: admin/index.php");
        } else {
            header("Location: dashboard.php");
        }
        exit;
    } else {
        $error = "Wrong Email or Password!";
    }
}
require 'common/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-5">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-primary text-white text-center">
                <h4 class="mb-0">Secure Login</h4>
            </div>
            <div class="card-body p-4">
                <?php if(isset($_GET['msg']) && $_GET['msg']=='registered'): ?>
                    <div class="alert alert-success">Account Created Successfully! Please Login.</div>
                <?php endif; ?>

                <?php if(isset($error)) showAlert($error, 'danger'); ?>
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email or Username</label>
                        <input type="text" name="login_input" class="form-control" placeholder="Enter email or username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                    </div>
                    
                    <!-- 🔥 ফরগেট পাসওয়ার্ড বাটন (নতুন) 🔥 -->
                    <div class="mb-3 text-end">
                        <a href="forgot_password.php" class="text-danger small fw-bold">Forgot Password?</a>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Login Now</button>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center py-3">
                <small>New here? <a href="register.php" class="fw-bold text-decoration-none">Create Account</a></small>
            </div>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>