<?php
require 'common/config.php';
session_destroy();
// লগআউটের পর লগইন পেজে রিডাইরেক্ট
header("Location: login.php");
exit;
?>