<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';

if (!isset($_SESSION['temp_user']) || !isset($_SESSION['otp'])) {
    header("Location: register.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_otp = $_POST['otp'];
    
    if ($user_otp == $_SESSION['otp']) {
        $data = $_SESSION['temp_user'];
        
        // 🔥 অটোমেটিক ইমেইল জেনারেট করা হচ্ছে (ডাটাবেসকে খুশি করার জন্য)
        $auto_email = $data['phone'] . "@mobile.com"; 

        // ১. ডাটাবেসে ইনসার্ট (email সহ)
        $sql = "INSERT INTO users (username, email, phone, password, ref_code, referrer_id, role) VALUES (?, ?, ?, ?, ?, ?, 'user')";
        $stmt = $pdo->prepare($sql);
        
        try {
            if ($stmt->execute([$data['username'], $auto_email, $data['phone'], $data['password'], $data['my_ref_code'], $data['referrer_id']])) {
                
                // ২. রেফার বোনাস
                if ($data['referrer_id']) {
                    $s_stmt = $pdo->query("SELECT ref_bonus FROM settings LIMIT 1");
                    $bonus = $s_stmt->fetchColumn();
                    if ($bonus > 0) {
                        $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$bonus, $data['referrer_id']]);
                    }
                }

                unset($_SESSION['temp_user']);
                unset($_SESSION['otp']);
                
                // সফল হলে লগইন পেজে
                echo "<script>alert('Account Created Successfully! Login now.'); window.location.href='login.php';</script>";
                exit;
            }
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
        }
    } else {
        $error = "Wrong OTP! Please try again.";
    }
}

require 'common/header.php';
?>

<script>
    // টেস্ট করার জন্য
    alert("Your OTP is: <?php echo $_SESSION['otp']; ?>");
</script>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow mt-5">
            <div class="card-header bg-success text-white text-center">
                <h4>Verify Phone Number</h4>
            </div>
            <div class="card-body text-center">
                <p>We have sent a verification code to <strong><?php echo $_SESSION['temp_user']['phone']; ?></strong></p>
                
                <?php if(isset($error)) showAlert($error, 'danger'); ?>

                <form method="POST">
                    <div class="mb-3">
                        <input type="number" name="otp" class="form-control text-center text-primary fw-bold" style="font-size: 24px; letter-spacing: 5px;" placeholder="XXXX" required>
                    </div>
                    <button type="submit" class="btn btn-success w-100">Verify & Create Account</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>