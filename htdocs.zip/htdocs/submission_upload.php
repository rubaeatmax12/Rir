<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

if (!isset($_GET['task_id'])) {
    header("Location: tasks.php");
    exit;
}

$task_id = $_GET['task_id'];

// টাস্কের ডিটেইলস চেক করা
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ?");
$stmt->execute([$task_id]);
$task = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ইমেজ আপলোড হ্যান্ডলিং
    $target_dir = "assets/images/proofs/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
    
    $file_name = time() . "_" . basename($_FILES["proof_img"]["name"]);
    $target_file = $target_dir . $file_name;
    
    if (move_uploaded_file($_FILES["proof_img"]["tmp_name"], $target_file)) {
        // ডাটাবেসে ইনসার্ট
        $sql = "INSERT INTO task_submissions (user_id, task_id, proof_img, status) VALUES (?, ?, ?, 'pending')";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_SESSION['user_id'], $task_id, $file_name]);
        
        echo "<script>alert('Proof Submitted! Wait for approval.'); window.location.href='tasks.php';</script>";
    } else {
        $error = "File upload failed.";
    }
}

require 'common/header.php';
?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">Submit Proof for: <?php echo $task['title']; ?></div>
            <div class="card-body">
                <p><strong>Instructions:</strong> <?php echo $task['description']; ?></p>
                <?php if(isset($error)) showAlert($error, 'danger'); ?>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label>Upload Screenshot</label>
                        <input type="file" name="proof_img" class="form-control" required accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Submit Task</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require 'common/footer.php'; ?>