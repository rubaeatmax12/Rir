<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];

// ১. মেসেজ ডিলিট করার লজিক
if (isset($_GET['delete_id'])) {
    $del_id = $_GET['delete_id'];
    // সিকিউরিটি চেক: মেসেজটি কি এই ইউজারের?
    $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
    $stmt->execute([$del_id, $user_id]);
    
    // পেজ রিলোড
    header("Location: notifications.php?msg=deleted");
    exit;
}

// ২. সব মেসেজ রিড হিসেবে মার্ক করা
$pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$user_id]);

// ৩. সব মেসেজ আনা
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$messages = $stmt->fetchAll();

require 'common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-envelope"></i> My Inbox</h5>
                <span class="badge bg-light text-dark"><?php echo count($messages); ?> Messages</span>
            </div>
            <div class="card-body p-0">
                <?php if(isset($_GET['msg'])): ?>
                    <div class="alert alert-success m-3">Message deleted successfully!</div>
                <?php endif; ?>

                <ul class="list-group list-group-flush">
                    <?php if(count($messages) > 0): ?>
                        <?php foreach($messages as $msg): ?>
                        <li class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="mb-1 text-primary fw-bold"><?php echo htmlspecialchars($msg['title']); ?></h6>
                                    <small class="text-muted d-block mb-2">
                                        <i class="far fa-clock"></i> <?php echo date('d M Y, h:i A', strtotime($msg['created_at'])); ?>
                                    </small>
                                    <p class="mb-1 text-dark"><?php echo nl2br(htmlspecialchars($msg['message'])); ?></p>
                                </div>
                                
                                <!-- ডিলিট বাটন -->
                                <a href="?delete_id=<?php echo $msg['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this message?')">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li class="list-group-item text-center py-5 text-muted">
                            <i class="fas fa-inbox fa-3x mb-3"></i><br>
                            Your inbox is empty.
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>