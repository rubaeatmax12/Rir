<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$msg = "";
$error = "";

// ছবি আপলোড লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_pic'])) {
    $file = $_FILES['profile_pic'];
    $allowed = ['jpg', 'jpeg', 'png'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (in_array($ext, $allowed)) {
        if ($file['size'] <= 2000000) { // 2MB Max
            $new_name = "user_" . $user_id . "." . $ext;
            $target = "assets/images/users/" . $new_name;
            
            // ফোল্ডার না থাকলে তৈরি করা
            if (!file_exists('assets/images/users')) {
                mkdir('assets/images/users', 0777, true);
            }

            if (move_uploaded_file($file['tmp_name'], $target)) {
                // ডাটাবেস আপডেট
                $pdo->prepare("UPDATE users SET profile_pic = ? WHERE id = ?")->execute([$new_name, $user_id]);
                $msg = "Profile picture updated successfully!";
            } else {
                $error = "Failed to upload image!";
            }
        } else {
            $error = "Image size must be less than 2MB!";
        }
    } else {
        $error = "Only JPG, JPEG, PNG allowed!";
    }
}

// পাসওয়ার্ড চেঞ্জ লজিক
if (isset($_POST['change_pass'])) {
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    if (!empty($new_pass)) {
        if ($new_pass === $confirm_pass) {
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $user_id]);
            $msg = "Password Updated Successfully!";
        } else {
            $error = "Passwords do not match!";
        }
    }
}

// ইউজার ডাটা আনা
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// প্রোফাইল পিকচার সেট করা
$pic = !empty($user['profile_pic']) ? "assets/images/users/".$user['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png";

require 'common/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-0">
            <div class="card-body text-center">
                <!-- মেসেজ শো -->
                <?php if($msg) showAlert($msg, 'success'); ?>
                <?php if($error) showAlert($error, 'danger'); ?>

                <!-- প্রোফাইল ছবি -->
                <img src="<?php echo $pic; ?>" class="rounded-circle border border-3 border-primary mb-3" width="120" height="120" style="object-fit: cover;">
                
                <h4 class="fw-bold"><?php echo $user['username']; ?></h4>
                <p class="text-muted"><?php echo $user['email']; ?></p>
                <span class="badge bg-warning text-dark mb-4">Plan: <?php echo $user['vip_level'] ?? 'Free'; ?></span>

                <hr>

                <!-- ছবি আপলোড ফর্ম -->
                <form method="POST" enctype="multipart/form-data" class="mb-4 text-start">
                    <label class="form-label fw-bold">Change Profile Photo</label>
                    <div class="input-group">
                        <input type="file" name="profile_pic" class="form-control" required>
                        <button class="btn btn-primary" type="submit">Upload</button>
                    </div>
                    <small class="text-muted">Max size: 2MB (JPG, PNG)</small>
                </form>

                <hr>

                <!-- পাসওয়ার্ড চেঞ্জ ফর্ম -->
                <form method="POST" class="text-start">
                    <h5 class="fw-bold mb-3"><i class="fas fa-lock"></i> Security</h5>
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" name="change_pass" class="btn btn-danger w-100">Update Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require 'common/footer.php'; ?>