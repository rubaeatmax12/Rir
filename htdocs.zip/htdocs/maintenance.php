<?php
require 'common/config.php';
// যদি কেউ সরাসরি এই পেজে আসে এবং অ্যাপ ON থাকে, তবে তাকে হোমে পাঠাবে
$sys = $pdo->query("SELECT app_status FROM settings LIMIT 1")->fetch();
if ($sys['app_status'] == 'on') {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Maintenance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Segoe UI', sans-serif; }
        .m-box { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); text-align: center; max-width: 400px; width: 90%; }
        .icon-circle { width: 100px; height: 100px; background: #ffeeba; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; }
        .fa-tools { font-size: 50px; color: #ffc107; }
    </style>
</head>
<body>
    <div class="m-box">
        <div class="icon-circle">
            <i class="fas fa-tools"></i>
        </div>
        <h3 class="fw-bold mb-3">System Update!</h3>
        <p class="text-muted">We are currently upgrading our system to serve you better. Please check back in a few minutes.</p>
        
        <div class="alert alert-warning mt-4">
            <small><i class="fas fa-clock"></i> Estimated time: 30 Mins</small>
        </div>

        <button onclick="location.reload()" class="btn btn-dark w-100 rounded-pill mt-3">Try Again</button>
        
        <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
            <a href="admin/index.php" class="btn btn-link mt-2">Go to Admin Panel</a>
        <?php endif; ?>
    </div>
</body>
</html>