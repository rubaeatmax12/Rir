<?php
header("Location: account_sell.php?type=facebook");
exit;
?>