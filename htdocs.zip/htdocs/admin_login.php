<?php
require 'common/config.php';
require 'common/db.php';
require 'common/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login_input = trim($_POST['login_input']);
    $password = $_POST['password'];

    // ডাটাবেস চেক
    $sql = "SELECT * FROM users WHERE email = ? OR username = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$login_input, $login_input]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // চেক করা হচ্ছে সে আসলেই অ্যাডমিন কিনা
        if ($user['role'] === 'admin') {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // অ্যাডমিন প্যানেলে পাঠানো
            header("Location: admin/index.php");
            exit;
        } else {
            $error = "🚫 Access Denied! Only Admin can login here.";
        }
    } else {
        $error = "Wrong Credentials!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - AlphaEarner</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #0f2027; 
            background: linear-gradient(to right, #2c5364, #203a43, #0f2027); 
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .admin-card {
            background: rgba(0, 0, 0, 0.6);
            padding: 40px;
            border-radius: 15px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 15px 25px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            backdrop-filter: blur(10px);
        }
        .admin-icon {
            width: 80px;
            height: 80px;
            background: #ffc107;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
            color: #333;
            box-shadow: 0 0 15px #ffc107;
        }
        .form-control {
            background: rgba(255,255,255,0.1);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 30px;
            text-align: center;
        }
        .form-control::placeholder { color: #ccc; }
        .form-control:focus { background: rgba(255,255,255,0.2); color: white; box-shadow: none; }
        .btn-login {
            background: #ffc107;
            color: #000;
            font-weight: bold;
            border-radius: 30px;
            padding: 12px;
            transition: 0.3s;
            border: none;
        }
        .btn-login:hover { background: #e0a800; transform: scale(1.05); }
    </style>
</head>
<body>

<div class="admin-card text-center">
    <div class="admin-icon">
        <i class="fas fa-user-secret"></i>
    </div>
    <h3 class="fw-bold mb-4">ADMIN ACCESS</h3>

    <?php if(isset($error)): ?>
        <div class="alert alert-danger py-2 mb-3" style="font-size: 13px;"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <input type="text" name="login_input" class="form-control" placeholder="Admin Username / Email" required>
        </div>
        <div class="mb-4">
            <input type="password" name="password" class="form-control" placeholder="Secret Password" required>
        </div>
        <button type="submit" class="btn btn-login w-100">SECURE LOGIN <i class="fas fa-lock ms-2"></i></button>
    </form>
    
    <div class="mt-4">
        <a href="index.php" class="text-white-50 text-decoration-none small"><i class="fas fa-arrow-left"></i> Back to Site</a>
    </div>
</div>

</body>
</html>