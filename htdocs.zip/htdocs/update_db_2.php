<?php
require 'common/db.php';

try {
    // ১. ইউজার টেবিলে VIP এবং Daily Bonus এর ডেট রাখার ঘর বানানো
    $sql1 = "ALTER TABLE users ADD COLUMN vip_level VARCHAR(20) DEFAULT 'Free'";
    $sql2 = "ALTER TABLE users ADD COLUMN last_daily_bonus DATE DEFAULT NULL";
    
    // ২. VIP প্ল্যানগুলোর জন্য টেবিল বানানো
    $sql3 = "CREATE TABLE IF NOT EXISTS vip_plans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        daily_limit INT NOT NULL,
        validity_days INT DEFAULT 30
    )";

    // ৩. কিছু ডিফল্ট প্ল্যান ঢুকিয়ে দেওয়া
    $sql4 = "INSERT INTO vip_plans (name, price, daily_limit, validity_days) VALUES 
            ('Silver', 500.00, 10, 30),
            ('Gold', 1000.00, 25, 30),
            ('Diamond', 2000.00, 50, 60)";

    $pdo->exec($sql1);
    $pdo->exec($sql2);
    $pdo->exec($sql3);
    $pdo->exec($sql4);

    echo "<h1>Database Updated for VIP & Bonus! ✅</h1>";
    echo "<p>Now delete this file.</p>";

} catch (PDOException $e) {
    echo "<h1>Already Updated or Error: " . $e->getMessage() . "</h1>";
}
?>