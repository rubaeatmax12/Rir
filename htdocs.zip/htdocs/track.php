<?php
require 'common/config.php';
require 'common/db.php';

$uid = $_GET['uid'] ?? 0;
$pid = $_GET['pid'] ?? 0;
$ip = $_SERVER['REMOTE_ADDR'];

// প্রোডাক্ট ইনফো
$stmt = $pdo->prepare("SELECT * FROM affiliate_products WHERE id = ?");
$stmt->execute([$pid]);
$prod = $stmt->fetch();

if ($prod) {
    // চেক করা এই আইপি থেকে আগে ক্লিক হয়েছে কিনা (স্প্যাম আটকাতে)
    $check = $pdo->prepare("SELECT id FROM affiliate_clicks WHERE ip_address = ? AND product_id = ?");
    $check->execute([$ip, $pid]);

    if ($check->rowCount() == 0) {
        // ১. নতুন ক্লিক হলে টাকা দেওয়া
        $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$prod['commission'], $uid]);
        // ২. ক্লিক রেকর্ড করা
        $pdo->prepare("INSERT INTO affiliate_clicks (user_id, product_id, ip_address) VALUES (?, ?, ?)")->execute([$uid, $pid, $ip]);
    }
    
    // ৩. আসল প্রোডাক্ট লিংকে পাঠানো
    header("Location: " . $prod['product_link']);
    exit;
} else {
    echo "Invalid Link!";
}
?>