<?php
// Top 5 Users Widget
$top_users_widget = $pdo->query("SELECT username, balance FROM users ORDER BY balance DESC LIMIT 5")->fetchAll();
?>
<div class="card mt-4">
    <div class="card-header bg-dark text-white">
        <i class="fas fa-trophy text-warning"></i> Top Performers
    </div>
    <ul class="list-group list-group-flush">
        <?php foreach($top_users_widget as $idx => $u): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <span>#<?php echo $idx+1; ?> <?php echo $u['username']; ?></span>
            <span class="badge bg-success rounded-pill"><?php echo CURRENCY . $u['balance']; ?></span>
        </li>
        <?php endforeach; ?>
    </ul>
    <div class="card-footer text-center">
        <a href="leaderboard.php" class="btn btn-sm btn-outline-dark">View Full Leaderboard</a>
    </div>
</div>