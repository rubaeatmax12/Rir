<?php
// Last 5 Approved Deposits
$last_deposits = $pdo->query("SELECT u.username, d.amount, d.method FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.status='approved' ORDER BY d.id DESC LIMIT 5")->fetchAll();
?>
<div class="card mt-4">
    <div class="card-header bg-success text-white">
        <i class="fas fa-money-bill-wave"></i> Recent Deposits
    </div>
    <div class="card-body p-0">
        <table class="table table-sm mb-0">
            <?php foreach($last_deposits as $ld): ?>
            <tr>
                <td class="ps-3"><?php echo $ld['username']; ?></td>
                <td><span class="badge bg-light text-dark"><?php echo $ld['method']; ?></span></td>
                <td class="pe-3 text-end fw-bold">+<?php echo $ld['amount']; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>