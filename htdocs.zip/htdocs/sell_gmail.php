<?php
// ইউজারকে সরাসরি জিমেইল সিলেক্ট করা অবস্থায় সেলিং পেজে পাঠাবে
header("Location: account_sell.php?type=gmail");
exit;
?>